using System.Reflection;

[assembly: AssemblyTitle("Gran Turismo Bulgaria Packet Bridge")]
[assembly: AssemblyDescription("Restricted authenticated GT4 UDP packet bridge")]
[assembly: AssemblyCompany("Gran Turismo Bulgaria Personal Project")]
[assembly: AssemblyProduct("Gran Turismo Bulgaria")]
[assembly: AssemblyCopyright("Personal, non-commercial build")]
[assembly: AssemblyVersion("0.17.7.0")]
[assembly: AssemblyFileVersion("0.17.7.0")]
[assembly: AssemblyInformationalVersion("0.17.7-interactive-home")]
