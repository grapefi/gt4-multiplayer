using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace GT4Together
{
    internal enum CoopRaceKind { Standard, OneVsOneMission }

    internal sealed class CoopPlayerState
    {
        public readonly string Id;
        public readonly string Name;
        public readonly bool IsHost;
        public readonly int ComputerSlot;
        public readonly int LocalControllerSlot;
        public long Credits;
        public readonly HashSet<string> Garage = new HashSet<string>(StringComparer.Ordinal);

        public CoopPlayerState(string id, string name, bool isHost, int computerSlot, int localControllerSlot)
        {
            if (string.IsNullOrWhiteSpace(id) || id.Length > 64) throw new ArgumentException("Invalid player identity.");
            if (string.IsNullOrWhiteSpace(name) || name.Length > 32) throw new ArgumentException("Invalid player name.");
            if (computerSlot < 0 || computerSlot > 3 || localControllerSlot < 0 || localControllerSlot > 3) throw new ArgumentOutOfRangeException("Controller assignment is outside the four-player limit.");
            Id = id; Name = name.Trim(); IsHost = isHost; ComputerSlot = computerSlot; LocalControllerSlot = localControllerSlot;
        }
    }

    internal sealed class CoopRaceSlot
    {
        public string PlayerId;
        public int GridSlot;
        public bool StartsGhosted;
    }

    internal sealed class CoopRacePlan
    {
        public readonly string EventId;
        public readonly CoopRaceKind Kind;
        public readonly List<CoopRaceSlot> Players;
        public readonly int RemainingAiCars;

        public CoopRacePlan(string eventId, CoopRaceKind kind, List<CoopRaceSlot> players, int remainingAiCars)
        { EventId = eventId; Kind = kind; Players = players; RemainingAiCars = remainingAiCars; }
    }

    internal sealed class UsedCarListing
    {
        public readonly string Id, SellerId, CarId;
        public readonly long Price;
        public bool Sold;
        public UsedCarListing(string id, string sellerId, string carId, long price) { Id = id; SellerId = sellerId; CarId = carId; Price = price; }
    }

    // Pure deterministic state. Emulator hooks can only submit validated commands to this host-owned model.
    internal sealed class CoopCampaignEngine
    {
        private readonly string _hostId;
        private readonly Dictionary<string, CoopPlayerState> _players = new Dictionary<string, CoopPlayerState>(StringComparer.Ordinal);
        private readonly Dictionary<string, bool> _votes = new Dictionary<string, bool>(StringComparer.Ordinal);
        private readonly Dictionary<string, UsedCarListing> _listings = new Dictionary<string, UsedCarListing>(StringComparer.Ordinal);
        private long _sequence;
        private string _proposal;
        public long Sequence { get { return _sequence; } }
        public IEnumerable<CoopPlayerState> Players { get { return _players.Values.OrderBy(p => p.ComputerSlot).ThenBy(p => p.LocalControllerSlot); } }
        public IEnumerable<UsedCarListing> Listings { get { return _listings.Values.Where(x => !x.Sold).OrderBy(x => x.Id); } }

        public CoopCampaignEngine(CoopPlayerState host)
        {
            if (host == null || !host.IsHost) throw new ArgumentException("The campaign must be created by its host.");
            _hostId = host.Id; AddPlayer(host);
        }

        public void AddPlayer(CoopPlayerState player)
        {
            if (player == null) throw new ArgumentNullException("player");
            if (_players.Count >= 4) throw new InvalidOperationException("The campaign already has four players.");
            if (_players.ContainsKey(player.Id)) throw new InvalidOperationException("Player identity is already present.");
            if (_players.Values.Any(x => x.ComputerSlot == player.ComputerSlot && x.LocalControllerSlot == player.LocalControllerSlot)) throw new InvalidOperationException("Controller assignment is already occupied.");
            if (player.IsHost && _players.Count != 0) throw new InvalidOperationException("Only the original host may be host-authoritative.");
            _players.Add(player.Id, player); ResetVote(); Advance();
        }

        public void RemovePlayer(string playerId)
        {
            if (playerId == _hostId) throw new InvalidOperationException("The active host cannot leave without ending or transferring the session.");
            RequirePlayer(playerId); _players.Remove(playerId); ResetVote(); Advance();
        }

        public void ProposeNavigation(string playerId, string destination)
        {
            RequirePlayer(playerId);
            if (string.IsNullOrWhiteSpace(destination) || destination.Length > 128) throw new ArgumentException("Invalid menu destination.");
            _proposal = destination; _votes.Clear(); _votes[playerId] = true; Advance();
        }

        public bool Vote(string playerId, bool approve)
        {
            RequirePlayer(playerId); if (_proposal == null) throw new InvalidOperationException("There is no active menu proposal.");
            _votes[playerId] = approve; Advance();
            return _players.Keys.All(id => _votes.ContainsKey(id) && _votes[id]);
        }

        public string CommitNavigation(string hostId)
        {
            RequireHost(hostId);
            if (_proposal == null || !_players.Keys.All(id => _votes.ContainsKey(id) && _votes[id])) throw new InvalidOperationException("Every joined player must visibly approve navigation.");
            string result = _proposal; ResetVote(); Advance(); return result;
        }

        public void AddOwnedCar(string hostId, string ownerId, string carId)
        {
            RequireHost(hostId); CoopPlayerState owner = RequirePlayer(ownerId); ValidateCar(carId);
            if (!owner.Garage.Add(carId)) throw new InvalidOperationException("That car is already in this garage."); Advance();
        }

        public UsedCarListing ListCar(string playerId, string carId, long price)
        {
            CoopPlayerState seller = RequirePlayer(playerId); ValidateCar(carId);
            if (price <= 0 || price > 1000000000L) throw new ArgumentOutOfRangeException("price");
            if (!seller.Garage.Remove(carId)) throw new InvalidOperationException("The seller does not own that car.");
            string id = Hash(playerId + "\n" + carId + "\n" + (++_sequence)).Substring(0, 24);
            var listing = new UsedCarListing(id, playerId, carId, price); _listings.Add(id, listing); return listing;
        }

        public void BuyCar(string hostId, string buyerId, string listingId)
        {
            RequireHost(hostId); CoopPlayerState buyer = RequirePlayer(buyerId); UsedCarListing listing;
            if (!_listings.TryGetValue(listingId, out listing) || listing.Sold) throw new InvalidOperationException("The listing is no longer available.");
            if (listing.SellerId == buyerId) throw new InvalidOperationException("A player cannot buy their own listing.");
            CoopPlayerState seller = RequirePlayer(listing.SellerId);
            if (buyer.Credits < listing.Price) throw new InvalidOperationException("The buyer does not have enough credits.");
            if (buyer.Garage.Contains(listing.CarId)) throw new InvalidOperationException("The buyer already owns this unique car record.");
            buyer.Credits -= listing.Price; seller.Credits += listing.Price; buyer.Garage.Add(listing.CarId); listing.Sold = true; Advance();
        }

        public CoopRacePlan PlanRace(string hostId, string eventId, CoopRaceKind kind, int originalGridSize)
        {
            RequireHost(hostId);
            if (string.IsNullOrWhiteSpace(eventId) || eventId.Length > 128) throw new ArgumentException("Invalid event identity.");
            if (originalGridSize < 2 || originalGridSize > 64) throw new ArgumentOutOfRangeException("originalGridSize");
            List<CoopPlayerState> ordered = Players.ToList();
            if (kind == CoopRaceKind.Standard && ordered.Count > originalGridSize) throw new InvalidOperationException("There are not enough grid slots for joined players.");
            var slots = new List<CoopRaceSlot>();
            for (int i = 0; i < ordered.Count; i++) slots.Add(new CoopRaceSlot { PlayerId = ordered[i].Id, GridSlot = kind == CoopRaceKind.OneVsOneMission ? 0 : i, StartsGhosted = kind == CoopRaceKind.OneVsOneMission });
            int ai = kind == CoopRaceKind.OneVsOneMission ? 1 : Math.Max(0, originalGridSize - ordered.Count);
            Advance(); return new CoopRacePlan(eventId, kind, slots, ai);
        }

        public bool CanUnghost(CoopRacePlan plan, IDictionary<string, double> distanceFromSharedStartMetres, double minimumSeparationMetres)
        {
            if (plan == null || plan.Kind != CoopRaceKind.OneVsOneMission) return true;
            if (minimumSeparationMetres < 5 || minimumSeparationMetres > 100) throw new ArgumentOutOfRangeException("minimumSeparationMetres");
            if (distanceFromSharedStartMetres == null || plan.Players.Any(p => !distanceFromSharedStartMetres.ContainsKey(p.PlayerId))) return false;
            double[] positions = plan.Players.Select(p => distanceFromSharedStartMetres[p.PlayerId]).OrderBy(x => x).ToArray();
            for (int i = 1; i < positions.Length; i++) if (positions[i] - positions[i - 1] < minimumSeparationMetres) return false;
            return true;
        }

        public void CommitRaceResult(string hostId, CoopRacePlan plan, IList<string> finishingOrder, IDictionary<string, long> prizeCredits)
        {
            RequireHost(hostId); if (plan == null) throw new ArgumentNullException("plan");
            string[] expected = plan.Players.Select(x => x.PlayerId).OrderBy(x => x, StringComparer.Ordinal).ToArray();
            string[] supplied = (finishingOrder ?? new List<string>()).OrderBy(x => x, StringComparer.Ordinal).ToArray();
            if (!expected.SequenceEqual(supplied, StringComparer.Ordinal) || finishingOrder.Distinct(StringComparer.Ordinal).Count() != finishingOrder.Count) throw new InvalidOperationException("Race results must contain every joined player exactly once.");
            foreach (string id in finishingOrder)
            {
                long prize = prizeCredits != null && prizeCredits.ContainsKey(id) ? prizeCredits[id] : 0;
                if (prize < 0 || prize > 1000000000L || RequirePlayer(id).Credits > long.MaxValue - prize) throw new InvalidOperationException("Invalid race prize.");
                _players[id].Credits += prize;
            }
            Advance();
        }

        private CoopPlayerState RequirePlayer(string id) { CoopPlayerState value; if (id == null || !_players.TryGetValue(id, out value)) throw new InvalidOperationException("Unknown campaign player."); return value; }
        private void RequireHost(string id) { if (!string.Equals(id, _hostId, StringComparison.Ordinal)) throw new UnauthorizedAccessException("Only the authenticated host may commit this change."); }
        private static void ValidateCar(string id) { if (string.IsNullOrWhiteSpace(id) || id.Length > 128) throw new ArgumentException("Invalid car identity."); }
        private void ResetVote() { _proposal = null; _votes.Clear(); }
        private void Advance() { checked { _sequence++; } }
        private static string Hash(string value) { using (SHA256 sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(value))).Replace("-", "").ToLowerInvariant(); }
    }

    internal static class CoopCampaignSelfTest
    {
        public static int Run(string root)
        {
            var report = new List<string> { "Gran Turismo Bulgaria deterministic co-op engine test " + DateTime.UtcNow.ToString("O") };
            bool ok = true;
            try
            {
                var host = new CoopPlayerState("p1", "Host", true, 0, 0) { Credits = 100000 };
                var e = new CoopCampaignEngine(host);
                e.AddPlayer(new CoopPlayerState("p2", "Friend", false, 1, 0) { Credits = 100000 });
                e.AddPlayer(new CoopPlayerState("p3", "Local 2", false, 0, 1) { Credits = 100000 });
                e.AddPlayer(new CoopPlayerState("p4", "Remote local 2", false, 1, 1) { Credits = 100000 });
                Pass(report, ref ok, e.Players.Count() == 4, "four hybrid local/online player assignments");
                e.ProposeNavigation("p2", "GT Mode/Beginner Hall"); e.Vote("p1", true); e.Vote("p3", true);
                Pass(report, ref ok, !e.Vote("p4", false), "navigation blocked by visible no vote");
                e.Vote("p4", true); Pass(report, ref ok, e.CommitNavigation("p1") == "GT Mode/Beginner Hall", "unanimous navigation commit");
                e.AddOwnedCar("p1", "p1", "car-host-001"); e.AddOwnedCar("p1", "p2", "car-friend-001");
                UsedCarListing listing = e.ListCar("p1", "car-host-001", 25000); e.BuyCar("p1", "p2", listing.Id);
                Pass(report, ref ok, host.Credits == 125000 && e.Players.Single(x => x.Id == "p2").Garage.Contains("car-host-001"), "host-authoritative shared used-car sale");
                CoopRacePlan standard = e.PlanRace("p1", "sunday-cup-1", CoopRaceKind.Standard, 6);
                Pass(report, ref ok, standard.Players.Select(x => x.GridSlot).SequenceEqual(new[] { 0, 1, 2, 3 }) && standard.RemainingAiCars == 2, "joined players replace standard AI grid slots");
                CoopRacePlan mission = e.PlanRace("p1", "mission-1v1", CoopRaceKind.OneVsOneMission, 2);
                Pass(report, ref ok, mission.Players.All(x => x.StartsGhosted && x.GridSlot == 0) && mission.RemainingAiCars == 1, "shared ghost start for one-versus-one mission");
                var close = new Dictionary<string, double> { { "p1", 20 }, { "p2", 22 }, { "p3", 40 }, { "p4", 60 } };
                var separated = new Dictionary<string, double> { { "p1", 20 }, { "p2", 35 }, { "p3", 50 }, { "p4", 65 } };
                Pass(report, ref ok, !e.CanUnghost(mission, close, 10) && e.CanUnghost(mission, separated, 10), "automatic unghost separation guard");
                bool rejected = false; try { e.CommitRaceResult("p2", standard, new[] { "p1", "p2", "p3", "p4" }, null); } catch (UnauthorizedAccessException) { rejected = true; }
                Pass(report, ref ok, rejected, "non-host race-result commit rejected");
                e.CommitRaceResult("p1", standard, new[] { "p2", "p1", "p3", "p4" }, new Dictionary<string, long> { { "p2", 10000 }, { "p1", 5000 } });
                Pass(report, ref ok, host.Credits == 130000, "host race-result prize commit");
            }
            catch (Exception ex) { ok = false; report.Add("FAIL unexpected exception: " + ex); }
            string logs = Path.Combine(root, "logs"); Directory.CreateDirectory(logs); File.WriteAllLines(Path.Combine(logs, "coop-engine-self-test.txt"), report.ToArray(), new UTF8Encoding(false));
            return ok ? 0 : 1;
        }

        private static void Pass(List<string> report, ref bool ok, bool condition, string name) { report.Add((condition ? "PASS " : "FAIL ") + name); ok &= condition; }
    }
}
