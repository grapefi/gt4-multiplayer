using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace GT4Together
{
    internal sealed class Gt4BetaHookSite
    {
        public readonly string Name;
        public readonly string Feature;
        public readonly uint Address;
        public readonly byte[] Signature;

        public Gt4BetaHookSite(string name, string feature, uint address, string signature)
        {
            Name = name; Feature = feature; Address = address; Signature = Hex(signature);
        }

        private static byte[] Hex(string value)
        {
            if (value == null || value.Length == 0 || (value.Length & 1) != 0) throw new ArgumentException("Invalid signature hex.");
            byte[] result = new byte[value.Length / 2];
            for (int i = 0; i < result.Length; i++) result[i] = Convert.ToByte(value.Substring(i * 2, 2), 16);
            return result;
        }
    }

    internal static class Gt4BetaHookManifest
    {
        internal const uint SnapshotBase = 0x00100000;
        internal static readonly Gt4BetaHookSite[] Sites =
        {
            new Gt4BetaHookSite("GetCursorProject", "extra-cursors", 0x003A5320, "B0FFBD273800B1FF2D8880003000B0FF2D20A0034000B2FF1E00C0144800BFFF"),
            new Gt4BetaHookSite("CursorVisibleProperty", "extra-cursors", 0x003A63B0, "C0FFBD272000B0FF2D80E0002800B1FF2D8880003000B2FF1F00C0143800BFFF"),
            new Gt4BetaHookSite("CursorProperty", "extra-cursors", 0x003A65A8, "90FFBD274000B0FF2D80E0004800B1FF2D8880005000B2FF5800B3FF2A00C014"),
            new Gt4BetaHookSite("SetFocus", "menu-voting", 0x003AC230, "C0FFBD273000B0FF2D80E0001300C0183800BFFFF4AE0E0C2D20A0030000038E"),
            new Gt4BetaHookSite("GarageCopyFrom", "garage-switching", 0x0012BD28, "B0FFBD273000B0FF2D80E0003800B1FF1100C0184000BFFF02A8040C2D20A003"),
            new Gt4BetaHookSite("GetGarageIndex", "garage-switching", 0x00131328, "C0FFBD273000B2FF1000B2272800B1FF2D8880002000B0FF3800BFFF02A8040C"),
            new Gt4BetaHookSite("CurrentCarGrid", "ai-replacement", 0x001F3C90, "50FFBD272D18A0007800B3FF2D9880006000B0FF6800B1FF7000B2FF8000B4FF"),
            new Gt4BetaHookSite("LanRaceResult", "race-results", 0x00202FC8, "F0FFBD270000B0FF0800BFFFEE340A0C2D8080000C0800AE6F00043C48F18424"),
            new Gt4BetaHookSite("NetRaceResult", "race-results", 0x00203190, "F0FFBD270000B0FF0800BFFFEE340A0C2D8080000C0800AE6F00043C88F18424"),
            new Gt4BetaHookSite("OnlineRaceBindings", "online-race-control", 0x00391450, "D0FFBD276A00023C1000B0FF2D8080001800B1FF2D88A0032000B2FF68414524"),
            new Gt4BetaHookSite("EventResultPath", "event-completion", 0x003D2D80, "60FFBD276000B0FF2D8080008800B5FF2DA8A0009000B6FF6800B1FF7000B2FF")
        };

        internal static void VerifyLive(PineClient pine)
        {
            foreach (Gt4BetaHookSite site in Sites)
            {
                int words = (site.Signature.Length + 3) / 4;
                byte[] actual = pine.ReadWords(site.Address, words).Take(site.Signature.Length).ToArray();
                if (!actual.SequenceEqual(site.Signature)) throw new InvalidDataException("GT4 hook signature mismatch at " + site.Name + " (0x" + site.Address.ToString("X8") + "). No write is permitted.");
            }
        }

        internal static int SelfTest(string root)
        {
            var lines = new List<string> { "Gran Turismo Bulgaria Online Beta hook-manifest test " + DateTime.Now.ToString("O") };
            bool ok = false;
            try
            {
                string snapshot = Path.Combine(root, "logs", "gt4-beta-ee-00100000-00800000.bin");
                byte[] bytes = File.Exists(snapshot) ? File.ReadAllBytes(snapshot) : null;
                var addresses = new HashSet<uint>();
                foreach (Gt4BetaHookSite site in Sites)
                {
                    if (!addresses.Add(site.Address) || site.Signature.Length != 32) throw new InvalidDataException("Invalid or duplicate hook manifest entry: " + site.Name);
                    if (bytes != null)
                    {
                        long offset = site.Address - SnapshotBase;
                        if (offset < 0 || offset + site.Signature.Length > bytes.Length) throw new InvalidDataException("Hook site is outside the exact-build snapshot: " + site.Name);
                        byte[] actual = new byte[site.Signature.Length]; Buffer.BlockCopy(bytes, (int)offset, actual, 0, actual.Length);
                        if (!actual.SequenceEqual(site.Signature)) throw new InvalidDataException("Signature mismatch: " + site.Name);
                    }
                    lines.Add("PASS " + site.Feature + " signature " + site.Name + " @ 0x" + site.Address.ToString("X8"));
                }
                lines.Add(bytes == null ? "INFO development memory snapshot is intentionally not shipped; use the live exact-build test" : "PASS signatures match the captured exact-build snapshot");
                byte[] tampered = (byte[])Sites[0].Signature.Clone(); tampered[0] ^= 1;
                ok = !tampered.SequenceEqual(Sites[0].Signature);
                lines.Add(ok ? "PASS fail-closed tamper check" : "FAIL fail-closed tamper check");
            }
            catch (Exception ex) { lines.Add("FAIL " + ex.GetType().Name + ": " + ex.Message); }
            lines.Add(ok ? "RESULT PASS" : "RESULT FAIL");
            Directory.CreateDirectory(Path.Combine(root, "logs"));
            File.WriteAllLines(Path.Combine(root, "logs", "gt4-beta-hook-manifest-test.txt"), lines.ToArray(), new UTF8Encoding(false));
            return ok ? 0 : 1;
        }
    }
}
