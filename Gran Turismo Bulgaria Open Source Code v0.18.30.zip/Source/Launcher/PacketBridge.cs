using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Threading;

namespace GT4PacketBridge
{
    internal static class Program
    {
        private static readonly byte[] Magic = { (byte)'G', (byte)'T', (byte)'B', (byte)'P' };

        [STAThread]
        private static int Main(string[] args)
        {
            try
            {
                if (args.Length == 1 && string.Equals(args[0], "--self-test", StringComparison.OrdinalIgnoreCase))
                    return ParserSelfTest() ? 0 : 1;
                if (args.Length != 3) return 2;
                int parentPid, bridgePort;
                if (!int.TryParse(args[0], out parentPid) || parentPid <= 0) return 2;
                if (!int.TryParse(args[1], out bridgePort) || bridgePort < 1 || bridgePort > 65535) return 2;
                byte[] token = Hex(args[2]);
                if (token.Length != 32) return 2;

                Process parent;
                try { parent = Process.GetProcessById(parentPid); }
                catch { return 3; }

                using (var output = new UdpClient(AddressFamily.InterNetwork))
                {
                    var destination = new IPEndPoint(IPAddress.Loopback, bridgePort);
                    PrepareRuntime();
                    IntPtr handle = WinDivertOpen("ip and outbound and !loopback and udp.DstPort == 3658 and udp.PayloadLength > 0", 0, 0, 0x0001 | 0x0004);
                    if (handle == new IntPtr(-1)) return Marshal.GetLastWin32Error() == 5 ? 5 : 4;
                    try
                    {
                        Send(output, destination, token, new byte[0]);
                        var watcher = new Thread((ThreadStart)delegate
                        {
                            try { parent.WaitForExit(); } catch { }
                            WinDivertShutdown(handle, 0x3);
                        });
                        watcher.IsBackground = true;
                        watcher.Start();

                        byte[] packet = new byte[65535];
                        byte[] address = new byte[80];
                        while (!parent.HasExited)
                        {
                            uint length;
                            if (!WinDivertRecv(handle, packet, (uint)packet.Length, out length, address)) break;
                            byte[] payload;
                            if (TryExtractUdpPayload(packet, (int)length, out payload) && payload.Length <= 4096)
                                Send(output, destination, token, payload);
                        }
                    }
                    finally { WinDivertClose(handle); }
                }
                return 0;
            }
            catch { return 9; }
        }

        private static void Send(UdpClient output, IPEndPoint destination, byte[] token, byte[] payload)
        {
            byte[] frame = new byte[38 + payload.Length];
            Buffer.BlockCopy(Magic, 0, frame, 0, 4);
            Buffer.BlockCopy(token, 0, frame, 4, 32);
            frame[36] = (byte)(payload.Length >> 8);
            frame[37] = (byte)payload.Length;
            Buffer.BlockCopy(payload, 0, frame, 38, payload.Length);
            output.Send(frame, frame.Length, destination);
        }

        internal static bool TryExtractUdpPayload(byte[] packet, int packetLength, out byte[] payload)
        {
            payload = null;
            if (packet == null || packetLength < 28 || packetLength > packet.Length) return false;
            if ((packet[0] >> 4) != 4 || packet[9] != 17) return false;
            int ipHeader = (packet[0] & 0x0F) * 4;
            if (ipHeader < 20 || ipHeader + 8 > packetLength) return false;
            int destinationPort = (packet[ipHeader + 2] << 8) | packet[ipHeader + 3];
            if (destinationPort != 3658) return false;
            int udpLength = (packet[ipHeader + 4] << 8) | packet[ipHeader + 5];
            if (udpLength < 8 || ipHeader + udpLength > packetLength) return false;
            int payloadLength = udpLength - 8;
            payload = new byte[payloadLength];
            Buffer.BlockCopy(packet, ipHeader + 8, payload, 0, payloadLength);
            return true;
        }

        private static byte[] Hex(string value)
        {
            if (value == null || value.Length % 2 != 0) return new byte[0];
            var bytes = new byte[value.Length / 2];
            for (int i = 0; i < bytes.Length; i++)
            {
                int hi = Digit(value[i * 2]), lo = Digit(value[i * 2 + 1]);
                if (hi < 0 || lo < 0) return new byte[0];
                bytes[i] = (byte)((hi << 4) | lo);
            }
            return bytes;
        }

        private static bool ParserSelfTest()
        {
            byte[] expected = { 0x47, 0x54, 0x34, 0x01, 0x02 };
            byte[] packet = new byte[20 + 8 + expected.Length];
            packet[0] = 0x45; packet[2] = 0; packet[3] = (byte)packet.Length; packet[9] = 17;
            packet[20] = 0x0E; packet[21] = 0x4A; packet[22] = 0x0E; packet[23] = 0x4A;
            int udpLength = 8 + expected.Length; packet[24] = (byte)(udpLength >> 8); packet[25] = (byte)udpLength;
            Buffer.BlockCopy(expected, 0, packet, 28, expected.Length);
            byte[] actual;
            if (!TryExtractUdpPayload(packet, packet.Length, out actual) || actual.Length != expected.Length) return false;
            for (int i = 0; i < expected.Length; i++) if (actual[i] != expected[i]) return false;
            packet[23] = 0x4B;
            return !TryExtractUdpPayload(packet, packet.Length, out actual);
        }

        private static void PrepareRuntime()
        {
            string archive = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "WinDivert-2.2.2-A.zip");
            if (!File.Exists(archive)) throw new FileNotFoundException("WinDivert runtime archive is missing.", archive);
            byte[] digest;
            using (var stream = File.OpenRead(archive)) using (var sha = SHA256.Create()) digest = sha.ComputeHash(stream);
            string actual = BitConverter.ToString(digest).Replace("-", "");
            if (!string.Equals(actual, "63CB41763BB4B20F600B6DE04E991A9C2BE73279E317D4D82F237B150C5F3F15", StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("WinDivert runtime archive failed integrity verification.");
            string runtime = Path.Combine(Path.GetTempPath(), "GranTurismoBulgaria", "WinDivert-2.2.2");
            Directory.CreateDirectory(runtime);
            using (var zip = new ZipArchive(File.OpenRead(archive), ZipArchiveMode.Read))
            {
                Extract(zip, "x64/WinDivert.dll", Path.Combine(runtime, "WinDivert.dll"), 47616);
                Extract(zip, "x64/WinDivert64.sys", Path.Combine(runtime, "WinDivert64.sys"), 94144);
            }
            if (!SetDllDirectory(runtime) || LoadLibrary(Path.Combine(runtime, "WinDivert.dll")) == IntPtr.Zero)
                throw new InvalidOperationException("Windows could not activate the verified packet bridge runtime.");
        }

        private static void Extract(ZipArchive zip, string suffix, string destination, long expectedLength)
        {
            ZipArchiveEntry entry = zip.Entries.FirstOrDefault(e => e.FullName.Replace('\\', '/').EndsWith(suffix, StringComparison.OrdinalIgnoreCase));
            if (entry == null || entry.Length != expectedLength) throw new InvalidDataException("WinDivert runtime entry is missing or invalid: " + suffix);
            using (Stream input = entry.Open()) using (FileStream output = new FileStream(destination, FileMode.Create, FileAccess.Write, FileShare.Read)) input.CopyTo(output);
        }

        private static int Digit(char c)
        {
            if (c >= '0' && c <= '9') return c - '0';
            if (c >= 'a' && c <= 'f') return c - 'a' + 10;
            if (c >= 'A' && c <= 'F') return c - 'A' + 10;
            return -1;
        }

        [DllImport("WinDivert.dll", CharSet = CharSet.Ansi, SetLastError = true)]
        private static extern IntPtr WinDivertOpen(string filter, int layer, short priority, ulong flags);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetDllDirectory(string path);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern IntPtr LoadLibrary(string path);

        [DllImport("WinDivert.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool WinDivertRecv(IntPtr handle, [Out] byte[] packet, uint packetLength, out uint receiveLength, [Out] byte[] address);

        [DllImport("WinDivert.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool WinDivertShutdown(IntPtr handle, int how);

        [DllImport("WinDivert.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool WinDivertClose(IntPtr handle);
    }
}
