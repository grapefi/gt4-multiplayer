using System.Reflection;

[assembly: AssemblyTitle("Gran Turismo Bulgaria")]
[assembly: AssemblyDescription("Personal Windows 11 launcher for the owner's Gran Turismo 4 installation")]
[assembly: AssemblyCompany("Gran Turismo Bulgaria Personal Project")]
[assembly: AssemblyProduct("Gran Turismo Bulgaria")]
[assembly: AssemblyCopyright("Personal, non-commercial build")]
[assembly: AssemblyVersion("0.18.30.0")]
[assembly: AssemblyFileVersion("0.18.30.0")]
[assembly: AssemblyInformationalVersion("0.18.30-beta-verified-safety")]
