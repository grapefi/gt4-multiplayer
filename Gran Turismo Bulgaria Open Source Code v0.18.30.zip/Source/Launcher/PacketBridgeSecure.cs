using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.IO.Pipes;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Threading;

namespace GT4PacketBridgeSecure
{
    internal static class Program
    {
        private static readonly byte[] Magic = { (byte)'G', (byte)'T', (byte)'B', (byte)'P' };
        private static readonly object FlowLock = new object();
        private static readonly Dictionary<ulong, ushort> Pcsx2Flows = new Dictionary<ulong, ushort>();
        private static readonly Dictionary<ushort, int> Pcsx2Ports = new Dictionary<ushort, int>();
        private static string _approvedRoot;
        private static volatile bool _running = true;

        [STAThread]
        private static int Main(string[] args)
        {
            string runtimeDirectory = null;
            byte[] token = null;
            try
            {
                if (args.Length == 1 && string.Equals(args[0], "--self-test", StringComparison.OrdinalIgnoreCase))
                    return ParserSelfTest() ? 0 : 1;
                if (args.Length != 3) return 2;
                int parentPid, bridgePort;
                if (!int.TryParse(args[0], out parentPid) || parentPid <= 0) return 2;
                if (!int.TryParse(args[1], out bridgePort) || bridgePort < 1 || bridgePort > 65535) return 2;
                if (!IsSafePipeName(args[2])) return 2;

                Process parent;
                try { parent = Process.GetProcessById(parentPid); }
                catch { return 3; }

                ReadHandshake(args[2], parentPid, out token, out _approvedRoot);
                VerifyLauncher(parent, _approvedRoot);

                using (var output = new UdpClient(AddressFamily.InterNetwork))
                {
                    var destination = new IPEndPoint(IPAddress.Loopback, bridgePort);
                    runtimeDirectory = PrepareRuntime();

                    // FLOW events provide the owning process ID. Only local ports belonging to
                    // the packaged PCSX2 executables are admitted to the network capture path.
                    IntPtr flowHandle = WinDivertOpen("outbound and udp.DstPort == 3658", 2, 0, 0x0001 | 0x0004);
                    if (flowHandle == new IntPtr(-1)) return Marshal.GetLastWin32Error() == 5 ? 5 : 4;
                    IntPtr packetHandle = WinDivertOpen("ip and outbound and !loopback and udp.DstPort == 3658 and udp.PayloadLength > 0", 0, 0, 0x0001 | 0x0004);
                    if (packetHandle == new IntPtr(-1)) { WinDivertClose(flowHandle); return Marshal.GetLastWin32Error() == 5 ? 5 : 4; }
                    try
                    {
                        var flowThread = new Thread((ThreadStart)delegate { FlowLoop(flowHandle); });
                        flowThread.IsBackground = true;
                        flowThread.Start();

                        Send(output, destination, token, new byte[0]);
                        var watcher = new Thread((ThreadStart)delegate
                        {
                            try { parent.WaitForExit(); } catch { }
                            _running = false;
                            WinDivertShutdown(flowHandle, 0x3);
                            WinDivertShutdown(packetHandle, 0x3);
                        });
                        watcher.IsBackground = true;
                        watcher.Start();

                        byte[] packet = new byte[8192];
                        byte[] address = new byte[80];
                        while (_running && !parent.HasExited)
                        {
                            uint length;
                            if (!WinDivertRecv(packetHandle, packet, (uint)packet.Length, out length, address)) break;
                            byte[] payload; ushort sourcePort;
                            if (TryExtractUdpPayload(packet, (int)length, out payload, out sourcePort) && payload.Length <= 4096 && IsApprovedPort(sourcePort))
                                Send(output, destination, token, payload);
                        }
                    }
                    finally
                    {
                        _running = false;
                        WinDivertShutdown(flowHandle, 0x3);
                        WinDivertClose(flowHandle);
                        WinDivertClose(packetHandle);
                    }
                }
                return 0;
            }
            catch { return 9; }
            finally
            {
                if (token != null) Array.Clear(token, 0, token.Length);
                if (!string.IsNullOrEmpty(runtimeDirectory)) TryDeleteRuntime(runtimeDirectory);
            }
        }

        private static void ReadHandshake(string pipeName, int expectedParentPid, out byte[] token, out string approvedRoot)
        {
            using (var pipe = new NamedPipeClientStream(".", pipeName, PipeDirection.In, PipeOptions.None))
            {
                pipe.Connect(8000);
                using (var reader = new BinaryReader(pipe, new UTF8Encoding(false), true))
                {
                    int parentPid = reader.ReadInt32();
                    int tokenLength = reader.ReadInt32();
                    if (parentPid != expectedParentPid || tokenLength != 32) throw new InvalidDataException("Packet bridge handshake was not issued by the launcher.");
                    token = reader.ReadBytes(tokenLength);
                    if (token.Length != tokenLength) throw new EndOfStreamException();
                    int rootLength = reader.ReadInt32();
                    if (rootLength < 3 || rootLength > 32768) throw new InvalidDataException("Packet bridge root is invalid.");
                    byte[] rootBytes = reader.ReadBytes(rootLength);
                    if (rootBytes.Length != rootLength) throw new EndOfStreamException();
                    approvedRoot = Path.GetFullPath(Encoding.UTF8.GetString(rootBytes)).TrimEnd(Path.DirectorySeparatorChar);
                }
            }
        }

        private static bool IsSafePipeName(string name)
        {
            if (string.IsNullOrWhiteSpace(name) || name.Length > 96 || !name.StartsWith("GTB-Bridge-", StringComparison.Ordinal)) return false;
            for (int i = "GTB-Bridge-".Length; i < name.Length; i++)
            {
                char c = name[i];
                if (!((c >= 'a' && c <= 'f') || (c >= '0' && c <= '9'))) return false;
            }
            return true;
        }

        private static void VerifyLauncher(Process parent, string root)
        {
            string actual = Path.GetFullPath(parent.MainModule.FileName);
            string expected = Path.GetFullPath(Path.Combine(root, "Gran Turismo Bulgaria.exe"));
            if (!string.Equals(actual, expected, StringComparison.OrdinalIgnoreCase)) throw new UnauthorizedAccessException("Packet bridge parent is not the approved launcher.");
        }

        private static void FlowLoop(IntPtr handle)
        {
            byte[] address = new byte[80];
            while (_running)
            {
                uint ignored;
                if (!WinDivertRecv(handle, null, 0, out ignored, address)) break;
                byte eventType = address[9];
                ulong endpointId = BitConverter.ToUInt64(address, 16);
                uint processId = BitConverter.ToUInt32(address, 32);
                ushort localPort = BitConverter.ToUInt16(address, 68);
                if (eventType == 1 && IsApprovedPcsx2Process(processId)) AddFlow(endpointId, localPort);
                else if (eventType == 2) RemoveFlow(endpointId);
            }
        }

        private static bool IsApprovedPcsx2Process(uint processId)
        {
            try
            {
                using (Process process = Process.GetProcessById((int)processId))
                {
                    string path = Path.GetFullPath(process.MainModule.FileName);
                    string runtime = Path.GetFullPath(Path.Combine(_approvedRoot, "runtime")) + Path.DirectorySeparatorChar;
                    string file = Path.GetFileName(path);
                    return path.StartsWith(runtime, StringComparison.OrdinalIgnoreCase) &&
                        (string.Equals(file, "pcsx2-qt.exe", StringComparison.OrdinalIgnoreCase) || string.Equals(file, "pcsx2-qtx64.exe", StringComparison.OrdinalIgnoreCase));
                }
            }
            catch { return false; }
        }

        private static void AddFlow(ulong endpointId, ushort localPort)
        {
            if (localPort == 0) return;
            lock (FlowLock)
            {
                if (Pcsx2Flows.ContainsKey(endpointId)) return;
                Pcsx2Flows[endpointId] = localPort;
                int count; Pcsx2Ports.TryGetValue(localPort, out count); Pcsx2Ports[localPort] = count + 1;
            }
        }

        private static void RemoveFlow(ulong endpointId)
        {
            lock (FlowLock)
            {
                ushort port;
                if (!Pcsx2Flows.TryGetValue(endpointId, out port)) return;
                Pcsx2Flows.Remove(endpointId);
                int count;
                if (!Pcsx2Ports.TryGetValue(port, out count) || count <= 1) Pcsx2Ports.Remove(port); else Pcsx2Ports[port] = count - 1;
            }
        }

        private static bool IsApprovedPort(ushort port) { lock (FlowLock) return Pcsx2Ports.ContainsKey(port); }

        private static void Send(UdpClient output, IPEndPoint destination, byte[] token, byte[] payload)
        {
            byte[] frame = new byte[38 + payload.Length];
            Buffer.BlockCopy(Magic, 0, frame, 0, 4);
            Buffer.BlockCopy(token, 0, frame, 4, 32);
            frame[36] = (byte)(payload.Length >> 8);
            frame[37] = (byte)payload.Length;
            Buffer.BlockCopy(payload, 0, frame, 38, payload.Length);
            output.Send(frame, frame.Length, destination);
        }

        internal static bool TryExtractUdpPayload(byte[] packet, int packetLength, out byte[] payload, out ushort sourcePort)
        {
            payload = null; sourcePort = 0;
            if (packet == null || packetLength < 28 || packetLength > packet.Length) return false;
            if ((packet[0] >> 4) != 4 || packet[9] != 17) return false;
            int ipHeader = (packet[0] & 0x0F) * 4;
            if (ipHeader < 20 || ipHeader + 8 > packetLength) return false;
            sourcePort = (ushort)((packet[ipHeader] << 8) | packet[ipHeader + 1]);
            int destinationPort = (packet[ipHeader + 2] << 8) | packet[ipHeader + 3];
            if (sourcePort == 0 || destinationPort != 3658) return false;
            int udpLength = (packet[ipHeader + 4] << 8) | packet[ipHeader + 5];
            if (udpLength < 8 || ipHeader + udpLength > packetLength) return false;
            int payloadLength = udpLength - 8;
            payload = new byte[payloadLength];
            Buffer.BlockCopy(packet, ipHeader + 8, payload, 0, payloadLength);
            return true;
        }

        private static bool ParserSelfTest()
        {
            byte[] expected = { 0x47, 0x54, 0x34, 0x01, 0x02 };
            byte[] packet = new byte[20 + 8 + expected.Length];
            packet[0] = 0x45; packet[2] = 0; packet[3] = (byte)packet.Length; packet[9] = 17;
            packet[20] = 0x0E; packet[21] = 0x4A; packet[22] = 0x0E; packet[23] = 0x4A;
            int udpLength = 8 + expected.Length; packet[24] = (byte)(udpLength >> 8); packet[25] = (byte)udpLength;
            Buffer.BlockCopy(expected, 0, packet, 28, expected.Length);
            byte[] actual; ushort port;
            if (!TryExtractUdpPayload(packet, packet.Length, out actual, out port) || port != 3658 || actual.Length != expected.Length) return false;
            for (int i = 0; i < expected.Length; i++) if (actual[i] != expected[i]) return false;
            packet[23] = 0x4B;
            return !TryExtractUdpPayload(packet, packet.Length, out actual, out port);
        }

        private static string PrepareRuntime()
        {
            string archive = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "WinDivert-2.2.2-A.zip");
            if (!File.Exists(archive)) throw new FileNotFoundException("WinDivert runtime archive is missing.", archive);
            if (!string.Equals(HashFile(archive), "63CB41763BB4B20F600B6DE04E991A9C2BE73279E317D4D82F237B150C5F3F15", StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("WinDivert runtime archive failed integrity verification.");

            string parent = Path.Combine(Path.GetTempPath(), "GranTurismoBulgaria");
            CreatePrivateDirectory(parent);
            string runtime = Path.Combine(parent, RandomHex(24));
            CreatePrivateDirectory(runtime);
            using (var stream = new FileStream(archive, FileMode.Open, FileAccess.Read, FileShare.Read))
            using (var zip = new ZipArchive(stream, ZipArchiveMode.Read))
            {
                ExtractVerified(zip, "x64/WinDivert.dll", Path.Combine(runtime, "WinDivert.dll"), 47616, "C1E060EE19444A259B2162F8AF0F3FE8C4428A1C6F694DCE20DE194AC8D7D9A2");
                ExtractVerified(zip, "x64/WinDivert64.sys", Path.Combine(runtime, "WinDivert64.sys"), 94144, "8DA085332782708D8767BCACE5327A6EC7283C17CFB85E40B03CD2323A90DDC2");
            }
            if ((File.GetAttributes(runtime) & FileAttributes.ReparsePoint) != 0 || !SetDllDirectory(runtime) || LoadLibrary(Path.Combine(runtime, "WinDivert.dll")) == IntPtr.Zero)
                throw new InvalidOperationException("Windows could not activate the verified packet bridge runtime.");
            return runtime;
        }

        private static void CreatePrivateDirectory(string path)
        {
            if (Directory.Exists(path))
            {
                if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0) throw new IOException("Packet bridge runtime path is a reparse point.");
                return;
            }
            var security = new DirectorySecurity();
            security.SetAccessRuleProtection(true, false);
            SecurityIdentifier user = WindowsIdentity.GetCurrent().User;
            security.AddAccessRule(new FileSystemAccessRule(user, FileSystemRights.FullControl, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
            security.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null), FileSystemRights.FullControl, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
            security.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null), FileSystemRights.FullControl, InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit, PropagationFlags.None, AccessControlType.Allow));
            Directory.CreateDirectory(path, security);
        }

        private static void ExtractVerified(ZipArchive zip, string suffix, string destination, long expectedLength, string expectedHash)
        {
            ZipArchiveEntry[] entries = zip.Entries.Where(e => e.FullName.Replace('\\', '/').EndsWith(suffix, StringComparison.OrdinalIgnoreCase)).ToArray();
            if (entries.Length != 1 || entries[0].Length != expectedLength) throw new InvalidDataException("WinDivert runtime entry is missing or ambiguous: " + suffix);
            using (Stream input = entries[0].Open())
            using (FileStream output = new FileStream(destination, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                input.CopyTo(output); output.Flush(true);
            }
            if (!string.Equals(HashFile(destination), expectedHash, StringComparison.OrdinalIgnoreCase)) throw new CryptographicException("WinDivert extracted file hash did not match: " + suffix);
        }

        private static string HashFile(string path)
        {
            using (var input = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
            using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(input)).Replace("-", "");
        }

        private static string RandomHex(int bytes)
        {
            byte[] value = new byte[bytes]; using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(value);
            return BitConverter.ToString(value).Replace("-", "").ToLowerInvariant();
        }

        private static void TryDeleteRuntime(string path)
        {
            try
            {
                SetDllDirectory(null);
                if (!string.IsNullOrEmpty(path) && Directory.Exists(path) && Path.GetFileName(path).Length == 48) Directory.Delete(path, true);
            }
            catch { }
        }

        [DllImport("WinDivert.dll", CharSet = CharSet.Ansi, SetLastError = true)]
        private static extern IntPtr WinDivertOpen(string filter, int layer, short priority, ulong flags);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)] private static extern bool SetDllDirectory(string path);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern IntPtr LoadLibrary(string path);
        [DllImport("WinDivert.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)] private static extern bool WinDivertRecv(IntPtr handle, [Out] byte[] packet, uint packetLength, out uint receiveLength, [Out] byte[] address);
        [DllImport("WinDivert.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)] private static extern bool WinDivertShutdown(IntPtr handle, int how);
        [DllImport("WinDivert.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)] private static extern bool WinDivertClose(IntPtr handle);
    }
}
