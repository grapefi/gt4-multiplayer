using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace GT4Together
{
    internal enum TunnelTransport { Tcp, Udp }

    internal struct LegacyService
    {
        public readonly TunnelTransport Transport;
        public readonly int Port;
        public readonly string Purpose;
        public LegacyService(TunnelTransport transport, int port, string purpose) { Transport = transport; Port = port; Purpose = purpose; }
    }

    // Public peers never choose arbitrary destinations. A future tunnel endpoint must map
    // authenticated logical service IDs through this closed policy to loopback only.
    internal static class LegacyTunnelPolicy
    {
        private static readonly LegacyService[] Services =
        {
            new LegacyService(TunnelTransport.Tcp, 10058, "SVO bootstrap"),
            new LegacyService(TunnelTransport.Tcp, 10060, "SVO HTTP"),
            new LegacyService(TunnelTransport.Tcp, 10061, "SVO HTTPS"),
            new LegacyService(TunnelTransport.Udp, 10070, "Medius NAT"),
            new LegacyService(TunnelTransport.Tcp, 10071, "MUIS primary"),
            new LegacyService(TunnelTransport.Tcp, 10072, "MUCG"),
            new LegacyService(TunnelTransport.Tcp, 10073, "DME control"),
            new LegacyService(TunnelTransport.Udp, 10073, "DME compatibility"),
            new LegacyService(TunnelTransport.Tcp, 10075, "Medius authentication"),
            new LegacyService(TunnelTransport.Tcp, 10076, "MUM"),
            new LegacyService(TunnelTransport.Tcp, 10077, "Medius proxy"),
            new LegacyService(TunnelTransport.Tcp, 10078, "Medius lobby"),
            new LegacyService(TunnelTransport.Tcp, 10079, "Medius matchmaking"),
            new LegacyService(TunnelTransport.Tcp, 10080, "MUIS secondary"),
            new LegacyService(TunnelTransport.Tcp, 10101, "MUIS compatibility"),
            new LegacyService(TunnelTransport.Tcp, 10471, "Medius profile"),
            new LegacyService(TunnelTransport.Udp, 10472, "Medius profile datagrams"),
            new LegacyService(TunnelTransport.Tcp, 10475, "Medius authentication compatibility"),
            new LegacyService(TunnelTransport.Udp, 50000, "DME race data"),
            new LegacyService(TunnelTransport.Udp, 50100, "Bandwidth probe")
        };

        public static IList<LegacyService> All { get { return Array.AsReadOnly(Services); } }
        public static bool IsAllowed(TunnelTransport transport, int port) { return Services.Any(x => x.Transport == transport && x.Port == port); }
        public static LegacyService Resolve(TunnelTransport transport, int port)
        {
            LegacyService[] matches = Services.Where(x => x.Transport == transport && x.Port == port).ToArray();
            if (matches.Length != 1) throw new UnauthorizedAccessException("The requested legacy service is not in the GT4 tunnel policy.");
            return matches[0];
        }
    }

    internal static class LegacyTunnelPolicySelfTest
    {
        public static int Run(string root)
        {
            var lines = new List<string> { "Gran Turismo Bulgaria legacy tunnel policy test " + DateTime.UtcNow.ToString("O") };
            bool unique = LegacyTunnelPolicy.All.GroupBy(x => x.Transport + ":" + x.Port).All(g => g.Count() == 1);
            bool expected = LegacyTunnelPolicy.IsAllowed(TunnelTransport.Tcp, 10075) && LegacyTunnelPolicy.IsAllowed(TunnelTransport.Udp, 50000);
            bool blocks = !LegacyTunnelPolicy.IsAllowed(TunnelTransport.Tcp, 22) && !LegacyTunnelPolicy.IsAllowed(TunnelTransport.Tcp, 445) && !LegacyTunnelPolicy.IsAllowed(TunnelTransport.Tcp, 3389) && !LegacyTunnelPolicy.IsAllowed(TunnelTransport.Udp, 53);
            lines.Add((unique ? "PASS " : "FAIL ") + "no duplicate service mappings");
            lines.Add((expected ? "PASS " : "FAIL ") + "required authentication and race services allowed");
            lines.Add((blocks ? "PASS " : "FAIL ") + "SSH, SMB, RDP and DNS are not tunnel destinations");
            bool throws = false; try { LegacyTunnelPolicy.Resolve(TunnelTransport.Tcp, 445); } catch (UnauthorizedAccessException) { throws = true; }
            lines.Add((throws ? "PASS " : "FAIL ") + "unknown destination fails closed");
            string logs = Path.Combine(root, "logs"); Directory.CreateDirectory(logs); File.WriteAllLines(Path.Combine(logs, "legacy-tunnel-policy-test.txt"), lines.ToArray(), new UTF8Encoding(false));
            return unique && expected && blocks && throws ? 0 : 1;
        }
    }
}
