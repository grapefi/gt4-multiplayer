$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$outputDir = Join-Path $projectRoot 'bundle'
New-Item -ItemType Directory -Force -Path $outputDir | Out-Null
$compiler = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$references = @(
  'System.dll',
  'System.Core.dll',
  'System.Drawing.dll',
  'System.Windows.Forms.dll',
  'System.Management.dll',
  'System.Security.dll',
  'System.IO.Compression.dll',
  'System.IO.Compression.FileSystem.dll'
)
$refArgs = $references | ForEach-Object { '/reference:' + $_ }
$exePath = Join-Path $outputDir 'Gran Turismo Bulgaria.exe'
$sourcePaths = Get-ChildItem -LiteralPath $PSScriptRoot -Filter '*.cs' -File |
  Where-Object { $_.Name -notin @('PacketBridge.cs', 'PacketBridgeSecure.cs', 'PacketBridgeAssemblyInfo.cs') } |
  Sort-Object Name |
  ForEach-Object { $_.FullName }
$manifestPath = Join-Path $PSScriptRoot 'app.manifest'
$outArg = '/out:' + $exePath
& $compiler /nologo /target:winexe /platform:x64 /optimize+ $outArg ('/win32manifest:' + $manifestPath) @refArgs @sourcePaths
if ($LASTEXITCODE -ne 0) { throw "C# compiler failed with exit code $LASTEXITCODE" }
$bridgePath = Join-Path $outputDir 'GT4PacketBridge.exe'
& $compiler /nologo /target:winexe /platform:x64 /optimize+ ('/out:' + $bridgePath) ('/win32manifest:' + (Join-Path $PSScriptRoot 'packet-bridge.manifest')) /reference:System.dll /reference:System.Core.dll /reference:System.IO.Compression.dll /reference:System.IO.Compression.FileSystem.dll (Join-Path $PSScriptRoot 'PacketBridgeSecure.cs') (Join-Path $PSScriptRoot 'PacketBridgeAssemblyInfo.cs')
if ($LASTEXITCODE -ne 0) { throw "Packet bridge compiler failed with exit code $LASTEXITCODE" }
Write-Output (Join-Path $outputDir 'Gran Turismo Bulgaria.exe')
