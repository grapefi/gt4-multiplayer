using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Compression;
using System.IO.Pipes;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

namespace GT4Together
{
    internal static class Program
    {
        private static Mutex _guiInstanceMutex;
        [STAThread]
        private static void Main(string[] args)
        {
            try
            {
                if (!IsSupportedWindows11())
                {
                    MessageBox.Show("Gran Turismo Bulgaria requires 64-bit Windows 11 (build 22000 or newer).", "Windows 11 required", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Environment.ExitCode = 1;
                    return;
                }
                if (args.Any(a => string.Equals(a, "--self-test", StringComparison.OrdinalIgnoreCase)))
                {
                    Environment.ExitCode = SelfTest.Run(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar));
                    return;
                }
                if (args.Any(a => string.Equals(a, "--multi-instance-test", StringComparison.OrdinalIgnoreCase)))
                {
                    Environment.ExitCode = MultiInstanceTest.Run(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar));
                    return;
                }
                if (args.Any(a => string.Equals(a, "--network-self-test", StringComparison.OrdinalIgnoreCase)))
                {
                    Environment.ExitCode = PrivateSessionSelfTest.Run(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar));
                    return;
                }
                if (args.Any(a => string.Equals(a, "--connection-transport-self-test", StringComparison.OrdinalIgnoreCase)))
                {
                    Environment.ExitCode = ConnectionTransportSelfTest.Run(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar));
                    return;
                }
                if (args.Any(a => string.Equals(a, "--zerotier-self-test", StringComparison.OrdinalIgnoreCase)))
                {
                    Environment.ExitCode = ZeroTierManagerSelfTest.Run(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar));
                    return;
                }
                if (args.Any(a => string.Equals(a, "--controller-self-test", StringComparison.OrdinalIgnoreCase)))
                {
                    Environment.ExitCode = ControllerConfigurationSelfTest.Run(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar));
                    return;
                }
                if (args.Any(a => string.Equals(a, "--two-app-online-test", StringComparison.OrdinalIgnoreCase)))
                {
                    Environment.ExitCode = TwoAppOnlineTest.Run(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar));
                    return;
                }
                if (args.Any(a => string.Equals(a, "--four-app-online-test", StringComparison.OrdinalIgnoreCase)))
                {
                    Environment.ExitCode = FourAppOnlineTest.Run(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar));
                    return;
                }
                if (args.Any(a => string.Equals(a, "--campaign-self-test", StringComparison.OrdinalIgnoreCase)))
                {
                    Environment.ExitCode = SharedCampaignSelfTest.Run(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar));
                    return;
                }
                if (args.Any(a => string.Equals(a, "--coop-engine-self-test", StringComparison.OrdinalIgnoreCase)))
                {
                    Environment.ExitCode = CoopCampaignSelfTest.Run(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar));
                    return;
                }
                if (args.Any(a => string.Equals(a, "--legacy-tunnel-policy-test", StringComparison.OrdinalIgnoreCase)))
                {
                    Environment.ExitCode = LegacyTunnelPolicySelfTest.Run(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar));
                    return;
                }
                if (args.Any(a => string.Equals(a, "--beta-backend-self-test", StringComparison.OrdinalIgnoreCase)))
                {
                    Environment.ExitCode = BetaBackendManager.SelfTest(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar));
                    return;
                }
                if (args.Any(a => string.Equals(a, "--gt4-hook-self-test", StringComparison.OrdinalIgnoreCase)))
                {
                    Environment.ExitCode = Gt4HookSelfTest.Run(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar));
                    return;
                }
                if (args.Any(a => string.Equals(a, "--gt4-beta-hook-self-test", StringComparison.OrdinalIgnoreCase)))
                {
                    Environment.ExitCode = Gt4BetaHookSelfTest.Run(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar), false);
                    return;
                }
                if (args.Any(a => string.Equals(a, "--gt4-beta-hook-manifest-test", StringComparison.OrdinalIgnoreCase)))
                {
                    Environment.ExitCode = Gt4BetaHookManifest.SelfTest(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar));
                    return;
                }
                if (args.Any(a => string.Equals(a, "--gt4-beta-memory-dump", StringComparison.OrdinalIgnoreCase)))
                {
                    Environment.ExitCode = Gt4BetaHookSelfTest.Run(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar), true);
                    return;
                }
                int nodeIndex = Array.FindIndex(args, a => string.Equals(a, "--online-test-node", StringComparison.OrdinalIgnoreCase));
                if (nodeIndex >= 0 && args.Length > nodeIndex + 2)
                {
                    Environment.ExitCode = TwoAppOnlineTest.RunNode(args[nodeIndex + 1], args[nodeIndex + 2]);
                    return;
                }
                int fourNodeIndex = Array.FindIndex(args, a => string.Equals(a, "--four-app-test-node", StringComparison.OrdinalIgnoreCase));
                if (fourNodeIndex >= 0 && args.Length > fourNodeIndex + 2)
                {
                    Environment.ExitCode = FourAppOnlineTest.RunNode(args[fourNodeIndex + 1], args[fourNodeIndex + 2]);
                    return;
                }
                bool firstInstance;
                _guiInstanceMutex = new Mutex(true, SingleInstanceGuard.NameFor(AppDomain.CurrentDomain.BaseDirectory), out firstInstance);
                if (!firstInstance)
                {
                    MessageBox.Show("Gran Turismo Bulgaria is already running from this installation. Use the existing launcher window so two PCSX2 processes cannot open the same memory card or control port.", "Already running", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new LauncherForm());
            }
            catch (Exception ex)
            {
                try
                {
                    string logs = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs");
                    Directory.CreateDirectory(logs);
                    string safeMessage = Regex.Replace(ex.Message ?? "", @"(?i)(?:LAN|BETA)\|[^\s]+|(?:[A-Za-z0-9_-]{40,})", "<REDACTED>");
                    safeMessage = safeMessage.Replace(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "<USER>");
                    File.AppendAllText(Path.Combine(logs, "crash.log"), DateTime.Now.ToString("O") + " " + ex.GetType().FullName + ": " + safeMessage + Environment.NewLine, new UTF8Encoding(false));
                }
                catch { }
                MessageBox.Show("Gran Turismo Bulgaria could not start. A crash report was saved in the logs folder.\n\n" + ex.Message, "Launcher error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static bool IsSupportedWindows11()
        {
            Version version = Environment.OSVersion.Version;
            return Environment.OSVersion.Platform == PlatformID.Win32NT && Environment.Is64BitOperatingSystem && version.Major >= 10 && version.Build >= 22000;
        }
    }

    internal static class ReleaseIntegrity
    {
        private const string TrustedPublicKeySha256 = "bf95c8243a0a4fc955352445e584e917214919d775f342e59e3451a3565c6f0a";
        private static readonly object Sync = new object();
        private static string _cachedRoot;
        private static Dictionary<string, string> _cachedHashes;

        public static void VerifyShippedFile(string root, string relative)
        {
            root = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar);
            Dictionary<string, string> hashes;
            lock (Sync)
            {
                if (_cachedHashes == null || !string.Equals(_cachedRoot, root, StringComparison.OrdinalIgnoreCase))
                {
                    _cachedHashes = LoadAndVerifyManifest(root);
                    _cachedRoot = root;
                }
                hashes = _cachedHashes;
            }
            string expected;
            string normalized = relative.Replace('\\', '/');
            if (!hashes.TryGetValue(normalized, out expected)) throw new CryptographicException("The signed release does not authorize " + normalized + ". Reinstall or apply the latest signed offline update.");
            string path = SafePath(root, normalized);
            if (!File.Exists(path) || !Fixed(Hash(path), expected)) throw new CryptographicException("A protected program component failed integrity verification: " + normalized);
        }

        private static Dictionary<string, string> LoadAndVerifyManifest(string root)
        {
            string manifestPath = Path.Combine(root, "release.manifest"), signaturePath = Path.Combine(root, "release.sig"), publicPath = Path.Combine(root, "release.public.xml");
            if (!File.Exists(manifestPath) || !File.Exists(signaturePath) || !File.Exists(publicPath)) throw new CryptographicException("Signed release metadata is missing. Reinstall or apply the latest signed offline update.");
            if (!Fixed(Hash(publicPath), TrustedPublicKeySha256)) throw new CryptographicException("The release verification key is not trusted.");
            byte[] manifest = File.ReadAllBytes(manifestPath); if (manifest.Length > 4 * 1024 * 1024) throw new InvalidDataException("Release manifest is too large.");
            byte[] signature = Convert.FromBase64String(File.ReadAllText(signaturePath, Encoding.UTF8).Trim());
            using (var rsa = new RSACryptoServiceProvider())
            {
                rsa.PersistKeyInCsp = false; rsa.FromXmlString(File.ReadAllText(publicPath, Encoding.UTF8));
                if (rsa.KeySize < 3072 || !rsa.VerifyData(manifest, CryptoConfig.MapNameToOID("SHA256"), signature)) throw new CryptographicException("The signed release manifest is invalid.");
            }
            var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            string[] lines = Encoding.UTF8.GetString(manifest).Replace("\r", "").Split('\n');
            if (lines.Length < 3 || lines[0] != "GTB-RELEASE-MANIFEST-V1") throw new InvalidDataException("Release manifest header is invalid.");
            for (int i = 2; i < lines.Length; i++)
            {
                if (lines[i].Length == 0) continue;
                string[] fields = lines[i].Split('\t');
                if (fields.Length != 4 || fields[0] != "F" || !Regex.IsMatch(fields[3], "^[a-f0-9]{64}$")) throw new InvalidDataException("Release manifest entry is invalid.");
                string relative = Encoding.UTF8.GetString(Convert.FromBase64String(fields[1])).Replace('\\', '/');
                SafePath(root, relative);
                if (result.ContainsKey(relative)) throw new InvalidDataException("Release manifest contains a duplicate path.");
                result.Add(relative, fields[3]);
            }
            return result;
        }

        private static string SafePath(string root, string relative)
        {
            if (string.IsNullOrWhiteSpace(relative) || Path.IsPathRooted(relative) || relative.IndexOf(':') >= 0 || relative.Split('/', '\\').Any(x => x.Length == 0 || x == "..")) throw new InvalidDataException("Unsafe release path.");
            string prefix = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string path = Path.GetFullPath(Path.Combine(prefix, relative.Replace('/', Path.DirectorySeparatorChar)));
            if (!path.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Release path leaves the application folder.");
            return path;
        }

        private static string Hash(string path) { using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read)) using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", "").ToLowerInvariant(); }
        private static bool Fixed(string a, string b) { if (a == null || b == null || a.Length != b.Length) return false; int d = 0; for (int i = 0; i < a.Length; i++) d |= a[i] ^ b[i]; return d == 0; }
    }

    internal static class MultiInstanceTest
    {
        public static int Run(string root)
        {
            var report = new List<string> { "Gran Turismo Bulgaria two-instance test " + DateTime.Now.ToString("O") };
            var processes = new List<Process>();
            bool ok = true;
            try
            {
                string lanPcsx2 = Path.Combine(root, "runtime", "pcsx2-lan", "pcsx2-qtx64.exe");
                string pcsx2 = TestAsset("GTB_TEST_PCSX2", File.Exists(lanPcsx2) ? lanPcsx2 : Path.Combine(root, "runtime", "pcsx2", "pcsx2-qt.exe"));
                string iso = TestAsset("GTB_TEST_ISO", Path.Combine(root, "game", UnifiedDisc.FileName));
                if (!File.Exists(pcsx2) || !File.Exists(iso)) throw new FileNotFoundException("PCSX2 or GT4 image is missing.");
                for (int player = 1; player <= 2; player++)
                {
                    string data = Prepare(root, player);
                    string args = "-datapath \"" + data + "\" -batch -nofullscreen -fastboot -- \"" + iso + "\"";
                    var process = Process.Start(new ProcessStartInfo(pcsx2, args) { WorkingDirectory = Path.GetDirectoryName(pcsx2), UseShellExecute = false });
                    processes.Add(process); report.Add("START player " + player + " PID " + process.Id);
                    Thread.Sleep(900);
                }
                Thread.Sleep(14000);
                for (int i = 0; i < processes.Count; i++)
                {
                    bool alive = !processes[i].HasExited;
                    string log = Path.Combine(root, "data", "player" + (i + 1), "PCSX2", "logs", "emulog.txt");
                    bool logged = File.Exists(log) && new FileInfo(log).Length > 0;
                    report.Add((alive && logged ? "PASS " : "FAIL ") + "player " + (i + 1) + " alive=" + alive + " separateLog=" + logged);
                    ok &= alive && logged;
                    try { using (var pine = new PineClient(28011 + i, 1500)) { UnifiedDisc.VerifyBuild(pine); report.Add("PASS player " + (i + 1) + " isolated PINE identity"); } }
                    catch (Exception ex) { ok = false; report.Add("FAIL player " + (i + 1) + " PINE: " + ex.Message); }
                }
            }
            catch (Exception ex) { ok = false; report.Add("FAIL " + ex); }
            finally
            {
                foreach (var process in processes)
                {
                    try { if (!process.HasExited) { process.CloseMainWindow(); if (!process.WaitForExit(2500)) process.Kill(); } } catch { }
                }
            }
            report.Add(ok ? "RESULT PASS" : "RESULT FAIL");
            string logs = Path.Combine(root, "logs"); Directory.CreateDirectory(logs);
            File.WriteAllLines(Path.Combine(logs, "multi-instance-test.txt"), report.ToArray(), new UTF8Encoding(false));
            return ok ? 0 : 1;
        }

        private static string Prepare(string root, int player)
        {
            string data = Path.Combine(root, "data", "player" + player);
            string app = Path.Combine(data, "PCSX2");
            string bios = Path.Combine(app, "bios"); Directory.CreateDirectory(bios);
            string biosSource = TestAsset("GTB_TEST_BIOS_DIR", Path.Combine(root, "private", "bios"));
            foreach (string source in Directory.GetFiles(biosSource))
                File.Copy(source, Path.Combine(bios, Path.GetFileName(source)), true);
            if (player > 1)
            {
                string playerOne = Path.Combine(root, "data", "player1", "PCSX2");
                foreach (string file in Directory.GetFiles(playerOne, "*.ini", SearchOption.AllDirectories))
                {
                    string relative = file.Substring(playerOne.Length).TrimStart(Path.DirectorySeparatorChar);
                    string destination = Path.Combine(app, relative); Directory.CreateDirectory(Path.GetDirectoryName(destination));
                    string text = File.ReadAllText(file).Replace("SDL-0", "SDL-1").Replace("XInput-0", "XInput-1");
                    File.WriteAllText(destination, text, new UTF8Encoding(false));
                }
            }
            LauncherForm.ApplyNetworkSettingsForTest(app);
            string mainIni = Path.Combine(app, "inis", "PCSX2.ini");
            if (File.Exists(mainIni))
            {
                string text = File.ReadAllText(mainIni); text = IniEditor.Set(text, "SetupWizardIncomplete", "false"); text = IniEditor.Set(text, "BIOS", "ps2-bios.bin"); text = IniEditor.Set(text, "EnablePINE", "true"); text = IniEditor.Set(text, "PINESlot", (28010 + player).ToString());
                File.WriteAllText(mainIni, text, new UTF8Encoding(false));
            }
            return data;
        }

        internal static string TestAsset(string variable, string fallback)
        {
            string value = Environment.GetEnvironmentVariable(variable);
            return string.IsNullOrWhiteSpace(value) ? fallback : Path.GetFullPath(value);
        }
    }

    internal static class SelfTest
    {
        public static int Run(string root)
        {
            var lines = new List<string>();
            bool ok = true;
            Action<string, bool> check = delegate(string name, bool passed) { lines.Add((passed ? "PASS " : "FAIL ") + name); if (!passed) ok = false; };
            try
            {
                string lanPcsx2 = Path.Combine(root, "runtime", "pcsx2-lan", "pcsx2-qtx64.exe");
                string pcsx2 = File.Exists(lanPcsx2) ? lanPcsx2 : Path.Combine(root, "runtime", "pcsx2", "pcsx2-qt.exe");
                string iso = Path.Combine(root, "game", UnifiedDisc.FileName);
                string bios = Path.Combine(root, "private", "bios", "ps2-bios.bin");
                check("PCSX2 runtime", File.Exists(pcsx2));
                check("PCSX2 LAN-hosting build", File.Exists(lanPcsx2));
                check("GT4 image", File.Exists(iso) && new FileInfo(iso).Length > 1024L * 1024 * 1024);
                check("PS2 BIOS", File.Exists(bios) && new FileInfo(bios).Length == 4194304);
                check("64-bit Windows 11 runtime", Environment.OSVersion.Platform == PlatformID.Win32NT && Environment.Is64BitOperatingSystem && Environment.Is64BitProcess && Environment.OSVersion.Version.Build >= 22000);
                check("per-install duplicate-launch guard", SingleInstanceGuard.SelfTest(root));
                lines.Add("INFO Windows 11 build: " + Environment.OSVersion.Version + ".");
                var hardware = HardwareProbe.Detect(); lines.Add("INFO Hardware: " + hardware.Summary);
                string networkDevice = NetworkAdapterProbe.Pcsx2Device();
                check("PCSX2 network adapter selection", !string.Equals(networkDevice, "Auto", StringComparison.OrdinalIgnoreCase));
                lines.Add("INFO PCSX2 network device: " + networkDevice + ".");
                foreach (ConnectionTransport transport in Enum.GetValues(typeof(ConnectionTransport)))
                {
                    ConnectionProfile provider = NetworkAdapterProbe.Detect(transport);
                    lines.Add("INFO Connection " + transport + ": available=" + provider.Available + ", resolved=" + provider.Resolved + ", adapter=" + provider.AdapterGuid + ", address=" + (provider.IPv4 ?? "none") + ".");
                }
                var graphics = GraphicsOptions.LoadOrDetect(root).ResolveAuto();
                check("Auto graphics scale", graphics.Scale >= 1 && graphics.Scale <= 8);
                check("UI scale explicit 150%", Math.Abs(UiScaleManager.Resolve(150, new Rectangle(0, 0, 1920, 1080), 1F) - 1.5F) < 0.01F);
                check("UI scale auto 1080p", Math.Abs(UiScaleManager.Resolve(0, new Rectangle(0, 0, 1920, 1040), 1F) - 1.25F) < 0.01F);
                check("UI scale auto 720p preserves home", Math.Abs(UiScaleManager.Resolve(0, new Rectangle(0, 0, 1280, 680), 1F) - 1F) < 0.01F);
                string sample = "[EmuCore/GS]\r\nRenderer = -1\r\nupscale_multiplier = 1\r\n";
                sample = IniEditor.Set(sample, "Renderer", "14"); sample = IniEditor.Set(sample, "upscale_multiplier", "4");
                check("INI renderer write", sample.Contains("Renderer = 14"));
                check("INI resolution write", sample.Contains("upscale_multiplier = 4"));
                string betaNetworkTest = Path.Combine(root, "logs", "self-test-beta-network-" + Guid.NewGuid().ToString("N"));
                string betaNetworkIni = Path.Combine(betaNetworkTest, "inis", "PCSX2.ini");
                Directory.CreateDirectory(Path.GetDirectoryName(betaNetworkIni));
                File.WriteAllText(betaNetworkIni, "[DEV9/Eth]\r\n", new UTF8Encoding(false));
                LauncherForm.ApplyBetaNetworkSettingsForTest(betaNetworkTest, "10.147.20.30");
                string betaNetworkText = File.ReadAllText(betaNetworkIni);
                check("Online Beta binds sockets to selected session adapter", betaNetworkText.Contains("EthApi = Sockets") && betaNetworkText.Contains("EthDevice = {11111111-2222-3333-4444-555555555555}"));
                check("Online Beta uses PCSX2 internal DNS", betaNetworkText.Contains("ModeDNS1 = Internal") && betaNetworkText.Contains("DNS1 = 192.0.2.1"));
                check("Online Beta DNS fallback remains automatic", betaNetworkText.Contains("ModeDNS2 = Auto") && betaNetworkText.Contains("DNS2 = 0.0.0.0"));
                string peerSection = Regex.Match(betaNetworkText, @"(?ms)^\[DEV9/Eth/Ports/Port0\]\r?\n(.*?)(?=^\[|\z)").Groups[1].Value;
                string peerList = Regex.Match(betaNetworkText, @"(?ms)^\[DEV9/Eth/Ports\]\r?\n(.*?)(?=^\[|\z)").Groups[1].Value;
                check("Online Beta peer UDP port", peerSection.Contains("Port = 6000") && peerSection.Contains("Protocol = UDP") && peerSection.Contains("Enabled = true") && peerList.Contains("Count = 1"));
                check("Online Beta normal-speed safety", betaNetworkText.Contains("EECycleRate = 0") && betaNetworkText.Contains("EECycleSkip = 0") && betaNetworkText.Contains("FramerateNTSC = 59.94") && betaNetworkText.Contains("NominalScalar = 1"));
                check("Online Beta private server mappings", betaNetworkText.Contains("gt4-pubeta.svo.pdonline.scea.com") && betaNetworkText.Contains("gt4-pubeta.muis.pdonline.scea.com") && betaNetworkText.Contains("gate1.us.dnas.playstation.org") && betaNetworkText.Contains("Address = 10.147.20.30"));
                try { Directory.Delete(betaNetworkTest, true); } catch { }
                string exactInterface = Path.Combine(root, "assets", "launcher-interface-exact.png");
                check("Exact launcher interface", File.Exists(exactInterface));
                if (File.Exists(exactInterface))
                {
                    using (var artwork = Image.FromFile(exactInterface))
                        check("Exact interface dimensions 1655x950", artwork.Width == 1655 && artwork.Height == 950);
                    check("Exact interface SHA-256", LauncherForm.SafeHashForSelfTest(exactInterface) == "292b93bbdba21f7885c94a9738ad60293cefd0cd92b9b45944e48acc99c61c32");
                    using (var launcher = new LauncherForm())
                    {
                        check("All exact-interface buttons mapped", launcher.HasValidExactInterfaceLayout);
                        check("Remote Desktop minimize control on in-app pages", launcher.HasRemotePageMinimizeControlForSelfTest());
                    }
                }
            }
            catch (Exception ex) { ok = false; lines.Add("FAIL Exception: " + ex); }
            lines.Insert(0, "Gran Turismo Bulgaria self-test " + DateTime.Now.ToString("O"));
            lines.Add(ok ? "RESULT PASS" : "RESULT FAIL");
            string logs = Path.Combine(root, "logs"); Directory.CreateDirectory(logs);
            File.WriteAllLines(Path.Combine(logs, "self-test.txt"), lines.ToArray(), new UTF8Encoding(false));
            return ok ? 0 : 1;
        }
    }

    internal static class SingleInstanceGuard
    {
        public static string NameFor(string root)
        {
            using (var sha = SHA256.Create()) return "Local\\GranTurismoBulgaria-" + BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes((root ?? "").TrimEnd('\\', '/').ToLowerInvariant()))).Replace("-", "").Substring(0, 20);
        }
        public static bool SelfTest(string root)
        {
            string name = NameFor(root + "-self-test-" + Guid.NewGuid().ToString("N")); bool first, second;
            using (var one = new Mutex(true, name, out first)) using (var two = new Mutex(true, name, out second)) return first && !second;
        }
    }

    internal enum OnlineEngineMode { OnlineBetaMedius }
    internal enum SessionEntryMode { Host, Join, Manage }
    internal enum ConnectionTransport { PhysicalLan, ZeroTier }

    internal sealed class ConnectionProfile
    {
        public ConnectionTransport Requested;
        public ConnectionTransport Resolved;
        public string DisplayName;
        public bool Available;
        public string AdapterGuid;
        public string IPv4;
        public string Diagnostic;
        public bool UsesPrivateOverlay
        {
            get { return Resolved == ConnectionTransport.ZeroTier; }
        }
        public bool UsesDirectPublicPort
        {
            get { return false; }
        }
    }

    internal static class UnifiedDisc
    {
        internal const string FileName = "Gran Turismo 4 (USA) (Online Public Beta).iso";
        internal const string GameId = "SCUS-97436";
        internal const string Crc = "32a1c752";
        internal const string Version = "1.00";
        internal const long ExactLength = 2654109696L;
        internal const string CompatibilityFingerprint = "5a91f177086e8d3ae2a01eb05047bc0aa6505c5b25c8d8a561f8e373544d5c67";

        internal static void VerifyImage(string path)
        {
            if (!File.Exists(path) || new FileInfo(path).Length != ExactLength)
                throw new InvalidDataException("Online multiplayer requires the verified Gran Turismo 4 Online Public Beta image.");
            string actual = LauncherForm.QuickFingerprintForCompatibility(path);
            if (!string.Equals(actual, CompatibilityFingerprint, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("The Online Public Beta image does not match the verified SCUS-97436 build. Restore the known-good image before playing online.");
        }

        internal static void VerifyBuild(PineClient pine)
        {
            string id = pine.GameId, crc = pine.Crc, version = pine.GameVersion;
            if (!string.Equals(id, GameId, StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(crc, Crc, StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(version, Version, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Gran Turismo Bulgaria disc safety lock refused " + id + " / " + crc + " / " + version + ".");
        }
    }

    internal sealed class LauncherForm : Form
    {
        internal const string BuildVersion = "0.18.30-open-source";
        private readonly string _root = AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
        private readonly string _logPath;
        private readonly List<Process> _gameProcesses = new List<Process>();
        private readonly List<Gt4RuntimeMonitor> _gt4Monitors = new List<Gt4RuntimeMonitor>();
        private readonly Label _systemStatus = NewLabel(11, FontStyle.Bold, Color.White);
        private readonly Label _controllerStatus = NewLabel(11, FontStyle.Regular, Color.FromArgb(210, 220, 228));
        private readonly Label _sessionStatus = NewLabel(10, FontStyle.Regular, Color.FromArgb(185, 195, 204));
        private readonly Label _clock = NewLabel(10, FontStyle.Regular, Color.FromArgb(210, 215, 220));
        private readonly ComboBox _localPlayers = new ComboBox();
        private readonly ComboBox _connectionSelector = new ComboBox();
        private readonly Label _connectionState = NewLabel(8.5F, FontStyle.Regular, Color.FromArgb(188, 207, 217));
        private readonly Panel _connectionPanel = new Panel();
        private readonly Button _zeroTierSetupButton = new Button();
        private readonly FlowLayoutPanel _controllerList = new FlowLayoutPanel();
        private readonly System.Windows.Forms.Timer _clockTimer = new System.Windows.Forms.Timer();
        private readonly System.Windows.Forms.Timer _controllerNavigationTimer = new System.Windows.Forms.Timer();
        private readonly System.Windows.Forms.Timer _controllerHotplugTimer = new System.Windows.Forms.Timer();
        private readonly Button _playButton;
        private readonly Button _setupButton;
        private readonly ExactInterfaceSurface _referenceSurface;
        private readonly Label _graphicsSummary = NewLabel(9, FontStyle.Regular, Color.FromArgb(190, 205, 214));
        private GraphicsOptions _graphics;
        private int _detectedControllerCount;
        private bool _scanning;
        private bool _coopCampaign;
        private CampaignInfo _activeCampaign;
        private PrivateSessionService _networkSession;
        private OnlineEngineMode _onlineMode = OnlineEngineMode.OnlineBetaMedius;
        internal static readonly ConnectionTransport[] VisibleConnectionTransports =
        {
            ConnectionTransport.ZeroTier,
            ConnectionTransport.PhysicalLan
        };
        internal static int VisibleConnectionIndex(ConnectionTransport transport)
        {
            return Array.IndexOf(VisibleConnectionTransports, transport);
        }
        private ConnectionTransport _connectionTransport = ConnectionTransport.ZeroTier;
        private ConnectionProfile _connectionProfile;
        private BetaBackendManager _betaBackend;
        private readonly ManualResetEvent _onlineHostReady = new ManualResetEvent(false);
        private volatile bool _onlineBackendReady;
        private readonly ushort[] _controllerButtonStates = new ushort[4];
        private string _controllerSignature = string.Empty;
        private Panel _pageHost;
        private Form _activePage;
        private bool _launcherFullscreen = true;
        private float _effectiveUiScale = 1F;

        private string Pcsx2Exe
        {
            get
            {
                string lanBuild = Path.Combine(_root, "runtime", "pcsx2-lan", "pcsx2-qtx64.exe");
                return File.Exists(lanBuild) ? lanBuild : Path.Combine(_root, "runtime", "pcsx2", "pcsx2-qt.exe");
            }
        }
        private string GameIso { get { return Path.Combine(_root, "game", UnifiedDisc.FileName); } }
        private string LaunchIso { get { return GameIso; } }
        private string BiosSource { get { return Path.Combine(_root, "private", "bios"); } }
        private string DataRoot { get { return Path.Combine(_root, "data"); } }
        internal bool HasValidExactInterfaceLayout { get { return _referenceSurface != null && _referenceSurface.HasValidLayout; } }

        public LauncherForm()
        {
            _logPath = Path.Combine(_root, "logs", "launcher.log");
            Directory.CreateDirectory(Path.GetDirectoryName(_logPath));
            Text = "Gran Turismo Bulgaria — v" + BuildVersion;
            ClientSize = new Size(1280, 720);
            MinimumSize = new Size(1100, 650);
            StartPosition = FormStartPosition.CenterScreen;
            SetLauncherWindowMode(true);
            KeyPreview = true;
            BackColor = Color.FromArgb(8, 12, 16);
            ForeColor = Color.White;
            Font = new Font("Segoe UI", 10F);
            DoubleBuffered = true;
            _systemStatus.Text = "Checking local installation…";
            _controllerStatus.Text = "Scanning controllers…";
            _graphicsSummary.Text = "Detecting the best graphics profile…";

            // These state controls are intentionally not painted. The supplied reference PNG is
            // the complete interface; image-coordinate hotspots invoke the existing functionality.
            _localPlayers.Items.AddRange(new object[] { "1 driver", "2 drivers", "3 drivers", "4 drivers" });
            _localPlayers.SelectedIndex = 0;
            _localPlayers.SelectedIndexChanged += delegate { RefreshReadiness(); };
            _playButton = new Button();
            _playButton.Click += async delegate { await LaunchGameAsync(); };
            _setupButton = new Button();
            _setupButton.Click += delegate { OpenGraphicsSettings(); };

            string exactInterface = Path.Combine(_root, "assets", "launcher-interface-exact.png");
            _referenceSurface = new ExactInterfaceSurface(exactInterface) { Dock = DockStyle.Fill };
            Controls.Add(_referenceSurface);
            BuildConnectionSelector();

            Action play = async delegate { await LaunchGameAsync(); };
            _referenceSurface.AddHotspot("LAUNCH SINGLE PLAYER", new Rectangle(57, 253, 511, 73), delegate { _coopCampaign = false; play(); });
            _referenceSurface.AddHotspot("HOST MATCH", new Rectangle(57, 338, 499, 71), delegate { OpenPrivateSession(SessionEntryMode.Host); });
            _referenceSurface.AddHotspot("JOIN MATCH", new Rectangle(57, 422, 499, 73), delegate { OpenPrivateSession(SessionEntryMode.Join); });
            _referenceSurface.AddHotspot("OPTIONS", new Rectangle(57, 505, 499, 71), delegate { OpenLauncherOptions(); });
            _referenceSurface.AddHotspot("PREVIOUS CONNECTION", new Rectangle(80, 626, 48, 40), delegate { CycleConnectionTransport(-1); });
            _referenceSurface.AddHotspot("NEXT CONNECTION", new Rectangle(474, 626, 49, 40), delegate { CycleConnectionTransport(1); });
            _referenceSurface.AddHotspot("CONNECTION TYPE", new Rectangle(128, 626, 346, 40), delegate { if (_connectionTransport == ConnectionTransport.ZeroTier) OpenZeroTierSetup(); else CycleConnectionTransport(1); });
            _referenceSurface.AddHotspot("EMULATOR", new Rectangle(63, 716, 151, 39), delegate { LaunchSetup(); });
            _referenceSurface.AddHotspot("GRAPHICS", new Rectangle(224, 716, 150, 39), delegate { OpenGraphicsSettings(); });
            _referenceSurface.AddHotspot("SUPPORT ZIP", new Rectangle(383, 716, 160, 39), delegate { ExportSupportBundle(); });
            _referenceSurface.AddHotspot("MINIMIZE APP", new Rectangle(958, 876, 176, 45), delegate { MinimizeLauncher(); });
            _referenceSurface.AddHotspot("MINIMIZE PCSX2", new Rectangle(1144, 876, 201, 45), delegate { MinimizeGameWindows(); });
            _referenceSurface.AddHotspot("OK", new Rectangle(65, 873, 120, 65), delegate { _referenceSurface.ActivateSelected(); }, false);
            _referenceSurface.AddHotspot("BACK", new Rectangle(207, 873, 132, 65), delegate { Close(); }, false);
            _referenceSurface.AddHotspot("SELECT", new Rectangle(384, 873, 150, 65), delegate { _referenceSurface.ActivateSelected(); }, false);

            _controllerNavigationTimer.Interval = 90;
            _controllerNavigationTimer.Tick += delegate { PollLauncherController(); };
            _controllerNavigationTimer.Start();
            _controllerHotplugTimer.Interval = 1500;
            _controllerHotplugTimer.Tick += async delegate { await ScanControllersAsync(false); };
            _controllerHotplugTimer.Start();
            _clockTimer.Interval = 1000;
            _clockTimer.Tick += delegate { _referenceSurface.SetClock(DateTime.Now.ToString("HH:mm")); };
            _clockTimer.Start();
            _referenceSurface.SetClock(DateTime.Now.ToString("HH:mm"));

            KeyDown += delegate(object sender, KeyEventArgs e)
            {
                if (e.KeyCode == Keys.F11 || (e.KeyCode == Keys.Enter && e.Alt)) { SetLauncherWindowMode(!_launcherFullscreen); e.Handled = true; }
                else if (e.KeyCode == Keys.Escape) { MenuAudio.PlayBack(); if (_activePage != null) _activePage.Close(); else Close(); }
                else if (e.KeyCode == Keys.Up || e.KeyCode == Keys.Left) { _referenceSurface.MoveSelection(-1); e.Handled = true; }
                else if (e.KeyCode == Keys.Down || e.KeyCode == Keys.Right) { _referenceSurface.MoveSelection(1); e.Handled = true; }
                else if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Space) { _referenceSurface.ActivateSelected(); e.Handled = true; }
            };

            FormClosing += delegate { _clockTimer.Stop(); _controllerHotplugTimer.Stop(); _controllerNavigationTimer.Stop(); StopTrackedProcesses(); if (_networkSession != null) _networkSession.Dispose(); if (_betaBackend != null) _betaBackend.Dispose(); };
            Shown += async delegate
            {
                Log("Launcher started. Build " + BuildVersion);
                _graphics = GraphicsOptions.LoadOrDetect(_root);
                RefreshUiScale();
                LoadConnectionTransport();
                MenuAudio.Volume = _graphics.MenuVolume;
                UpdateGraphicsSummary();
                ValidateInstallation();
                await ScanControllersAsync();
                _referenceSurface.Focus();
            };
        }

        private void BuildConnectionSelector()
        {
            // The supplied artwork owns the visible home layout. This hidden selector keeps the
            // existing transport model and events while ExactInterfaceSurface paints live values.
            _connectionPanel.Size = new Size(520, 150);
            _connectionPanel.BackColor = Color.FromArgb(24, 31, 38);
            _connectionPanel.BorderStyle = BorderStyle.FixedSingle;
            _connectionPanel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            var caption = NewLabel(8, FontStyle.Bold, Color.FromArgb(235, 77, 86));
            caption.Name = "ConnectionCaption"; caption.Text = "CONNECTION TYPE"; caption.AutoSize = true; caption.Location = new Point(18, 10); _connectionPanel.Controls.Add(caption);
            _connectionSelector.DropDownStyle = ComboBoxStyle.DropDownList;
            _connectionSelector.FlatStyle = FlatStyle.Flat;
            _connectionSelector.BackColor = Color.FromArgb(39, 50, 59);
            _connectionSelector.ForeColor = Color.White;
            _connectionSelector.Font = new Font("Segoe UI Semibold", 15F);
            _connectionSelector.Location = new Point(18, 34); _connectionSelector.Size = new Size(484, 42);
            foreach (ConnectionTransport transport in VisibleConnectionTransports) _connectionSelector.Items.Add(NetworkAdapterProbe.DisplayName(transport));
            _connectionSelector.SelectedIndexChanged += delegate
            {
                if (_connectionSelector.SelectedIndex < 0) return;
                _connectionTransport = VisibleConnectionTransports[_connectionSelector.SelectedIndex];
                RefreshConnectionProfile(true);
            };
            _connectionPanel.Controls.Add(_connectionSelector);
            _connectionState.AutoSize = false; _connectionState.Location = new Point(18, 82); _connectionState.Size = new Size(484, 58); _connectionState.Font = new Font("Segoe UI", 11.5F); _connectionPanel.Controls.Add(_connectionState);
            _zeroTierSetupButton.Text = "ZEROTIER NETWORKS"; _zeroTierSetupButton.FlatStyle = FlatStyle.Flat; _zeroTierSetupButton.FlatAppearance.BorderColor = Color.FromArgb(118, 142, 157);
            _zeroTierSetupButton.BackColor = Color.FromArgb(35, 54, 67); _zeroTierSetupButton.ForeColor = Color.White; _zeroTierSetupButton.Font = new Font("Segoe UI Semibold", 10F);
            _zeroTierSetupButton.Location = new Point(18, 147); _zeroTierSetupButton.Size = new Size(484, 40); _zeroTierSetupButton.Visible = false;
            _zeroTierSetupButton.Click += delegate { OpenZeroTierSetup(); }; _connectionPanel.Controls.Add(_zeroTierSetupButton);
            _connectionPanel.Visible = false;
        }

        private void RefreshUiScale()
        {
            int requested = _graphics == null ? 0 : _graphics.UiScalePercent;
            _effectiveUiScale = UiScaleManager.Resolve(requested, Screen.FromControl(this).WorkingArea, GetDpiScale());
            UiScaleManager.Current = _effectiveUiScale;
            UpdateConnectionPanelScale();
        }

        private float GetDpiScale()
        {
            try { using (Graphics graphics = CreateGraphics()) return Math.Max(1F, graphics.DpiX / 96F); }
            catch { return 1F; }
        }

        private void UpdateConnectionPanelScale()
        {
            _connectionPanel.Visible = false;
        }

        private string ConnectionSettingPath { get { return Path.Combine(DataRoot, "connection-transport.txt"); } }

        private void LoadConnectionTransport()
        {
            try { if (File.Exists(ConnectionSettingPath)) _connectionTransport = NetworkAdapterProbe.Parse(File.ReadAllText(ConnectionSettingPath).Trim()); }
            catch { _connectionTransport = ConnectionTransport.ZeroTier; }
            int visibleIndex = VisibleConnectionIndex(_connectionTransport);
            if (visibleIndex < 0)
            {
                _connectionTransport = ConnectionTransport.ZeroTier;
                visibleIndex = 0;
                try { Directory.CreateDirectory(DataRoot); File.WriteAllText(ConnectionSettingPath, _connectionTransport.ToString(), new UTF8Encoding(false)); } catch { }
                Log("Hidden legacy connection choice migrated to ZeroTier.");
            }
            _connectionSelector.SelectedIndex = visibleIndex;
            RefreshConnectionProfile(false);
        }

        private void RefreshConnectionProfile(bool save)
        {
            _connectionProfile = NetworkAdapterProbe.Detect(_connectionTransport);
            _connectionState.Text = (_connectionProfile.Available ? "READY  •  " : "SETUP NEEDED  •  ") + _connectionProfile.Diagnostic;
            _connectionState.ForeColor = _connectionProfile.Available ? Color.FromArgb(105, 235, 170) : Color.FromArgb(245, 178, 90);
            _zeroTierSetupButton.Visible = _connectionTransport == ConnectionTransport.ZeroTier;
            _referenceSurface.SetConnectionStatus(NetworkAdapterProbe.DisplayName(_connectionTransport), _connectionState.Text, _connectionProfile.Available);
            UpdateConnectionPanelScale();
            if (save)
            {
                try { Directory.CreateDirectory(DataRoot); File.WriteAllText(ConnectionSettingPath, _connectionTransport.ToString(), new UTF8Encoding(false)); } catch { }
                Log("Connection type selected: " + _connectionTransport + "; resolved=" + _connectionProfile.Resolved + "; " + _connectionProfile.Diagnostic);
            }
        }

        private void CycleConnectionTransport(int delta)
        {
            int count = VisibleConnectionTransports.Length;
            _connectionSelector.SelectedIndex = (_connectionSelector.SelectedIndex + delta + count) % count;
            _referenceSurface.Focus();
        }

        private void OpenZeroTierSetup()
        {
            var page = new ZeroTierSetupForm(_root);
            ShowInAppPage(page, delegate(Form closed) { RefreshConnectionProfile(false); });
        }

        private void SetLauncherWindowMode(bool fullscreen)
        {
            _launcherFullscreen = fullscreen;
            if (fullscreen)
            {
                FormBorderStyle = FormBorderStyle.None;
                WindowState = FormWindowState.Maximized;
            }
            else
            {
                WindowState = FormWindowState.Normal;
                FormBorderStyle = FormBorderStyle.Sizable;
                ClientSize = new Size(1280, 720);
                StartPosition = FormStartPosition.CenterScreen;
                CenterToScreen();
            }
        }

        private void MinimizeLauncher()
        {
            WindowState = FormWindowState.Minimized;
            Log("Launcher minimized by user.");
        }

        private void MinimizeGameWindows()
        {
            int minimized = 0;
            foreach (Process process in _gameProcesses.ToArray())
            {
                try
                {
                    if (process.HasExited) continue;
                    process.Refresh();
                    uint processId = unchecked((uint)process.Id);
                    EnumWindows(delegate(IntPtr handle, IntPtr state)
                    {
                        uint windowProcessId;
                        GetWindowThreadProcessId(handle, out windowProcessId);
                        if (windowProcessId == processId && IsWindowVisible(handle))
                        {
                            ShowWindow(handle, 6);
                            minimized++;
                        }
                        return true;
                    }, IntPtr.Zero);
                }
                catch (Exception ex) { LogException("Could not minimize a PCSX2 window", ex); }
            }
            if (minimized == 0)
                MessageBox.Show("No active PCSX2 game window was found.", "Minimize PCSX2", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
                Log("Minimized " + minimized + " PCSX2 game window" + (minimized == 1 ? "." : "s."));
        }

        private void ShowInAppPage(Form page, Action<Form> completed)
        {
            if (_activePage != null) _activePage.Close();
            _referenceSurface.Visible = false;
            _connectionPanel.Visible = false;
            _pageHost = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(7, 11, 15), AutoScroll = true };
            Controls.Add(_pageHost);
            _pageHost.BringToFront();
            _activePage = page;
            Size baseSize = page.ClientSize;
            float fitWidth = Math.Max(0.75F, (ClientSize.Width - 48F) / baseSize.Width);
            float fitHeight = Math.Max(0.75F, (ClientSize.Height - 130F) / baseSize.Height);
            bool manualScale = _graphics != null && _graphics.UiScalePercent > 0;
            float pageScale = manualScale ? _effectiveUiScale : Math.Max(1F, Math.Min(_effectiveUiScale, Math.Min(fitWidth, fitHeight)));
            if (Math.Abs(pageScale - 1F) > 0.01F) page.Scale(new SizeF(pageScale, pageScale));
            Size preferred = page.ClientSize;
            page.TopLevel = false;
            page.FormBorderStyle = FormBorderStyle.None;
            page.StartPosition = FormStartPosition.Manual;
            page.Size = preferred;
            _pageHost.Controls.Add(page);
            WirePageSounds(page);
            var back = MakeButton("←  BACK TO HOME", Color.FromArgb(45, 55, 64), 170, 38);
            back.Location = new Point(24, 22);
            back.Anchor = AnchorStyles.Top | AnchorStyles.Left;
            back.Click += delegate { MenuAudio.PlayBack(); page.Close(); };
            _pageHost.Controls.Add(back);
            back.BringToFront();
            var minimize = MakeButton("—  MINIMIZE APP", Color.FromArgb(35, 54, 67), 180, 38);
            minimize.Location = new Point(Math.Max(220, _pageHost.ClientSize.Width - minimize.Width - 24), 22);
            minimize.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            minimize.Click += delegate { MinimizeLauncher(); };
            _pageHost.Controls.Add(minimize);
            minimize.BringToFront();
            Action position = delegate
            {
                page.Left = Math.Max(24, (_pageHost.ClientSize.Width - preferred.Width) / 2);
                page.Top = Math.Max(76, (_pageHost.ClientSize.Height - preferred.Height) / 2);
            };
            _pageHost.Resize += delegate { position(); };
            page.FormClosed += delegate
            {
                if (completed != null) completed(page);
                if (_pageHost != null) { Controls.Remove(_pageHost); _pageHost.Dispose(); _pageHost = null; }
                _activePage = null;
                _referenceSurface.Visible = true;
                _connectionPanel.Visible = true;
                _referenceSurface.Focus();
            };
            position();
            page.Show();
            page.Focus();
        }

        internal bool HasRemotePageMinimizeControlForSelfTest()
        {
            using (var page = new Form { ClientSize = new Size(620, 492) })
            {
                ShowInAppPage(page, null);
                bool found = _pageHost != null && _pageHost.Controls.OfType<Button>().Any(button => string.Equals(button.Text, "—  MINIMIZE APP", StringComparison.Ordinal));
                page.Close();
                return found;
            }
        }

        private static void WirePageSounds(Control parent)
        {
            foreach (Control control in parent.Controls)
            {
                if (control is Button)
                {
                    control.MouseEnter += delegate { MenuAudio.PlayMove(); };
                    control.Click += delegate { MenuAudio.PlayConfirm(); };
                }
                WirePageSounds(control);
            }
        }

        private void ChangeLocalPlayers(int delta)
        {
            int next = Math.Max(0, Math.Min(_localPlayers.Items.Count - 1, _localPlayers.SelectedIndex + delta));
            _localPlayers.SelectedIndex = next;
            Log("Local driver count changed to " + (next + 1) + ".");
        }

        private void SelectSharedCampaign()
        {
            var dialog = new SharedCampaignForm(new SharedCampaignStore(_root));
            ShowInAppPage(dialog, delegate(Form closed)
            {
                if (dialog.DialogResult != DialogResult.OK || dialog.SelectedCampaign == null) return;
                _activeCampaign = dialog.SelectedCampaign;
                _coopCampaign = true;
                _localPlayers.SelectedIndex = 0;
                RefreshReadiness();
                Log("Co-op Campaign selected: " + _activeCampaign.Name + " v" + _activeCampaign.Version + ".");
            });
        }

        private void OpenPrivateSession(SessionEntryMode entryMode = SessionEntryMode.Manage)
        {
            RefreshConnectionProfile(false);
            var dialog = new PrivateSessionForm(_root, _connectionTransport, _connectionProfile, entryMode);
            ShowInAppPage(dialog, async delegate(Form closed)
            {
                if (dialog.DialogResult == DialogResult.OK && dialog.ActiveSession != null)
                {
                    try
                    {
                        await ActivateOnlineSessionAsync(dialog.ActiveSession, dialog.SelectedMode, dialog.SelectedTransport);
                        await LaunchGameAsync();
                    }
                    catch (Exception ex)
                    {
                        LogException("Online engine startup failed", ex);
                        if (_betaBackend != null) { _betaBackend.Dispose(); _betaBackend = null; }
                        if (_networkSession != null) { _networkSession.Dispose(); _networkSession = null; }
                        MessageBox.Show(ex.Message, "Online match could not start", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
            });
        }

        private async Task ActivateOnlineSessionAsync(PrivateSessionService session, OnlineEngineMode mode, ConnectionTransport transport)
        {
            if (session == null) throw new ArgumentNullException("session");
            if (_networkSession != null && !object.ReferenceEquals(_networkSession, session)) _networkSession.Dispose();
            if (_betaBackend != null) { _betaBackend.Dispose(); _betaBackend = null; }
            _networkSession = session;
            _onlineMode = mode;
            _onlineHostReady.Reset();
            _onlineBackendReady = false;
            _connectionTransport = transport;
            int visibleIndex = VisibleConnectionIndex(_connectionTransport);
            if (visibleIndex < 0)
                throw new InvalidOperationException("This connection type is currently hidden. Select ZeroTier or Local Router / LAN on the home screen.");
            _connectionSelector.SelectedIndex = visibleIndex;
            RefreshConnectionProfile(true);
            if (_onlineMode == OnlineEngineMode.OnlineBetaMedius && _networkSession.Role == "HOST")
            {
                _betaBackend = new BetaBackendManager(_root, _networkSession.ServerAddress, Log);
                Log("Starting the private GT4 Online server; the launcher will remain responsive while it becomes ready.");
                await Task.Run(() => _betaBackend.StartAndVerify());
                _onlineBackendReady = true;
            }
            _networkSession.ControlMessage += OnControlMessage;
            _networkSession.ConnectionChanged += OnSessionConnectionChanged;
            EnsureRelayStarted();
            if (_networkSession.Role == "JOIN")
            {
                _networkSession.SendControl(2, new byte[0]);
                if (_onlineMode == OnlineEngineMode.OnlineBetaMedius)
                {
                    await Task.Run(() => WaitForOnlineHostReady());
                    await Task.Run(() => VerifyRemoteOnlineServices());
                }
            }
            else
            {
                if (_onlineBackendReady && _networkSession.Connected) SendOnlineHostReady();
                if (_activeCampaign != null && _networkSession.Connected) SendActiveCampaign();
            }
            UpdateSessionStatus();
            Log("Private session activated as " + _networkSession.Role + "; game launch requested.");
        }

        private void WaitForOnlineHostReady()
        {
            Stopwatch wait = Stopwatch.StartNew();
            while (wait.ElapsedMilliseconds < 90000)
            {
                if (_onlineHostReady.WaitOne(250)) return;
                if (_networkSession == null || !_networkSession.Connected)
                    throw new IOException("The host closed the private session before its GT4 Online server became ready. The game was not launched.");
            }
            throw new TimeoutException("The host did not confirm that its GT4 Online server was ready. The game was not launched, preventing an empty or conflicting session.");
        }

        private void VerifyRemoteOnlineServices()
        {
            int[] ports = { 10071, 10075, 10073, 443 };
            Stopwatch wait = Stopwatch.StartNew();
            while (wait.ElapsedMilliseconds < 15000)
            {
                if (_networkSession == null || !_networkSession.Connected)
                    throw new IOException("The host disconnected while its GT4 Online services were being checked.");
                if (ports.All(port => CanReachTcp(_networkSession.ServerAddress, port, 500)))
                {
                    Log("Joining computer reached host DNAS, MUIS, MAS and DME services.");
                    return;
                }
                Thread.Sleep(500);
            }
            throw new IOException("The host is authenticated, but its GT4 Online service ports cannot be reached. On the host, allow the packaged backend runtime on Windows Private networks and confirm both computers are authorized on the same ZeroTier network. The game was not launched.");
        }

        private static bool CanReachTcp(string host, int port, int timeoutMs)
        {
            try
            {
                using (var client = new TcpClient())
                {
                    IAsyncResult pending = client.BeginConnect(host, port, null, null);
                    if (!pending.AsyncWaitHandle.WaitOne(timeoutMs)) return false;
                    client.EndConnect(pending);
                    return client.Connected;
                }
            }
            catch { return false; }
        }

        private void OnSessionConnectionChanged()
        {
            try
            {
                if (IsDisposed) return;
                BeginInvoke((Action)delegate
                {
                    try
                    {
                        EnsureRelayStarted();
                        UpdateSessionStatus();
                        if (_networkSession != null && _networkSession.Role == "HOST" && _onlineBackendReady && _networkSession.Connected) SendOnlineHostReady();
                        if (_networkSession != null && _networkSession.Role == "HOST" && _activeCampaign != null && _networkSession.Connected) SendActiveCampaign();
                    }
                    catch (Exception ex) { LogException("Deferred online relay startup failed", ex); }
                });
            }
            catch { }
        }

        private void EnsureRelayStarted()
        {
            // The public release uses GT4 Online Beta's native private LAN traffic.
            // It does not expose the separate encrypted retail LAN relay mode.
            return;
        }

        private void UpdateSessionStatus()
        {
            if (_networkSession == null)
            {
                _sessionStatus.Text = "Offline";
                if (_connectionProfile != null) _referenceSurface.SetConnectionStatus(NetworkAdapterProbe.DisplayName(_connectionTransport), _connectionState.Text, _connectionProfile.Available);
                return;
            }
            string mode = "ONLINE BETA — PRIVATE GT4 SERVER";
            if (_networkSession.Role == "HOST" && !_networkSession.Connected)
                _sessionStatus.Text = "HOSTING: " + mode + " — waiting for invited friends.";
            else
                _sessionStatus.Text = (_networkSession.Role == "HOST" ? "HOSTING: " : "JOINED: ") + mode +
                    " — room authenticated; private backend active.";
            _referenceSurface.SetConnectionStatus(NetworkAdapterProbe.DisplayName(_connectionTransport),
                (_networkSession.Role == "HOST" ? "HOSTING • " : "JOINED • ") + mode, true);
        }

        internal static Label NewPublicLabel(float size, FontStyle style, Color color)
        {
            return new Label { Font = new Font("Segoe UI", size, style), ForeColor = color, BackColor = Color.Transparent };
        }

        private static Label NewLabel(float size, FontStyle style, Color color) { return NewPublicLabel(size, style, color); }

        private static void AddHeading(Control parent, string text, int x, int y)
        {
            var label = NewLabel(19, FontStyle.Bold, Color.White);
            label.Text = text;
            label.AutoSize = true;
            label.Location = new Point(x, y);
            parent.Controls.Add(label);
        }

        private static void AddSmallCaption(Control parent, string text, int x, int y)
        {
            var label = NewLabel(8, FontStyle.Bold, Color.FromArgb(218, 71, 84));
            label.Text = text;
            label.AutoSize = true;
            label.Location = new Point(x, y);
            parent.Controls.Add(label);
        }

        private static Button MakeButton(string text, Color color, int width, int height)
        {
            var button = new Button
            {
                Text = text,
                Width = width,
                Height = height,
                FlatStyle = FlatStyle.Flat,
                BackColor = color,
                ForeColor = Color.White,
                Cursor = Cursors.Hand,
                Font = new Font("Segoe UI Semibold", 9.5F),
                TabStop = true
            };
            button.FlatAppearance.BorderSize = 0;
            button.FlatAppearance.MouseOverBackColor = ControlPaint.Light(color, .12F);
            button.FlatAppearance.BorderColor = Color.White;
            button.Enter += delegate { button.FlatAppearance.BorderSize = 2; button.FlatAppearance.BorderColor = Color.FromArgb(238, 244, 248); };
            button.Leave += delegate { button.FlatAppearance.BorderSize = 0; };
            return button;
        }

        private void PollLauncherController()
        {
            ushort pressed = 0;
            for (uint index = 0; index < 4; index++)
            {
                ushort buttons;
                if (!ControllerScanner.TryGetButtons(index, out buttons)) { _controllerButtonStates[index] = 0; continue; }
                ushort edge = (ushort)(buttons & ~_controllerButtonStates[index]);
                _controllerButtonStates[index] = buttons;
                if (pressed == 0 && edge != 0) pressed = edge;
            }
            if (!LauncherControllerInputAllowed(WindowState, ContainsFocus, HasRunningGame())) return;
            if (pressed == 0) return;
            if (_activePage != null)
            {
                if ((pressed & (0x0001 | 0x0004)) != 0) { _activePage.SelectNextControl(_activePage.ActiveControl, false, true, true, true); MenuAudio.PlayMove(); }
                else if ((pressed & (0x0002 | 0x0008)) != 0) { _activePage.SelectNextControl(_activePage.ActiveControl, true, true, true, true); MenuAudio.PlayMove(); }
                else if ((pressed & 0x1000) != 0)
                {
                    var button = _activePage.ActiveControl as Button;
                    var check = _activePage.ActiveControl as CheckBox;
                    var combo = _activePage.ActiveControl as ComboBox;
                    if (button != null) button.PerformClick();
                    else if (check != null) { MenuAudio.PlayConfirm(); check.Checked = !check.Checked; }
                    else if (combo != null) { MenuAudio.PlayConfirm(); combo.DroppedDown = !combo.DroppedDown; }
                }
                else if ((pressed & 0x2000) != 0) { MenuAudio.PlayBack(); _activePage.Close(); }
                return;
            }
            if ((pressed & 0x0001) != 0 || (pressed & 0x0004) != 0) _referenceSurface.MoveSelection(-1);
            else if ((pressed & 0x0002) != 0 || (pressed & 0x0008) != 0) _referenceSurface.MoveSelection(1);
            else if ((pressed & 0x1000) != 0) _referenceSurface.ActivateSelected();
            // B/Circle is deliberately ignored on the home screen. Closing the launcher also
            // closes app-owned PCSX2 processes, so a global controller button must never exit it.
        }

        internal static bool LauncherControllerInputAllowed(FormWindowState windowState, bool containsFocus, bool gameRunning)
        {
            return windowState != FormWindowState.Minimized && containsFocus && !gameRunning;
        }

        private bool HasRunningGame()
        {
            return _gameProcesses.Any(delegate(Process process)
            {
                try { return !process.HasExited; } catch { return false; }
            });
        }

        private bool ValidateInstallation()
        {
            var errors = new List<string>();
            if (!File.Exists(Pcsx2Exe)) errors.Add("PCSX2");
            if (!File.Exists(GameIso) || new FileInfo(GameIso).Length < 1024L * 1024L * 1024L) errors.Add("Gran Turismo Bulgaria unified disc");
            var bios = Directory.Exists(BiosSource) ? Directory.GetFiles(BiosSource, "*.bin") : new string[0];
            if (bios.Length == 0 || new FileInfo(bios[0]).Length != 4194304) errors.Add("PS2 BIOS");
            if (errors.Count == 0)
            {
                _systemStatus.Text = "READY  •  GRAN TURISMO BULGARIA / COMPLETE";
                _systemStatus.ForeColor = Color.FromArgb(116, 225, 164);
                Log("Installation validation passed.");
                RefreshReadiness();
                return true;
            }
            _systemStatus.Text = "MISSING  •  " + string.Join(", ", errors.ToArray());
            _systemStatus.ForeColor = Color.FromArgb(255, 150, 116);
            _playButton.Enabled = false;
            Log("Installation validation failed: " + string.Join(", ", errors.ToArray()));
            return false;
        }

        private async Task ScanControllersAsync(bool announce = true)
        {
            if (_scanning) return;
            _scanning = true;
            if (announce) _controllerStatus.Text = "Scanning controllers…";
            try
            {
                var controllers = await Task.Run(() => ControllerScanner.GetControllers());
                string signature = string.Join("|", controllers.ToArray());
                if (!announce && string.Equals(signature, _controllerSignature, StringComparison.Ordinal)) return;
                bool newlyConnected = !string.IsNullOrEmpty(signature) && string.IsNullOrEmpty(_controllerSignature);
                _controllerSignature = signature;
                _detectedControllerCount = controllers.Count;
                _controllerList.Controls.Clear();
                if (controllers.Count == 0)
                {
                    _controllerList.Controls.Add(NewDeviceLabel("○  No controller detected — keyboard remains available", Color.FromArgb(190, 198, 205)));
                    _controllerStatus.Text = "No game controllers detected";
                    _referenceSurface.SetControllerStatus(0);
                }
                else
                {
                    foreach (var controller in controllers.Take(4))
                        _controllerList.Controls.Add(NewDeviceLabel("●  " + controller, Color.FromArgb(121, 224, 166)));
                    _controllerStatus.Text = controllers.Count + (controllers.Count == 1 ? " controller ready" : " controllers ready");
                    _referenceSurface.SetControllerStatus(Math.Min(4, controllers.Count));
                }
                Log("Controller scan: " + (controllers.Count == 0 ? "none" : string.Join(" | ", controllers.ToArray())));
                if (newlyConnected) Log("Controller hot-plug detected; Xbox/SDL Pad 1 mapping will be applied automatically at game launch.");
                RefreshReadiness();
            }
            catch (Exception ex)
            {
                _controllerStatus.Text = "Controller scan failed — see support log";
                LogException("Controller scan failed", ex);
            }
            finally { _scanning = false; }
        }

        private static Label NewDeviceLabel(string text, Color color)
        {
            var label = NewLabel(9.5F, FontStyle.Regular, color);
            label.Text = text;
            label.AutoSize = false;
            label.Width = 350;
            label.Height = 23;
            return label;
        }

        private void RefreshReadiness()
        {
            int requested = _localPlayers.SelectedIndex + 1;
            _playButton.Enabled = File.Exists(Pcsx2Exe) && File.Exists(GameIso);
            if (requested > 1 && _detectedControllerCount < requested)
            {
                _playButton.Text = "CONNECT " + requested + " CONTROLLERS";
                _playButton.Enabled = false;
            }
            else _playButton.Text = _coopCampaign ? "START SHARED CO-OP CAMPAIGN" : (requested == 1 ? "PLAY GRAN TURISMO BULGARIA" : "START " + requested + "-DRIVER PARTY");
        }

        private async Task LaunchGameAsync()
        {
            _gameProcesses.RemoveAll(delegate(Process p) { try { return p.HasExited; } catch { return true; } });
            if (_gameProcesses.Count > 0)
            {
                MessageBox.Show("Gran Turismo 4 is already running from this launcher. Close the active game before starting another session so PCSX2 does not open the same memory card or PINE port twice.", "Game already running", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (!ValidateInstallation()) return;
            if (_coopCampaign && _activeCampaign == null)
            {
                SelectSharedCampaign();
                if (_activeCampaign == null) return;
            }
            int players = _localPlayers.SelectedIndex + 1;
            if (_coopCampaign) players = 1;
            if (players > 1 && _detectedControllerCount < players)
            {
                MessageBox.Show("Connect at least " + players + " controllers, then select Refresh Controllers.", "Controllers required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            _playButton.Enabled = false;
            try
            {
                if (_networkSession != null && _onlineMode == OnlineEngineMode.OnlineBetaMedius)
                {
                    UnifiedDisc.VerifyImage(GameIso);
                    Log("Verified Online Public Beta compatibility fingerprint: SCUS-97436 / UDP 6000 profile.");
                }
                for (int i = 1; i <= players; i++)
                {
                    string dataPath = PreparePlayerData(i, players);
                    bool fullscreen = players == 1 && _graphics != null && _graphics.LaunchFullscreen;
                    if (!File.Exists(LaunchIso))
                        throw new FileNotFoundException("The verified Gran Turismo 4 Online Public Beta image is missing.", LaunchIso);
                    var args = "-datapath \"" + dataPath + "\" -batch " + (fullscreen ? "-fullscreen " : "-nofullscreen ") + "-fastboot -- \"" + LaunchIso + "\"";
                    var process = Process.Start(new ProcessStartInfo(Pcsx2Exe, args) { WorkingDirectory = Path.GetDirectoryName(Pcsx2Exe), UseShellExecute = false });
                    _gameProcesses.Add(process);
                    process.EnableRaisingEvents = true;
                    if (_networkSession != null)
                    {
                        int pinePort = 28010 + i;
                        var monitor = new Gt4RuntimeMonitor(pinePort, process, _networkSession, Log,
                            false);
                        _gt4Monitors.Add(monitor);
                        monitor.Start();
                        process.Exited += delegate { monitor.Dispose(); };
                    }
                    if (_coopCampaign && i == 1)
                    {
                        process.Exited += delegate { CommitCampaignAfterGame(dataPath); };
                    }
                    Log("Started PCSX2 player " + i + " (PID " + process.Id + ").");
                    await Task.Delay(800);
                }
                if (_coopCampaign) Log("Co-op Campaign started with isolated signed memory-card history.");
                if (players > 1)
                {
                    await Task.Delay(6000);
                    TileGameWindows(players);
                }
                WindowState = FormWindowState.Minimized;
            }
            catch (Exception ex)
            {
                LogException("Game launch failed", ex);
                MessageBox.Show("GT4 could not be started. Use Export Support ZIP and send the resulting file for diagnosis.\n\n" + ex.Message, "Launch failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally { _playButton.Enabled = true; }
        }

        private string PreparePlayerData(int player, int totalPlayers = 1)
        {
            string target = _coopCampaign && _activeCampaign != null
                ? Path.Combine(DataRoot, "shared-campaigns", _activeCampaign.Id)
                : Path.Combine(DataRoot, "player" + player);
            // PCSX2 appends its own "PCSX2" directory to -datapath on Windows.
            string appDataTarget = Path.Combine(target, "PCSX2");
            string playerOneTemplate = Path.Combine(DataRoot, "player1", "PCSX2");
            if (!File.Exists(Path.Combine(appDataTarget, "inis", "PCSX2.ini")) && Directory.Exists(playerOneTemplate))
                CopyConfiguration(playerOneTemplate, appDataTarget, Math.Max(0, player - 1));
            string biosTarget = Path.Combine(appDataTarget, "bios");
            Directory.CreateDirectory(biosTarget);
            foreach (var source in Directory.GetFiles(BiosSource))
            {
                string extension = Path.GetExtension(source).ToLowerInvariant();
                if (extension == ".bin" || extension == ".nvm" || extension == ".mec")
                    File.Copy(source, Path.Combine(biosTarget, Path.GetFileName(source)), true);
            }
            if (_coopCampaign && _activeCampaign != null)
            {
                string card = Path.Combine(appDataTarget, "memcards", "Mcd001.ps2");
                Directory.CreateDirectory(Path.GetDirectoryName(card));
                new SharedCampaignStore(_root).RestoreToMemoryCard(_activeCampaign.Id, card);
            }
            if (player > 1)
            {
                string playerOne = Path.Combine(DataRoot, "player1", "PCSX2");
                CopyConfiguration(playerOne, appDataTarget, player - 1);
            }
            ApplyGraphicsSettings(appDataTarget, totalPlayers);
            ControllerConfiguration.Apply(appDataTarget, Math.Max(0, player - 1));
            ApplyPineSettings(appDataTarget, player);
            if (_networkSession != null && (_networkSession.Connected || string.Equals(_networkSession.Role, "HOST", StringComparison.Ordinal)))
            {
                string adapter = NetworkAdapterProbe.Pcsx2Device(_connectionTransport);
                if (_onlineMode == OnlineEngineMode.OnlineBetaMedius)
                {
                    // Keep TCP login and fixed-port UDP NAT on the same selected
                    // session interface. Windows automatic routing can send the TCP
                    // login successfully while rejecting GT4's UDP/6000 NAT probe
                    // with WSAENETUNREACH when a physical NIC wins the route.
                    ApplyBetaNetworkSettings(appDataTarget, _networkSession.ServerAddress, adapter);
                    Log("GT Bulgaria automatic network profile applied: DHCP, private internal DNS and selected-adapter TCP/UDP routing (session network " + adapter + ").");
                }
                else ApplyNetworkSettings(appDataTarget, adapter);
            }
            return target;
        }

        private static void ApplyPineSettings(string appDataTarget, int player)
        {
            string ini = Path.Combine(appDataTarget, "inis", "PCSX2.ini");
            if (!File.Exists(ini)) return;
            string text = File.ReadAllText(ini);
            text = IniEditor.Set(text, "SetupWizardIncomplete", "false");
            text = IniEditor.Set(text, "BIOS", "ps2-bios.bin");
            text = IniEditor.Set(text, "EnablePINE", "true");
            text = IniEditor.Set(text, "PINESlot", (28010 + player).ToString());
            File.WriteAllText(ini, text, new UTF8Encoding(false));
        }

        private void CommitCampaignAfterGame(string dataPath)
        {
            try
            {
                if (_activeCampaign == null) return;
                if (_networkSession != null && _networkSession.Connected && _networkSession.Role != "HOST")
                {
                    Log("Joined player memory-card changes ignored; the host owns campaign commits.");
                    return;
                }
                string card = Path.Combine(dataPath, "PCSX2", "memcards", "Mcd001.ps2");
                if (!File.Exists(card)) { Log("Campaign did not create a memory card; no commit made."); return; }
                var store = new SharedCampaignStore(_root);
                CampaignInfo committed = store.Commit(_activeCampaign.Id, card, _networkSession == null ? "LOCAL HOST" : "SESSION HOST");
                _activeCampaign = committed;
                Log("Campaign commit accepted: " + committed.Name + " v" + committed.Version + ".");
                if (_networkSession != null && _networkSession.Connected) SendActiveCampaign();
            }
            catch (Exception ex) { LogException("Campaign commit failed", ex); }
        }

        private void SendActiveCampaign()
        {
            try
            {
                if (_networkSession == null || !_networkSession.Connected || _activeCampaign == null) return;
                byte[] package = new SharedCampaignStore(_root).ExportPackage(_activeCampaign.Id);
                _networkSession.SendControl(1, package);
                byte[] authority = new SharedCampaignStore(_root).ExportHostingAuthority(_activeCampaign.Id);
                try { _networkSession.SendControl(3, authority); }
                finally { Array.Clear(authority, 0, authority.Length); }
                Log("Sent signed campaign " + _activeCampaign.Name + " v" + _activeCampaign.Version + " to friend.");
            }
            catch (Exception ex) { LogException("Campaign synchronization send failed", ex); }
        }

        private void OnControlMessage(byte type, byte[] payload)
        {
            try
            {
                if (type == 30)
                {
                    if (_networkSession == null || _networkSession.Role != "JOIN") { Log("Rejected participant-originated server-ready signal."); return; }
                    _onlineHostReady.Set();
                    Log("Authenticated host confirmed that the GT4 Online server is ready.");
                    return;
                }
                if (type == 20)
                {
                    string telemetry = Encoding.UTF8.GetString(payload ?? new byte[0]);
                    Log("Verified host race telemetry: " + telemetry);
                    return;
                }
                if (type == 2)
                {
                    if (_networkSession != null && _networkSession.Role == "HOST")
                    {
                        if (_onlineBackendReady) SendOnlineHostReady();
                        SendActiveCampaign();
                    }
                    return;
                }
                if (type == 3)
                {
                    if (_networkSession == null || _networkSession.Role != "JOIN") { Log("Rejected participant-originated hosting authority."); return; }
                    new SharedCampaignStore(_root).ImportHostingAuthority(payload);
                    Log("Protected campaign hosting authority received from the authenticated session host.");
                    return;
                }
                if (type != 1) return;
                if (_networkSession == null || _networkSession.Role != "JOIN")
                {
                    Log("Rejected participant-originated campaign commit; only the active host may distribute campaign state.");
                    return;
                }
                CampaignInfo imported = new SharedCampaignStore(_root).ImportPackage(payload);
                _activeCampaign = imported; _coopCampaign = true;
                Log("Verified synchronized campaign: " + imported.Name + " v" + imported.Version + ".");
                if (!IsDisposed && IsHandleCreated) BeginInvoke((Action)delegate
                {
                    RefreshReadiness();
                    MessageBox.Show("Verified campaign synchronized:\n\n" + imported.Name + " — version " + imported.Version + "\n\nThe authenticated host also transfers protected hosting authority, so this computer can host the latest synchronized save later.", "Co-op Campaign synchronized", MessageBoxButtons.OK, MessageBoxIcon.Information);
                });
            }
            catch (Exception ex) { LogException("Campaign synchronization rejected", ex); }
        }

        private void SendOnlineHostReady()
        {
            try
            {
                if (_networkSession != null && _networkSession.Role == "HOST" && _networkSession.Connected)
                    _networkSession.SendControl(30, Encoding.ASCII.GetBytes("GT4-ONLINE-READY-V1"));
            }
            catch (Exception ex) { LogException("Could not send online server readiness", ex); }
        }

        private static void ApplyNetworkSettings(string appDataTarget, string adapterDevice = null)
        {
            string ini = Path.Combine(appDataTarget, "inis", "PCSX2.ini");
            if (!File.Exists(ini)) return;
            string text = File.ReadAllText(ini);
            text = IniEditor.SetInSection(text, "DEV9/Eth", "EthEnable", "true");
            text = IniEditor.SetInSection(text, "DEV9/Eth", "EthApi", "Sockets");
            text = IniEditor.SetInSection(text, "DEV9/Eth", "EthDevice", string.IsNullOrWhiteSpace(adapterDevice) ? NetworkAdapterProbe.Pcsx2Device() : adapterDevice);
            text = IniEditor.SetInSection(text, "DEV9/Eth", "InterceptDHCP", "true");
            text = IniEditor.SetInSection(text, "DEV9/Eth", "LanMode", "true");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Hosts", "Count", "0");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Ports", "LanMode", "true");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Ports", "Count", "1");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Ports/Port0", "Port", "3658");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Ports/Port0", "Desc", "Gran Turismo 4 LAN");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Ports/Port0", "Protocol", "UDP");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Ports/Port0", "Enabled", "true");
            File.WriteAllText(ini, text, new UTF8Encoding(false));
        }

        internal static void ApplyNetworkSettingsForTest(string appDataTarget) { ApplyNetworkSettings(appDataTarget); }
        internal static void ApplyBetaNetworkSettingsForTest(string appDataTarget, string serverAddress) { ApplyBetaNetworkSettings(appDataTarget, serverAddress, "{11111111-2222-3333-4444-555555555555}"); }

        private static void ApplyBetaNetworkSettings(string appDataTarget, string serverAddress, string adapterDevice = null)
        {
            string ini = Path.Combine(appDataTarget, "inis", "PCSX2.ini");
            if (!File.Exists(ini)) return;
            IPAddress parsed;
            if (!IPAddress.TryParse(serverAddress, out parsed) || parsed.AddressFamily != AddressFamily.InterNetwork)
                parsed = Dns.GetHostAddresses(serverAddress).First(a => a.AddressFamily == AddressFamily.InterNetwork);
            string address = parsed.ToString();
            string text = File.ReadAllText(ini);
            text = IniEditor.SetInSection(text, "DEV9/Eth", "EthEnable", "true");
            text = IniEditor.SetInSection(text, "DEV9/Eth", "EthApi", "Sockets");
            text = IniEditor.SetInSection(text, "DEV9/Eth", "EthDevice", string.IsNullOrWhiteSpace(adapterDevice) ? NetworkAdapterProbe.Pcsx2Device() : adapterDevice);
            text = IniEditor.SetInSection(text, "DEV9/Eth", "InterceptDHCP", "true");
            // This is the host-side half of the plug-and-play "GT Bulgaria"
            // profile. The in-game profile only needs DHCP/automatic addressing;
            // PCSX2 supplies the private DNS and authenticated session address.
            // PCSX2's built-in DNS server owns the private hostname table below.
            // DHCP advertises 192.0.2.1 for ModeDNS1=Internal; pointing DNS at the
            // game host would fail because the embedded backend is not a DNS server.
            text = IniEditor.SetInSection(text, "DEV9/Eth", "ModeDNS1", "Internal");
            text = IniEditor.SetInSection(text, "DEV9/Eth", "DNS1", "192.0.2.1");
            text = IniEditor.SetInSection(text, "DEV9/Eth", "ModeDNS2", "Auto");
            text = IniEditor.SetInSection(text, "DEV9/Eth", "DNS2", "0.0.0.0");
            text = IniEditor.SetInSection(text, "DEV9/Eth", "EthLogDNS", "true");
            text = IniEditor.SetInSection(text, "DEV9/Eth", "LanMode", "false");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Ports", "LanMode", "false");
            // PR13391 supports a listener for peer-initiated race traffic.
            // Preserve adapter binding and LAN mode; never open a port range.
            bool peerPort = Environment.GetEnvironmentVariable("GTB_PEER_PORT") != "legacy";
            text = IniEditor.SetInSection(text, "DEV9/Eth/Ports", "Count", peerPort ? "1" : "0");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Ports/Port0", "Port", "6000");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Ports/Port0", "Desc", "GT4 Online Beta race peers");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Ports/Port0", "Protocol", "UDP");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Ports/Port0", "Enabled", peerPort ? "true" : "false");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Hosts", "Count", "3");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Hosts/Host0", "Url", "gt4-pubeta.svo.pdonline.scea.com");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Hosts/Host0", "Desc", "Gran Turismo Bulgaria private SVO");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Hosts/Host0", "Address", address);
            text = IniEditor.SetInSection(text, "DEV9/Eth/Hosts/Host0", "Enabled", "true");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Hosts/Host1", "Url", "gt4-pubeta.muis.pdonline.scea.com");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Hosts/Host1", "Desc", "Gran Turismo Bulgaria private Medius");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Hosts/Host1", "Address", address);
            text = IniEditor.SetInSection(text, "DEV9/Eth/Hosts/Host1", "Enabled", "true");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Hosts/Host2", "Url", "gate1.us.dnas.playstation.org");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Hosts/Host2", "Desc", "Gran Turismo Bulgaria retired DNAS sink");
            text = IniEditor.SetInSection(text, "DEV9/Eth/Hosts/Host2", "Address", address);
            text = IniEditor.SetInSection(text, "DEV9/Eth/Hosts/Host2", "Enabled", "true");
            // Preserve graphics choices, including display VSync, while removing
            // emulator speed changes that can destabilize Beta peer simulation.
            text = IniEditor.SetInSection(text, "EmuCore/Speedhacks", "EECycleRate", "0");
            text = IniEditor.SetInSection(text, "EmuCore/Speedhacks", "EECycleSkip", "0");
            text = IniEditor.SetInSection(text, "EmuCore/GS", "FramerateNTSC", "59.94");
            text = IniEditor.SetInSection(text, "Framerate", "NominalScalar", "1");
            File.WriteAllText(ini, text, new UTF8Encoding(false));
        }

        private void OpenGraphicsSettings()
        {
            if (_graphics == null) _graphics = GraphicsOptions.LoadOrDetect(_root);
            var dialog = new GraphicsSettingsForm(_graphics, HardwareProbe.Detect());
            ShowInAppPage(dialog, delegate(Form closed)
            {
                if (dialog.DialogResult == DialogResult.OK)
                {
                    _graphics = dialog.Options;
                    _graphics.Save(_root);
                    RefreshUiScale();
                    ApplyGraphicsSettings(Path.Combine(DataRoot, "player1", "PCSX2"), 1);
                    UpdateGraphicsSummary();
                    Log("Graphics saved: " + _graphics.Describe());
                }
            });
        }

        private void OpenLauncherOptions()
        {
            var page = new Form { Text = "Gran Turismo Bulgaria Options", ClientSize = new Size(720, 430), BackColor = Color.FromArgb(10, 16, 21), ForeColor = Color.White };
            AddHeading(page, "OPTIONS", 38, 38);
            var version = NewLabel(9.5F, FontStyle.Regular, Color.FromArgb(170, 187, 199));
            version.Text = "VERSION  " + BuildVersion; version.AutoSize = true; version.Location = new Point(40, 80); page.Controls.Add(version);
            AddSmallCaption(page, "LOCAL SPLIT-SCREEN DRIVERS", 40, 128);
            var players = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(31, 41, 49), ForeColor = Color.White, Font = new Font("Segoe UI Semibold", 13F), Location = new Point(40, 150), Size = new Size(300, 38) };
            players.Items.AddRange(new object[] { "1 driver", "2 drivers", "3 drivers", "4 drivers" }); players.SelectedIndex = _localPlayers.SelectedIndex; page.Controls.Add(players);
            var detected = NewLabel(11F, FontStyle.Regular, Color.FromArgb(120, 225, 169));
            detected.Text = _detectedControllerCount == 0 ? "No controller detected — keyboard remains available" : _detectedControllerCount + (_detectedControllerCount == 1 ? " controller ready" : " controllers ready");
            detected.AutoSize = false; detected.Location = new Point(40, 214); detected.Size = new Size(640, 30); page.Controls.Add(detected);
            var refresh = MakeButton("REFRESH CONTROLLERS", Color.FromArgb(35, 54, 67), 220, 44); refresh.Location = new Point(40, 258);
            refresh.Click += async delegate { await ScanControllersAsync(); detected.Text = _detectedControllerCount == 0 ? "No controller detected — keyboard remains available" : _detectedControllerCount + (_detectedControllerCount == 1 ? " controller ready" : " controllers ready"); }; page.Controls.Add(refresh);
            var save = MakeButton("SAVE & RETURN", Color.FromArgb(190, 19, 38), 220, 48); save.Location = new Point(460, 342);
            save.Click += delegate { _localPlayers.SelectedIndex = Math.Max(0, players.SelectedIndex); Log("Local driver count changed to " + (_localPlayers.SelectedIndex + 1) + " from Options."); page.DialogResult = DialogResult.OK; page.Close(); }; page.Controls.Add(save);
            ShowInAppPage(page, null);
            players.Focus();
        }

        private void UpdateGraphicsSummary()
        {
            if (_graphics == null) return;
            _graphicsSummary.Text = "GRAPHICS  •  " + _graphics.Describe();
        }

        private void ApplyGraphicsSettings(string appDataTarget, int totalPlayers)
        {
            string ini = Path.Combine(appDataTarget, "inis", "PCSX2.ini");
            if (!File.Exists(ini) || _graphics == null) return;
            GraphicsOptions effective = _graphics.ResolveAuto();
            if (_graphics.Profile == "Auto" && totalPlayers > 1)
                effective.Scale = totalPlayers == 2 ? Math.Min(2, effective.Scale) : 1;
            string text = File.ReadAllText(ini);
            text = IniEditor.Set(text, "Renderer", effective.RendererCode.ToString());
            text = IniEditor.Set(text, "upscale_multiplier", effective.Scale.ToString());
            text = IniEditor.Set(text, "MaxAnisotropy", effective.Anisotropy.ToString());
            text = IniEditor.Set(text, "VsyncEnable", effective.Vsync ? "true" : "false");
            text = IniEditor.Set(text, "EnableWideScreenPatches", effective.Widescreen ? "true" : "false");
            text = IniEditor.Set(text, "EnableNoInterlacingPatches", effective.NoInterlace ? "true" : "false");
            text = IniEditor.Set(text, "FXAA", effective.Fxaa ? "true" : "false");
            File.WriteAllText(ini, text, new UTF8Encoding(false));
        }

        private static void CopyConfiguration(string source, string target, int controllerIndex)
        {
            if (!Directory.Exists(source)) return;
            foreach (var file in Directory.GetFiles(source, "*.ini", SearchOption.AllDirectories))
            {
                if (file.IndexOf("memcard", StringComparison.OrdinalIgnoreCase) >= 0) continue;
                string relative = file.Substring(source.Length).TrimStart(Path.DirectorySeparatorChar);
                string destination = Path.Combine(target, relative);
                Directory.CreateDirectory(Path.GetDirectoryName(destination));
                string text = File.ReadAllText(file);
                text = text.Replace("SDL-0", "SDL-" + controllerIndex).Replace("XInput-0", "XInput-" + controllerIndex);
                File.WriteAllText(destination, text, new UTF8Encoding(false));
            }
        }

        private void LaunchSetup()
        {
            try
            {
                string dataPath = PreparePlayerData(1);
                var setupProcess = Process.Start(new ProcessStartInfo(Pcsx2Exe, "-datapath \"" + dataPath + "\" -setupwizard") { WorkingDirectory = Path.GetDirectoryName(Pcsx2Exe), UseShellExecute = false });
                _gameProcesses.Add(setupProcess);
                Log("Opened PCSX2 setup wizard.");
            }
            catch (Exception ex)
            {
                LogException("PCSX2 setup launch failed", ex);
                MessageBox.Show(ex.Message, "PCSX2 setup failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TileGameWindows(int count)
        {
            var area = Screen.PrimaryScreen.WorkingArea;
            int columns = count == 2 ? 2 : 2;
            int rows = count <= 2 ? 1 : 2;
            int width = area.Width / columns;
            int height = area.Height / rows;
            for (int i = 0; i < _gameProcesses.Count && i < count; i++)
            {
                try
                {
                    var p = _gameProcesses[i];
                    p.Refresh();
                    IntPtr handle = p.MainWindowHandle;
                    if (handle == IntPtr.Zero) continue;
                    int col = i % columns;
                    int row = i / columns;
                    ShowWindow(handle, 9);
                    MoveWindow(handle, area.Left + col * width, area.Top + row * height, width, height, true);
                }
                catch (Exception ex) { LogException("Could not tile player window " + (i + 1), ex); }
            }
        }

        private void ExportSupportBundle()
        {
            try
            {
                Directory.CreateDirectory(Path.Combine(_root, "support"));
                string stamp = DateTime.Now.ToString("yyyyMMdd-HHmmss");
                string zipPath = Path.Combine(_root, "support", "Gran-Turismo-Bulgaria-Support-" + stamp + ".zip");
                using (var archive = ZipFile.Open(zipPath, ZipArchiveMode.Create))
                {
                    AddText(archive, "diagnostics.txt", BuildDiagnostics());
                    AddSanitizedFile(archive, _logPath, "launcher.log");
                    AddSanitizedFile(archive, Path.Combine(_root, "logs", "svo-backend.log"), "svo-backend.log");
                    AddSanitizedFile(archive, Path.Combine(_root, "logs", "medius-backend.log"), "medius-backend.log");
                    AddSanitizedFile(archive, Path.Combine(_root, "logs", "dnas-backend.log"), "dnas-backend.log");
                    if (Directory.Exists(DataRoot))
                    {
                        foreach (var file in Directory.GetFiles(DataRoot, "emulog.txt", SearchOption.AllDirectories))
                        {
                            string relative = file.Substring(DataRoot.Length).TrimStart('\\').Replace('\\', '-').Replace('/', '-');
                            AddSanitizedFile(archive, file, "pcsx2-" + relative);
                        }
                    }
                }
                Log("Exported redacted support bundle: " + zipPath);
                MessageBox.Show("Support bundle created:\n\n" + zipPath + "\n\nIt excludes the game, BIOS, memory cards and account secrets.", "Support bundle ready", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Process.Start("explorer.exe", "/select,\"" + zipPath + "\"");
            }
            catch (Exception ex)
            {
                LogException("Support bundle export failed", ex);
                MessageBox.Show(ex.Message, "Export failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string BuildDiagnostics()
        {
            var sb = new StringBuilder();
            sb.AppendLine("Gran Turismo Bulgaria support bundle");
            sb.AppendLine("Build: " + BuildVersion);
            sb.AppendLine("Generated: " + DateTime.Now.ToString("O"));
            sb.AppendLine("OS: " + Environment.OSVersion);
            sb.AppendLine("64-bit OS/process: " + Environment.Is64BitOperatingSystem + "/" + Environment.Is64BitProcess);
            sb.AppendLine("CPU count: " + Environment.ProcessorCount);
            sb.AppendLine("PCSX2 present: " + File.Exists(Pcsx2Exe));
            sb.AppendLine("PCSX2 SHA-256: " + SafeHash(Pcsx2Exe));
            sb.AppendLine("GT4 present/size: " + File.Exists(GameIso) + "/" + (File.Exists(GameIso) ? new FileInfo(GameIso).Length.ToString() : "0"));
            sb.AppendLine("GT4 quick fingerprint: " + QuickFingerprint(GameIso));
            sb.AppendLine("GT4 Online Beta expected fingerprint: " + UnifiedDisc.CompatibilityFingerprint);
            sb.AppendLine("GT4 Online Beta fingerprint match: " + (File.Exists(GameIso) && new FileInfo(GameIso).Length == UnifiedDisc.ExactLength && string.Equals(QuickFingerprint(GameIso), UnifiedDisc.CompatibilityFingerprint, StringComparison.OrdinalIgnoreCase)));
            sb.AppendLine("BIOS files: " + (Directory.Exists(BiosSource) ? string.Join(", ", Directory.GetFiles(BiosSource).Select(f => Path.GetFileName(f) + ":" + new FileInfo(f).Length).ToArray()) : "none"));
            sb.AppendLine("Controllers: " + string.Join(" | ", ControllerScanner.GetControllers().ToArray()));
            sb.AppendLine("Local drivers selected: " + (_localPlayers.SelectedIndex + 1));
            sb.AppendLine("Graphics: " + (_graphics == null ? "not loaded" : _graphics.Describe()));
            sb.AppendLine("Hardware: " + HardwareProbe.Detect().Summary);
            sb.AppendLine("PCSX2 configuration present: " + File.Exists(Path.Combine(DataRoot, "player1", "PCSX2", "inis", "PCSX2.ini")));
            string activeIni = Path.Combine(DataRoot, "player1", "PCSX2", "inis", "PCSX2.ini");
            if (File.Exists(activeIni))
            {
                string settings = File.ReadAllText(activeIni);
                sb.AppendLine("Beta network API/device: " + IniEditor.GetInSection(settings, "DEV9/Eth", "EthApi") + "/" + IniEditor.GetInSection(settings, "DEV9/Eth", "EthDevice"));
                sb.AppendLine("Beta peer listener: UDP " + IniEditor.GetInSection(settings, "DEV9/Eth/Ports/Port0", "Port") + ", enabled=" + IniEditor.GetInSection(settings, "DEV9/Eth/Ports/Port0", "Enabled"));
                sb.AppendLine("Beta timing: EE rate=" + IniEditor.GetInSection(settings, "EmuCore/Speedhacks", "EECycleRate") + ", EE skip=" + IniEditor.GetInSection(settings, "EmuCore/Speedhacks", "EECycleSkip") + ", NTSC=" + IniEditor.GetInSection(settings, "EmuCore/GS", "FramerateNTSC") + ", scalar=" + IniEditor.GetInSection(settings, "Framerate", "NominalScalar"));
            }
            sb.AppendLine("Private session: " + (_networkSession == null ? "inactive" : _networkSession.Role + ", mode=" + (_onlineMode == OnlineEngineMode.OnlineBetaMedius ? "ONLINE BETA PRIVATE SERVER" : "ARCADE LAN RETAIL v2.00") + ", connected=" + _networkSession.Connected));
            if (_networkSession != null && _networkSession.Relay != null)
                sb.AppendLine("Race relay: " + _networkSession.RelayStatus + ", sent=" + _networkSession.Relay.SentPackets + ", received=" + _networkSession.Relay.ReceivedPackets);
            sb.AppendLine("Privacy: raw settings and private game or account materials are excluded.");
            return Sanitize(sb.ToString());
        }

        private static string SafeHash(string path)
        {
            try
            {
                if (!File.Exists(path)) return "missing";
                using (var stream = File.OpenRead(path))
                using (var sha = SHA256.Create())
                    return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", "").ToLowerInvariant();
            }
            catch (Exception ex) { return "unavailable:" + ex.GetType().Name; }
        }

        internal static string SafeHashForSelfTest(string path) { return SafeHash(path); }

        private static string QuickFingerprint(string path)
        {
            try
            {
                if (!File.Exists(path)) return "missing";
                using (var stream = File.OpenRead(path))
                using (var sha = SHA256.Create())
                {
                    var buffer = new byte[1024 * 1024];
                    int first = stream.Read(buffer, 0, buffer.Length);
                    sha.TransformBlock(buffer, 0, first, buffer, 0);
                    stream.Seek(Math.Max(0, stream.Length - buffer.Length), SeekOrigin.Begin);
                    int last = stream.Read(buffer, 0, buffer.Length);
                    sha.TransformFinalBlock(buffer, 0, last);
                    return BitConverter.ToString(sha.Hash).Replace("-", "").ToLowerInvariant();
                }
            }
            catch (Exception ex) { return "unavailable:" + ex.GetType().Name; }
        }

        internal static string QuickFingerprintForCompatibility(string path) { return QuickFingerprint(path); }

        private void AddSanitizedFile(ZipArchive archive, string source, string entryName)
        {
            if (!File.Exists(source)) return;
            const int limit = 2 * 1024 * 1024;
            string content;
            using (var stream = new FileStream(source, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
            {
                if (stream.Length > limit) stream.Seek(-limit, SeekOrigin.End);
                using (var reader = new StreamReader(stream, Encoding.UTF8, true)) content = reader.ReadToEnd();
            }
            AddText(archive, entryName, Sanitize(content));
        }

        private static void AddText(ZipArchive archive, string name, string content)
        {
            var entry = archive.CreateEntry(name, CompressionLevel.Optimal);
            using (var writer = new StreamWriter(entry.Open(), new UTF8Encoding(false))) writer.Write(content);
        }

        private string Sanitize(string value)
        {
            string user = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string result = value.Replace(user, "<USER>").Replace(_root, "<APP>");
            result = Regex.Replace(result, @"(?im)^.*(?:password|token|secret|authorization|cookie).*$", "[REDACTED SECRET LINE]");
            result = Regex.Replace(result, @"(?i)\b(?:LAN|BETA)\|[^\s\r\n]+|\b[^\s:#]+:\d{1,5}#[A-Za-z0-9_-]{40,}\b", "<PRIVATE INVITATION>");
            result = Regex.Replace(result, @"\b(?:\d{1,3}\.){3}\d{1,3}\b", "<IP>");
            result = Regex.Replace(result, @"(?i)(?<![A-Za-z0-9])(?:[0-9a-f]{0,4}:){2,7}[0-9a-f]{0,4}(?![A-Za-z0-9])", "<IPV6>");
            result = Regex.Replace(result, @"\b(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\b", "<MAC>");
            result = Regex.Replace(result, @"(?i)\b[A-Za-z0-9_-]{43}\b", "<REDACTED CAPABILITY>");
            return result;
        }

        private void StopTrackedProcesses()
        {
            foreach (var monitor in _gt4Monitors.ToArray())
            {
                try { monitor.Dispose(); } catch { }
            }
            foreach (var process in _gameProcesses.ToArray())
            {
                try
                {
                    if (!process.HasExited)
                    {
                        process.CloseMainWindow();
                        if (!process.WaitForExit(2500)) process.Kill();
                    }
                }
                catch { }
            }
            Log("Launcher closed; tracked PCSX2 processes stopped.");
        }

        private void Log(string message)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(_logPath));
                if (File.Exists(_logPath) && new FileInfo(_logPath).Length > 5L * 1024 * 1024)
                {
                    string previous = _logPath + ".previous";
                    if (File.Exists(previous)) File.Delete(previous);
                    File.Move(_logPath, previous);
                }
                File.AppendAllText(_logPath, DateTime.Now.ToString("O") + " [INFO] " + Sanitize(message) + Environment.NewLine, new UTF8Encoding(false));
            }
            catch { }
        }

        private void LogException(string message, Exception ex)
        {
            Log(message + ": " + ex.GetType().Name + " — " + ex.Message + Environment.NewLine + ex.StackTrace);
        }

        [DllImport("user32.dll", SetLastError = true)] private static extern bool MoveWindow(IntPtr hWnd, int x, int y, int width, int height, bool repaint);
        private delegate bool EnumWindowsCallback(IntPtr hWnd, IntPtr lParam);
        [DllImport("user32.dll")] private static extern bool EnumWindows(EnumWindowsCallback callback, IntPtr lParam);
        [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
        [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr hWnd);
        [DllImport("user32.dll")] private static extern bool ShowWindow(IntPtr hWnd, int command);
    }

    internal sealed class BetaBackendManager : IDisposable
    {
        private readonly string _root;
        private readonly string _serverAddress;
        private readonly Action<string> _log;
        private readonly List<Process> _processes = new List<Process>();
        private string _backendLogPath;
        private long _backendLogStartOffset;
        private volatile bool _disposed;

        public BetaBackendManager(string root, string serverAddress, Action<string> log) { _root = root; _serverAddress = serverAddress; _log = log; }

        public void StartAndVerify()
        {
            IPAddress bindAddress;
            if (!IPAddress.TryParse(_serverAddress, out bindAddress) || bindAddress.AddressFamily != AddressFamily.InterNetwork || !IsLocalAddress(bindAddress))
                throw new InvalidOperationException("The Online Beta backend can bind only to a private IPv4 address assigned to this computer.");
            string runtime = Path.Combine(_root, "backend", "runtime", "dotnet.exe");
            string servers = Path.Combine(_root, "backend", "servers");
            string dnasDirectory = Path.Combine(servers, "DNAS1");
            if (!File.Exists(runtime) || !File.Exists(Path.Combine(servers, "Horizon", "Horizon.dll")) || !File.Exists(Path.Combine(dnasDirectory, "DNAS1Server.dll")))
                throw new FileNotFoundException("The GT4 Online Beta backend is not installed. Reinstall the open source release.");
            ReleaseIntegrity.VerifyShippedFile(_root, "backend/servers/Horizon/Horizon.dll");
            foreach (string relative in new[]
            {
                "backend/servers/DNAS1/DNAS1Server.dll",
                "backend/servers/DNAS1/DNAS1Server.deps.json",
                "backend/servers/DNAS1/DNAS1Server.runtimeconfig.json",
                "backend/servers/DNAS1/BouncyCastle.Cryptography.dll",
                "backend/servers/DNAS1/keys/dnas1.us.chain.crt",
                "backend/servers/DNAS1/keys/dnas1.us.key"
            }) ReleaseIntegrity.VerifyShippedFile(_root, relative);
            ConfigureForSelectedInterface(Path.Combine(servers, "Horizon", "static"));
            bool startCleanBackend = CleanupOwnedBackendProcesses(runtime, Path.Combine(servers, "Horizon", "Horizon.dll"), Path.Combine(dnasDirectory, "DNAS1Server.dll"));
            if (!startCleanBackend)
            {
                _log("Reusing the already-running GT4 Online backend because every required service is healthy on " + _serverAddress + ".");
                return;
            }
            Start(runtime, dnasDirectory, "DNAS1Server.dll", "dnas-backend.log");
            Start(runtime, Path.Combine(servers, "Horizon"), "Horizon.dll", "medius-backend.log");
            Stopwatch wait = Stopwatch.StartNew();
            while (wait.ElapsedMilliseconds < 75000)
            {
                if (_processes.Any(p => p.HasExited)) throw new InvalidOperationException("The private backend stopped during startup. Export a Support ZIP for the backend logs.");
                // GT4 Online Public Beta (application 10782) has no SVO URL in the
                // bundled universe table. Its required path is MUIS -> MAS -> DME.
                // Requiring an unrelated, unshipped SVO web tree caused valid
                // Medius startup to time out and left guests launching alone.
                // Authentication takes several seconds. Checking the live service
                // sockets first created hundreds of short connections, flooded the
                // backend log and could starve startup. Wait for this run's two
                // authenticated clients, then probe each public service once.
                if (BackendAuthenticationReady() && BackendNatReady() && IsListening(_serverAddress, 443) && CanConnect(_serverAddress, 10071) && CanConnect(_serverAddress, 10075) && CanConnect(_serverAddress, 10073))
                {
                    _log("GT4 Online Beta DNAS, NAT, MUIS, MAS and DME ports and authenticated routing are ready on " + _serverAddress + ".");
                    return;
                }
                Thread.Sleep(250);
            }
            throw new TimeoutException("The private GT4 Online Beta backend did not become ready within 75 seconds. Export a Support ZIP for the Medius log.");
        }

        private bool CleanupOwnedBackendProcesses(string runtime, string horizonAssembly, string dnasAssembly)
        {
            string expectedRuntime = Path.GetFullPath(runtime);
            string expectedHorizon = Path.GetFullPath(horizonAssembly);
            string expectedDnas = Path.GetFullPath(dnasAssembly);
            var terminated = new List<Process>();
            try
            {
                using (var searcher = new ManagementObjectSearcher("SELECT ProcessId, ExecutablePath, CommandLine FROM Win32_Process WHERE Name='dotnet.exe'"))
                using (ManagementObjectCollection results = searcher.Get())
                {
                    foreach (ManagementObject item in results)
                    using (item)
                    {
                        string executable = Convert.ToString(item["ExecutablePath"]);
                        string commandLine = Convert.ToString(item["CommandLine"]);
                        if (!IsOwnedBackendCommand(executable, commandLine, expectedRuntime, expectedHorizon, expectedDnas)) continue;
                        int processId = Convert.ToInt32((uint)item["ProcessId"]);
                        Process process = Process.GetProcessById(processId);
                        if (process.HasExited) { process.Dispose(); continue; }
                        process.Kill();
                        terminated.Add(process);
                        _log("Closed stale GT4 Online backend process " + processId + " before starting a clean session.");
                    }
                }
                foreach (Process process in terminated)
                {
                    try { process.WaitForExit(5000); } finally { process.Dispose(); }
                }
            }
            catch (ManagementException ex)
            {
                _log("Could not inspect stale GT4 backend processes: " + ex.Message);
            }
            catch (UnauthorizedAccessException ex)
            {
                bool dnasReady = IsListening(_serverAddress, 443);
                bool natReady = IsUdpListening(_serverAddress, 10070);
                bool muisReady = CanConnect(_serverAddress, 10071);
                bool masReady = CanConnect(_serverAddress, 10075);
                bool dmeReady = CanConnect(_serverAddress, 10073);
                _log("Protected backend service check: DNAS=" + dnasReady + ", NAT=" + natReady + ", MUIS=" + muisReady + ", MAS=" + masReady + ", DME=" + dmeReady + ".");
                if (!dnasReady && !natReady && !muisReady && !masReady && !dmeReady)
                {
                    _log("The protected GT4 backend process is inert and owns no game-service ports; continuing with a clean backend start.");
                    return true;
                }
                if (natReady && muisReady && masReady && dmeReady)
                {
                    if (!dnasReady)
                    {
                        Start(expectedRuntime, Path.GetDirectoryName(expectedDnas), Path.GetFileName(expectedDnas), "dnas-backend.log");
                        Stopwatch wait = Stopwatch.StartNew();
                        while (wait.ElapsedMilliseconds < 15000 && !IsListening(_serverAddress, 443))
                        {
                            if (_processes.Any(p => p.HasExited)) throw new InvalidOperationException("The replacement DNAS service stopped during recovery.", ex);
                            Thread.Sleep(200);
                        }
                        if (!IsListening(_serverAddress, 443)) throw new InvalidOperationException("The replacement DNAS service did not become ready during recovery.", ex);
                    }
                    _log("Windows kept a protected GT4 Horizon process running; verified its service ports and recovered DNAS for this session.");
                    return false;
                }
                throw new InvalidOperationException("A previous GT4 Online backend is still running and Windows would not allow the launcher to close it. Restart Windows once, then try Host Match again.", ex);
            }
            return true;
        }

        internal static bool IsOwnedBackendCommand(string executable, string commandLine, string expectedRuntime, string expectedHorizon, string expectedDnas)
        {
            if (string.IsNullOrWhiteSpace(executable) || string.IsNullOrWhiteSpace(commandLine)) return false;
            string fullExecutable;
            try { fullExecutable = Path.GetFullPath(executable); } catch { return false; }
            if (!string.Equals(fullExecutable, expectedRuntime, StringComparison.OrdinalIgnoreCase)) return false;
            return commandLine.IndexOf(expectedHorizon, StringComparison.OrdinalIgnoreCase) >= 0 ||
                   commandLine.IndexOf(expectedDnas, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private void ConfigureForSelectedInterface(string staticDirectory)
        {
            if (!Directory.Exists(staticDirectory)) throw new DirectoryNotFoundException("The GT4 Online server configuration is missing.");
            string natPath = Path.Combine(staticDirectory, "nat.json");
            if (!File.Exists(natPath))
                File.WriteAllText(natPath, "{\r\n  \"Port\": 10070\r\n}\r\n", new UTF8Encoding(false));
            string[] files = { "medius.json", "muis.json", "dme.json", "bwps.json", "nat.json", "horizon.json", "MultiServerLibrary.json" };
            foreach (string name in files)
            {
                string path = Path.Combine(staticDirectory, name);
                if (!File.Exists(path)) continue;
                string text = File.ReadAllText(path, Encoding.UTF8);
                string jsonStaticDirectory = staticDirectory.Replace("\\", "\\\\");
                text = Regex.Replace(text, @"[A-Za-z]:\\\\(?:[^""\r\n]|\\\\.)*?[\\/]static", delegate(Match ignored) { return jsonStaticDirectory; }, RegexOptions.IgnoreCase);
                text = SetJsonString(text, "PublicIpOverride", _serverAddress);
                text = SetJsonBoolean(text, "UsePublicIp", false);
                text = SetJsonBoolean(text, "use_public_ip", false);
                text = SetJsonBoolean(text, "enable_server_ip_auto_negotiation", false);
                foreach (string key in new[] { "MUISIp", "MEDIUSIp", "NATIp", "DMEIp", "BWPSIp", "MUCGServerIP", "BillingProviderIpAddr", "MUMIp", "Endpoint", "Ip", "fallback_server_ip" })
                    text = SetJsonString(text, key, _serverAddress);
                if (string.Equals(name, "dme.json", StringComparison.OrdinalIgnoreCase))
                    text = SetJsonIntegerArray(text, "ApplicationIds", 10782);
                if (string.Equals(name, "muis.json", StringComparison.OrdinalIgnoreCase))
                    text = SetJsonIntegerArray(text, "CompatibleApplicationIds", 10782);
                if (string.Equals(name, "horizon.json", StringComparison.OrdinalIgnoreCase))
                    text = Regex.Replace(text, "(\\\"nat\\\"\\s*:\\s*\\{[\\s\\S]*?\\\"enabled\\\"\\s*:\\s*)(?:true|false)", "$1true", RegexOptions.IgnoreCase);
                text = Regex.Replace(text, "(\\\"MFSTransferURI\\\"\\s*:\\s*\\\"https?://)(?:\\d{1,3}\\.){3}\\d{1,3}", delegate(Match match) { return match.Groups[1].Value + _serverAddress; }, RegexOptions.IgnoreCase);
                File.WriteAllText(path, text, new UTF8Encoding(false));
            }
            File.WriteAllText(Path.Combine(staticDirectory, "gtb-active-interface.txt"), _serverAddress + Environment.NewLine, new UTF8Encoding(false));
            _log("Configured GT4 Online backend advertisements and internal service links for " + _serverAddress + ".");
        }

        private static string SetJsonString(string text, string key, string value)
        {
            return Regex.Replace(text, "(\\\"" + Regex.Escape(key) + "\\\"\\s*:\\s*\\\")[^\\\"]*(\\\")", delegate(Match match) { return match.Groups[1].Value + value + match.Groups[2].Value; }, RegexOptions.IgnoreCase);
        }

        private static string SetJsonBoolean(string text, string key, bool value)
        {
            return Regex.Replace(text, "(\\\"" + Regex.Escape(key) + "\\\"\\s*:\\s*)(?:true|false)", delegate(Match match) { return match.Groups[1].Value + (value ? "true" : "false"); }, RegexOptions.IgnoreCase);
        }

        private static string SetJsonIntegerArray(string text, string key, int value)
        {
            return Regex.Replace(text, "(\\\"" + Regex.Escape(key) + "\\\"\\s*:\\s*)\\[(?:\\s*\\d+\\s*,?)*\\]", delegate(Match match) { return match.Groups[1].Value + "[\n    " + value + "\n  ]"; }, RegexOptions.IgnoreCase);
        }

        private void Start(string runtime, string workingDirectory, string assembly, string logName)
        {
            string logPath = Path.Combine(_root, "logs", logName);
            _backendLogPath = logPath;
            Directory.CreateDirectory(Path.GetDirectoryName(logPath));
            Append(logPath, "==== GTB BACKEND RUN " + Guid.NewGuid().ToString("N") + " ====");
            try { _backendLogStartOffset = new FileInfo(logPath).Length; } catch { _backendLogStartOffset = 0; }
            var start = new ProcessStartInfo(runtime, "\"" + Path.Combine(workingDirectory, assembly) + "\"")
            {
                WorkingDirectory = workingDirectory,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };
            start.EnvironmentVariables["DOTNET_ROOT"] = Path.GetDirectoryName(runtime);
            start.EnvironmentVariables["DOTNET_RUNNING_IN_CONTAINER"] = "true";
            start.EnvironmentVariables["GTB_EMBEDDED"] = "1";
            start.EnvironmentVariables["GTB_BIND_IP"] = _serverAddress;
            start.EnvironmentVariables["DNAS_BIND_IP"] = _serverAddress;
            start.EnvironmentVariables["DNAS_REGION"] = "us";
            Process process = new Process { StartInfo = start, EnableRaisingEvents = true };
            process.OutputDataReceived += delegate(object sender, DataReceivedEventArgs e) { if (e.Data != null) Append(logPath, e.Data); };
            process.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs e) { if (e.Data != null) Append(logPath, "ERROR " + e.Data); };
            if (!process.Start()) throw new InvalidOperationException("Could not start " + assembly + ".");
            process.BeginOutputReadLine(); process.BeginErrorReadLine(); _processes.Add(process);
            _log("Started GT4 Online Beta backend component " + assembly + " (PID " + process.Id + ").");
        }

        private bool BackendAuthenticationReady()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(_backendLogPath) || !File.Exists(_backendLogPath)) return false;
                string text;
                using (var stream = new FileStream(_backendLogPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                {
                    if (_backendLogStartOffset > 0 && _backendLogStartOffset < stream.Length) stream.Position = _backendLogStartOffset;
                    using (var reader = new StreamReader(stream, Encoding.UTF8, true, 4096, false)) text = reader.ReadToEnd();
                }
                int start = text.LastIndexOf("Initializing DME components", StringComparison.OrdinalIgnoreCase);
                if (start >= 0) text = text.Substring(start);
                if (text.IndexOf("Failed to authenticate with the MAS server", StringComparison.OrdinalIgnoreCase) >= 0) return false;
                if (text.IndexOf("UNHANDLED MAS MESSAGE: Id: RT_MSG_SERVER_CRYPTKEY_GAME", StringComparison.OrdinalIgnoreCase) >= 0) return false;
                return text.IndexOf("[MASClient] - Authenticated application 10782", StringComparison.OrdinalIgnoreCase) >= 0 &&
                       text.IndexOf("[MPSClient] - Authenticated application 10782", StringComparison.OrdinalIgnoreCase) >= 0;
            }
            catch { return false; }
        }

        private bool BackendNatReady()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(_backendLogPath) || !File.Exists(_backendLogPath)) return false;
                string text;
                using (var stream = new FileStream(_backendLogPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                {
                    if (_backendLogStartOffset > 0 && _backendLogStartOffset < stream.Length) stream.Position = _backendLogStartOffset;
                    using (var reader = new StreamReader(stream, Encoding.UTF8, true, 4096, false)) text = reader.ReadToEnd();
                }
                return text.IndexOf("[NATClass] - Initialized server", StringComparison.OrdinalIgnoreCase) >= 0 &&
                       text.IndexOf("SocketException (10048)", StringComparison.OrdinalIgnoreCase) < 0;
            }
            catch { return false; }
        }

        private static bool CanConnect(string host, int port)
        {
            try
            {
                using (var client = new TcpClient())
                {
                    IAsyncResult ar = client.BeginConnect(host, port, null, null);
                    using (ar.AsyncWaitHandle)
                    {
                        if (!ar.AsyncWaitHandle.WaitOne(750)) return false;
                        client.EndConnect(ar);
                        return client.Connected;
                    }
                }
            }
            catch { return false; }
        }

        private static bool IsListening(string host, int port)
        {
            IPAddress expected;
            if (!IPAddress.TryParse(host, out expected)) return false;
            try
            {
                return IPGlobalProperties.GetIPGlobalProperties().GetActiveTcpListeners().Any(endpoint =>
                    endpoint.Port == port && (endpoint.Address.Equals(expected) || endpoint.Address.Equals(IPAddress.Any)));
            }
            catch { return CanConnect(host, port); }
        }

        private static bool IsUdpListening(string host, int port)
        {
            IPAddress expected;
            if (!IPAddress.TryParse(host, out expected)) return false;
            try
            {
                return IPGlobalProperties.GetIPGlobalProperties().GetActiveUdpListeners().Any(endpoint =>
                    endpoint.Port == port && (endpoint.Address.Equals(expected) || endpoint.Address.Equals(IPAddress.Any)));
            }
            catch { return false; }
        }

        private static bool IsLocalAddress(IPAddress address)
        {
            byte[] b = address.GetAddressBytes(); bool privateAddress = b[0] == 10 || (b[0] == 172 && b[1] >= 16 && b[1] <= 31) || (b[0] == 192 && b[1] == 168);
            if (!privateAddress) return false;
            try { return Dns.GetHostAddresses(Dns.GetHostName()).Any(x => x.AddressFamily == AddressFamily.InterNetwork && x.Equals(address)); } catch { return false; }
        }

        private static void Append(string path, string line)
        {
            try { lock (typeof(BetaBackendManager)) File.AppendAllText(path, DateTime.Now.ToString("O") + " " + line + Environment.NewLine, new UTF8Encoding(false)); } catch { }
        }

        public void Dispose()
        {
            if (_disposed) return; _disposed = true;
            foreach (Process process in _processes.ToArray())
            {
                try { if (!process.HasExited) { process.CloseMainWindow(); if (!process.WaitForExit(1500)) process.Kill(); } } catch { }
                try { process.Dispose(); } catch { }
            }
            _processes.Clear(); _log("GT4 Online Beta backend stopped.");
        }

        public static int SelfTest(string root)
        {
            string logs = Path.Combine(root, "logs"); Directory.CreateDirectory(logs);
            string reportPath = Path.Combine(logs, "beta-backend-self-test.txt");
            var lines = new List<string> { "Gran Turismo Bulgaria GT4 Online backend test " + DateTime.Now.ToString("O") };
            BetaBackendManager backend = null;
            try
            {
                string requested = Environment.GetEnvironmentVariable("GTB_TEST_BIND_IP");
                ConnectionProfile profile = string.IsNullOrWhiteSpace(requested) ? NetworkAdapterProbe.Detect(ConnectionTransport.ZeroTier) : null;
                string address = string.IsNullOrWhiteSpace(requested) ? (profile != null && profile.Available ? profile.IPv4 : NetworkAdapterProbe.Detect(ConnectionTransport.PhysicalLan).IPv4) : requested;
                if (string.IsNullOrWhiteSpace(address)) throw new InvalidOperationException("No private IPv4 interface was available for the test.");
                backend = new BetaBackendManager(root, address, delegate(string message) { lines.Add("INFO " + message); });
                backend.StartAndVerify();
                lines.Add("PASS GT4 Online DNAS/NAT/MUIS/MAS/DME ready on selected interface " + address);
                using (var nat = new UdpClient(new IPEndPoint(IPAddress.Parse(address), 0)))
                {
                    nat.Client.ReceiveTimeout = 2500;
                    nat.Connect(address, 10070);
                    int sourcePort = ((IPEndPoint)nat.Client.LocalEndPoint).Port;
                    byte[] request = new byte[4];
                    nat.Send(request, request.Length);
                    IPEndPoint sender = new IPEndPoint(IPAddress.Any, 0);
                    byte[] response = nat.Receive(ref sender);
                    if (response.Length != 6 || !response.Take(4).SequenceEqual(IPAddress.Parse(address).GetAddressBytes()) ||
                        ((response[4] << 8) | response[5]) != sourcePort)
                        throw new InvalidDataException("The NAT service returned an invalid address or port.");
                    lines.Add("PASS live NAT request/reply with correct IPv4 address and source port.");
                }
                lines.Add("RESULT PASS");
                File.WriteAllLines(reportPath, lines.ToArray(), new UTF8Encoding(false));
                return 0;
            }
            catch (Exception ex)
            {
                lines.Add("FAIL " + ex.GetType().Name + ": " + ex.Message); lines.Add("RESULT FAIL");
                File.WriteAllLines(reportPath, lines.ToArray(), new UTF8Encoding(false));
                return 1;
            }
            finally { if (backend != null) backend.Dispose(); }
        }
    }

    internal sealed class PineClient : IDisposable
    {
        private readonly TcpClient _client;
        private readonly NetworkStream _stream;
        public PineClient(int port, int timeoutMs)
        {
            _client = new TcpClient();
            IAsyncResult pending = _client.BeginConnect(IPAddress.Loopback, port, null, null);
            if (!pending.AsyncWaitHandle.WaitOne(timeoutMs)) { _client.Close(); throw new TimeoutException("PCSX2 PINE did not answer on port " + port + "."); }
            _client.EndConnect(pending); _client.ReceiveTimeout = timeoutMs; _client.SendTimeout = timeoutMs; _stream = _client.GetStream();
        }
        public string Title { get { return ReadString(0x0B); } }
        public string GameId { get { return ReadString(0x0C); } }
        public string Crc { get { return ReadString(0x0D); } }
        public string GameVersion { get { return ReadString(0x0E); } }
        public uint Read32(uint address)
        {
            byte[] command = new byte[5]; command[0] = 2; Array.Copy(BitConverter.GetBytes(address), 0, command, 1, 4);
            byte[] response = Exchange(command); if (response.Length != 4) throw new InvalidDataException("PINE Read32 returned an invalid payload.");
            return BitConverter.ToUInt32(response, 0);
        }
        public void Write32(uint address, uint value)
        {
            byte[] command = new byte[9]; command[0] = 6;
            Array.Copy(BitConverter.GetBytes(address), 0, command, 1, 4);
            Array.Copy(BitConverter.GetBytes(value), 0, command, 5, 4);
            byte[] response = Exchange(command);
            if (response.Length != 0) throw new InvalidDataException("PINE Write32 returned an invalid payload.");
        }
        public byte[] ReadWords(uint address, int wordCount)
        {
            if (wordCount < 1 || wordCount > 50000) throw new ArgumentOutOfRangeException("wordCount");
            byte[] command = new byte[wordCount * 5];
            for (int i = 0; i < wordCount; i++)
            {
                command[i * 5] = 2;
                Array.Copy(BitConverter.GetBytes(address + (uint)(i * 4)), 0, command, i * 5 + 1, 4);
            }
            byte[] response = Exchange(command);
            if (response.Length != wordCount * 4) throw new InvalidDataException("PINE bulk Read32 returned an invalid payload.");
            return response;
        }
        public float ReadFloat(uint address) { return BitConverter.ToSingle(BitConverter.GetBytes(Read32(address)), 0); }
        private string ReadString(byte opcode)
        {
            byte[] response = Exchange(new[] { opcode });
            if (response.Length < 4) throw new InvalidDataException("PINE string response is incomplete.");
            int size = BitConverter.ToInt32(response, 0); if (size < 1 || size > response.Length - 4) throw new InvalidDataException("PINE string length is invalid.");
            return Encoding.UTF8.GetString(response, 4, size - 1);
        }
        private byte[] Exchange(byte[] command)
        {
            byte[] packet = new byte[4 + command.Length]; Array.Copy(BitConverter.GetBytes(packet.Length), packet, 4); Array.Copy(command, 0, packet, 4, command.Length);
            _stream.Write(packet, 0, packet.Length); _stream.Flush();
            byte[] lengthBytes = ReadExact(4); int length = BitConverter.ToInt32(lengthBytes, 0);
            if (length < 5 || length > 650000) throw new InvalidDataException("PINE response length is invalid.");
            byte[] body = ReadExact(length - 4); if (body[0] != 0) throw new InvalidOperationException("PCSX2 rejected a PINE command.");
            byte[] payload = new byte[body.Length - 1]; Array.Copy(body, 1, payload, 0, payload.Length); return payload;
        }
        private byte[] ReadExact(int length)
        {
            byte[] result = new byte[length]; int offset = 0;
            while (offset < length) { int read = _stream.Read(result, offset, length - offset); if (read <= 0) throw new EndOfStreamException("PINE connection closed."); offset += read; }
            return result;
        }
        public void Dispose() { try { _stream.Dispose(); } catch { } try { _client.Close(); } catch { } }
    }

    internal sealed class Gt4RuntimeMonitor : IDisposable
    {
        // DNAS-net Patcher mode 3 sites for the verified SCUS-97436 / CRC 32A1C752
        // runtime. GT4 Online Beta requires the guarded SetStatus call to be
        // neutralized as well as changing state 6 (failed) to state 5
        // (authenticated). The same two changes are baked into DNAS310.IMG.
        private static readonly uint[] BetaDnasGuardSites = { 0x015A7F28u, 0x017D4E28u };
        private static readonly uint[] BetaDnasGuardInstructions = { 0x2484D6C4u, 0x24845484u };
        private static readonly uint[] BetaDnasStatusSites = { 0x015A7F34u, 0x017D4E34u };
        private const uint BetaDnasFailedInstruction = 0x24020006u;
        private const uint BetaDnasAuthenticatedInstruction = 0x24020005u;
        // Exact GT4 Online Beta addresses published by the original DNAS-net
        // Patcher scan. They are now used only as read-only proof that both
        // relocated DNAS copies are loaded; applying the full mode-1 function
        // patch caused the observed black-cursor freeze in this build.
        private static readonly uint[] BetaDnasMode1Bases = { 0x015A9E20u, 0x017D6D20u };
        private static readonly uint[] BetaDnasStateSites = { 0x016F64C0u, 0x0014ECC0u };
        private const uint NormalMarker = 0x21C0EEA4;
        private const uint ChampionshipMarker = 0x21C0F964;
        private const int CarSize = 4256;
        private readonly int _port; private readonly Process _process; private readonly PrivateSessionService _session; private readonly Action<string> _log; private readonly bool _retailLan;
        private volatile bool _stop; private Thread _thread; private int _lastRaceSecond = -1;
        public Gt4RuntimeMonitor(int port, Process process, PrivateSessionService session, Action<string> log, bool retailLan = false) { _port = port; _process = process; _session = session; _log = log; _retailLan = retailLan; }
        public void Start() { _thread = new Thread(Run) { IsBackground = true, Name = "GT4 verified runtime" }; _thread.Start(); }
        private void Run()
        {
            int failures = 0;
            bool transientFailureLogged = false;
            while (!_stop && IsProcessAlive())
            {
                try
                {
                    using (var pine = new PineClient(_port, 1500))
                    {
                        VerifyBuild(pine);
                        failures = 0; _log(_retailLan
                            ? "Verified GT4 USA v2.00 Arcade LAN runtime on PINE " + _port + " (SCUS-97328 / 77e61c8a / v2.00)."
                            : "Verified GT4 Online Beta runtime on PINE " + _port + " (SCUS-97436 / 32a1c752 / v1.00).");
                        bool betaMode3Logged = false, betaMode1Logged = false, betaStateLogged = false;
                        int lastDnasCopyCount = -1;
                        uint lastDnasState0 = uint.MaxValue, lastDnasState1 = uint.MaxValue;
                        while (!_stop && IsProcessAlive())
                        {
                            if (_retailLan) Sample(pine);
                            else
                            {
                                bool mode3Active = ApplyBetaDnasMode3(pine);
                                if (mode3Active && !betaMode3Logged)
                                {
                                    betaMode3Logged = true;
                                    _log("DNAS compatibility fallback 1/3 active: verified GT4 mode 3 status patch.");
                                }
                                int mode1CopyCount = CountBetaDnasMode1Copies(pine);
                                bool mode1Present = mode1CopyCount > 0;
                                if (mode1Present && (!betaMode1Logged || mode1CopyCount != lastDnasCopyCount))
                                {
                                    betaMode1Logged = true;
                                    lastDnasCopyCount = mode1CopyCount;
                                    _log("DNAS compatibility fallback 2/3 armed read-only: verified " + mode1CopyCount + " GT4 DNAS module cop" + (mode1CopyCount == 1 ? "y is" : "ies are") + " loaded. Unsafe mode 1 writes remain disabled.");
                                }
                                uint state0 = pine.Read32(BetaDnasStateSites[0]);
                                uint state1 = pine.Read32(BetaDnasStateSites[1]);
                                // Trace only the compact DNAS state range. This also lets
                                // support logs show the first-attempt transition when the
                                // first relocated copy is still loading, without recording
                                // unrelated values from an unloaded address.
                                if ((state0 <= 11u || state1 <= 11u) && (state0 != lastDnasState0 || state1 != lastDnasState1))
                                {
                                    lastDnasState0 = state0; lastDnasState1 = state1;
                                    _log("DNAS state trace: primary=" + state0 + ", secondary=" + state1 + ".");
                                }
                                string stateResult = (mode3Active || mode1Present) ? ApplyBetaDnasStateFallback(pine) : null;
                                if (stateResult != null && !betaStateLogged)
                                {
                                    betaStateLogged = true;
                                    _log("DNAS compatibility fallback 3/3 active: " + stateResult);
                                }
                            }
                            // The terminal DNAS state can be consumed by GT4 within a
                            // single frame. Poll Online Beta at 20 ms so the guarded
                            // correction is applied before the error page wins the race.
                            Thread.Sleep(_retailLan ? 250 : 20);
                        }
                    }
                }
                catch (Exception ex)
                {
                    failures++;
                    if (!_stop && IsProcessAlive() && failures >= 3 && !transientFailureLogged)
                    {
                        transientFailureLogged = true;
                        _log("GT4 runtime monitor is retrying after transient PINE startup failures: " + ex.Message);
                    }
                    if (!_stop && IsProcessAlive()) Thread.Sleep(750);
                }
            }
        }
        private bool IsProcessAlive() { try { return _process != null && !_process.HasExited; } catch { return false; } }
        internal static bool ApplyBetaDnasMode3(PineClient pine)
        {
            bool foundModule = false;
            for (int i = 0; i < BetaDnasStatusSites.Length; i++)
            {
                uint guard = pine.Read32(BetaDnasGuardSites[i]);
                uint status = pine.Read32(BetaDnasStatusSites[i]);
                if (guard == BetaDnasGuardInstructions[i])
                {
                    pine.Write32(BetaDnasGuardSites[i], 0u);
                    guard = pine.Read32(BetaDnasGuardSites[i]);
                    if (guard != 0u) throw new IOException("PCSX2 did not retain the verified DNAS guard write at module site " + (i + 1) + ".");
                }
                if (status == BetaDnasFailedInstruction)
                {
                    pine.Write32(BetaDnasStatusSites[i], BetaDnasAuthenticatedInstruction);
                    status = pine.Read32(BetaDnasStatusSites[i]);
                    if (status != BetaDnasAuthenticatedInstruction) throw new IOException("PCSX2 did not retain the verified DNAS status write at module site " + (i + 1) + ".");
                }
                if (guard == 0u && status == BetaDnasAuthenticatedInstruction) foundModule = true;
            }
            return foundModule;
        }
        internal static int CountBetaDnasMode1Copies(PineClient pine)
        {
            // The two relocated copies do not appear atomically. The first request
            // can finish while only one copy is visible, which previously meant the
            // guarded state fallback was armed only after the user pressed Retry.
            // These are fixed addresses in the already verified SCUS-97436 build;
            // only the exact original or previously patched instruction is accepted.
            int count = 0;
            foreach (uint start in BetaDnasMode1Bases)
            {
                uint value = pine.Read32(start + 0x54u);
                if (value == 0x03E00008u || value == 0x34030005u) count++;
            }
            return count;
        }
        internal static bool IsBetaDnasMode1Present(PineClient pine) { return CountBetaDnasMode1Copies(pine) > 0; }
        internal static string ApplyBetaDnasStateFallback(PineClient pine)
        {
            foreach (uint address in BetaDnasStateSites)
            {
                uint state = pine.Read32(address);
                // 6 and 7 are terminal DNAS failures; 11 is the aggressive
                // bypass state documented by the patch author. Never touch an
                // unknown value or an unloaded/zero page.
                if (state == 6u || state == 7u || state == 11u)
                {
                    pine.Write32(address, 5u);
                    if (pine.Read32(address) != 5u) throw new IOException("PCSX2 did not retain the verified DNAS state fallback write.");
                    return "converted GT4 DNAS state " + state + " to authenticated state 5 at 0x" + address.ToString("X8") + ".";
                }
            }
            return null;
        }
        internal static void VerifyBuild(PineClient pine)
        {
            UnifiedDisc.VerifyBuild(pine);
        }
        private void Sample(PineClient pine)
        {
            uint marker; uint carBase; uint raceClock;
            float normal = pine.ReadFloat(NormalMarker), champ = pine.ReadFloat(ChampionshipMarker);
            if (float.IsNaN(normal)) { marker = NormalMarker; raceClock = NormalMarker - 0xA4A0; }
            else if (float.IsNaN(champ)) { marker = ChampionshipMarker; raceClock = ChampionshipMarker - 0xA4A0; }
            else return;
            carBase = marker - 140 - CarSize;
            int milliseconds = unchecked((int)pine.Read32(raceClock)); int second = milliseconds / 1000;
            if (second == _lastRaceSecond) return; _lastRaceSecond = second;
            var cars = new StringBuilder();
            for (int i = 0; i < 6; i++)
            {
                // The public layout documents offsets relative to the NaN block, which starts 140 bytes into Automobile.
                uint car = carBase + (uint)(i * CarSize); float meters = pine.ReadFloat(car + 1448); short lap = unchecked((short)(pine.Read32(car + 1456) & 0xffff));
                if (i > 0) cars.Append(','); cars.Append(i + 1).Append(':').Append(lap).Append(':').Append(meters.ToString("0.0", System.Globalization.CultureInfo.InvariantCulture));
            }
            string snapshot = "raceMs=" + milliseconds + ";cars=" + cars;
            if (_session != null && _session.Connected && _session.Role == "HOST") try { _session.SendControl(20, Encoding.UTF8.GetBytes(snapshot)); } catch { }
        }
        public void Dispose() { _stop = true; try { if (_thread != null && _thread.IsAlive) _thread.Join(1200); } catch { } }
    }

    internal static class Gt4HookSelfTest
    {
        public static int Run(string root)
        {
            var lines = new List<string> { "Gran Turismo Bulgaria verified GT4 hook test " + DateTime.Now.ToString("O") }; Process process = null; bool ok = false;
            try
            {
                string defaultPcsx2 = File.Exists(Path.Combine(root, "runtime", "pcsx2-lan", "pcsx2-qtx64.exe")) ? Path.Combine(root, "runtime", "pcsx2-lan", "pcsx2-qtx64.exe") : Path.Combine(root, "runtime", "pcsx2", "pcsx2-qt.exe");
                string pcsx2 = MultiInstanceTest.TestAsset("GTB_TEST_PCSX2", defaultPcsx2);
                string iso = MultiInstanceTest.TestAsset("GTB_TEST_ISO", Path.Combine(root, "game", UnifiedDisc.FileName)); string data = Path.Combine(root, "data", "player1"); string ini = Path.Combine(data, "PCSX2", "inis", "PCSX2.ini");
                bool retailLan = string.Equals(Environment.GetEnvironmentVariable("GTB_TEST_RETAIL"), "1", StringComparison.Ordinal);
                string text = File.ReadAllText(ini); text = IniEditor.Set(text, "EnablePINE", "true"); text = IniEditor.Set(text, "PINESlot", "28011"); File.WriteAllText(ini, text, new UTF8Encoding(false));
                process = Process.Start(new ProcessStartInfo(pcsx2, "-datapath \"" + data + "\" -batch -nofullscreen -fastboot -- \"" + iso + "\"") { WorkingDirectory = Path.GetDirectoryName(pcsx2), UseShellExecute = false });
                Exception last = null; DateTime deadline = DateTime.UtcNow.AddSeconds(35);
                while (DateTime.UtcNow < deadline && !ok)
                {
                    try { using (var pine = new PineClient(28011, 1200)) { UnifiedDisc.VerifyBuild(pine); lines.Add("PASS identity " + pine.Title + " / " + pine.GameId + " / " + pine.Crc + " / " + pine.GameVersion); uint probe = pine.Read32(0x00100008u); lines.Add("PASS safe read coreEntryWord=0x" + probe.ToString("X8")); ok = true; } }
                    catch (Exception ex) { last = ex; Thread.Sleep(700); }
                }
                if (!ok) throw last ?? new TimeoutException("PCSX2 did not expose GT4 through PINE.");
            }
            catch (Exception ex) { lines.Add("FAIL " + ex); }
            finally { try { if (process != null && !process.HasExited) { process.CloseMainWindow(); if (!process.WaitForExit(2500)) process.Kill(); } } catch { } }
            lines.Add(ok ? "RESULT PASS" : "RESULT FAIL"); string logs = Path.Combine(root, "logs"); Directory.CreateDirectory(logs); File.WriteAllLines(Path.Combine(logs, "gt4-hook-self-test.txt"), lines.ToArray(), new UTF8Encoding(false)); return ok ? 0 : 1;
        }
    }

    internal static class Gt4BetaHookSelfTest
    {
        private const uint DumpStart = 0x00100000;
        private const int DumpLength = 0x00700000;

        public static int Run(string root, bool dumpMemory)
        {
            var lines = new List<string> { "Gran Turismo Bulgaria verified GT4 Online Beta test " + DateTime.Now.ToString("O") }; Process process = null; bool ok = false;
            try
            {
                string defaultPcsx2 = File.Exists(Path.Combine(root, "runtime", "pcsx2", "pcsx2-qt.exe")) ? Path.Combine(root, "runtime", "pcsx2", "pcsx2-qt.exe") : Path.Combine(root, "runtime", "pcsx2-lan", "pcsx2-qtx64.exe");
                string pcsx2 = MultiInstanceTest.TestAsset("GTB_TEST_PCSX2", defaultPcsx2);
                string iso = MultiInstanceTest.TestAsset("GTB_TEST_BETA_ISO", Path.Combine(root, "game", UnifiedDisc.FileName));
                string data = Path.Combine(root, "data", "player1"); string ini = Path.Combine(data, "PCSX2", "inis", "PCSX2.ini");
                string text = File.ReadAllText(ini); text = IniEditor.Set(text, "SetupWizardIncomplete", "false"); text = IniEditor.Set(text, "BIOS", "ps2-bios.bin"); text = IniEditor.Set(text, "EnablePINE", "true"); text = IniEditor.Set(text, "PINESlot", "28011"); File.WriteAllText(ini, text, new UTF8Encoding(false));
                process = Process.Start(new ProcessStartInfo(pcsx2, "-datapath \"" + data + "\" -batch -nofullscreen -fastboot -- \"" + iso + "\"") { WorkingDirectory = Path.GetDirectoryName(pcsx2), UseShellExecute = false });
                Exception last = null; DateTime deadline = DateTime.UtcNow.AddSeconds(45);
                while (DateTime.UtcNow < deadline && !ok)
                {
                    try
                    {
                        using (var pine = new PineClient(28011, 2000))
                        {
                            VerifyBuild(pine); lines.Add("PASS identity " + pine.Title + " / " + pine.GameId + " / " + pine.Crc + " / " + pine.GameVersion);
                            uint probe = 0; DateTime coreDeadline = DateTime.UtcNow.AddSeconds(30);
                            while (DateTime.UtcNow < coreDeadline && probe == 0) { probe = pine.Read32(DumpStart + 8); if (probe == 0) Thread.Sleep(250); }
                            if (probe == 0) throw new TimeoutException("GT4 Online Beta did not load CORE.GT4 into EE memory.");
                            lines.Add("PASS safe read coreEntryWord=0x" + probe.ToString("X8"));
                            pine.Write32(DumpStart + 8, probe);
                            if (pine.Read32(DumpStart + 8) != probe) throw new IOException("PINE verified no-op write/readback failed.");
                            lines.Add("PASS PINE write/readback transport (same-value safety test)");
                            Gt4BetaHookManifest.VerifyLive(pine);
                            lines.Add("PASS exact-build hook signatures " + Gt4BetaHookManifest.Sites.Length + "/" + Gt4BetaHookManifest.Sites.Length + " (read-only; writes remain disabled)");
                            if (dumpMemory)
                            {
                                string output = Path.Combine(root, "logs", "gt4-beta-ee-00100000-00800000.bin"); Directory.CreateDirectory(Path.GetDirectoryName(output));
                                using (var stream = new FileStream(output, FileMode.Create, FileAccess.Write, FileShare.None))
                                {
                                    int remaining = DumpLength; uint at = DumpStart;
                                    while (remaining > 0)
                                    {
                                        int words = Math.Min(50000, remaining / 4); byte[] block = pine.ReadWords(at, words); stream.Write(block, 0, block.Length); at += (uint)block.Length; remaining -= block.Length;
                                    }
                                    stream.Flush(true);
                                }
                                lines.Add("PASS exact-build read-only EE dump " + DumpLength + " bytes SHA256=" + HashFile(output));
                            }
                            ok = true;
                        }
                    }
                    catch (Exception ex) { last = ex; Thread.Sleep(700); }
                }
                if (!ok) throw last ?? new TimeoutException("PCSX2 did not expose GT4 Online Beta through PINE.");
            }
            catch (Exception ex) { lines.Add("FAIL " + ex); }
            finally { try { if (process != null && !process.HasExited) { process.CloseMainWindow(); if (!process.WaitForExit(2500)) process.Kill(); } } catch { } }
            lines.Add(ok ? "RESULT PASS" : "RESULT FAIL"); string logs = Path.Combine(root, "logs"); Directory.CreateDirectory(logs); File.WriteAllLines(Path.Combine(logs, dumpMemory ? "gt4-beta-memory-dump.txt" : "gt4-beta-hook-self-test.txt"), lines.ToArray(), new UTF8Encoding(false)); return ok ? 0 : 1;
        }

        internal static void VerifyBuild(PineClient pine)
        {
            UnifiedDisc.VerifyBuild(pine);
        }

        private static string HashFile(string path) { using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read)) using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(stream)).Replace("-", ""); }
    }

    internal static class ZeroTierManager
    {
        private static readonly Regex NetworkIdPattern = new Regex("^[0-9a-fA-F]{16}$", RegexOptions.Compiled | RegexOptions.CultureInvariant);

        internal static bool IsValidNetworkId(string value)
        {
            return !string.IsNullOrWhiteSpace(value) && NetworkIdPattern.IsMatch(value.Trim());
        }

        internal static string NormalizeNetworkId(string value)
        {
            if (!IsValidNetworkId(value)) throw new InvalidDataException("A ZeroTier Network ID must contain exactly 16 hexadecimal characters.");
            return value.Trim().ToLowerInvariant();
        }

        internal static string NodeId
        {
            get
            {
                try
                {
                    string identity = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "ZeroTier", "One", "identity.public");
                    string text = File.ReadAllText(identity).Trim();
                    string id = text.Split(':').FirstOrDefault();
                    return id != null && Regex.IsMatch(id, "^[0-9a-fA-F]{10}$") ? id.ToLowerInvariant() : "unavailable";
                }
                catch { return "unavailable"; }
            }
        }

        internal static string CliPath
        {
            get
            {
                string programData = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "ZeroTier", "One", "zerotier-one_x64.exe");
                if (File.Exists(programData)) return programData;
                string x86 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "ZeroTier", "One", "zerotier-one_x64.exe");
                return File.Exists(x86) ? x86 : null;
            }
        }

        internal static string[] LoadRecent(string root)
        {
            var result = new List<string>();
            try
            {
                string path = Path.Combine(root, "data", "zerotier-networks.txt");
                if (File.Exists(path))
                    foreach (string line in File.ReadAllLines(path))
                        if (IsValidNetworkId(line) && !result.Contains(NormalizeNetworkId(line), StringComparer.OrdinalIgnoreCase)) result.Add(NormalizeNetworkId(line));
            }
            catch { }
            return result.Take(12).ToArray();
        }

        internal static void SaveRecent(string root, string networkId)
        {
            string normalized = NormalizeNetworkId(networkId);
            var values = new List<string> { normalized };
            values.AddRange(LoadRecent(root).Where(x => !string.Equals(x, normalized, StringComparison.OrdinalIgnoreCase)));
            string path = Path.Combine(root, "data", "zerotier-networks.txt");
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            File.WriteAllLines(path, values.Take(12).ToArray(), new UTF8Encoding(false));
            File.WriteAllText(Path.Combine(root, "data", "zerotier-preferred-network.txt"), normalized, new UTF8Encoding(false));
        }

        internal static string PreferredNetwork(string root)
        {
            try
            {
                string path = Path.Combine(root, "data", "zerotier-preferred-network.txt");
                if (File.Exists(path) && IsValidNetworkId(File.ReadAllText(path).Trim())) return NormalizeNetworkId(File.ReadAllText(path).Trim());
            }
            catch { }
            return string.Empty;
        }

        internal static bool IsJoined(string networkId)
        {
            try
            {
                string normalized = NormalizeNetworkId(networkId);
                string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "ZeroTier", "One", "networks.d", normalized + ".conf");
                return File.Exists(path);
            }
            catch { return false; }
        }

        internal static string CurrentNetwork(string root)
        {
            string preferred = PreferredNetwork(root);
            if (IsJoined(preferred)) return preferred;
            try
            {
                string directory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "ZeroTier", "One", "networks.d");
                string joined = Directory.GetFiles(directory, "*.conf").Select(Path.GetFileNameWithoutExtension).FirstOrDefault(IsValidNetworkId);
                if (!string.IsNullOrWhiteSpace(joined)) return NormalizeNetworkId(joined);
            }
            catch { }
            return preferred;
        }

        internal static int ChangeMembership(string networkId, bool join)
        {
            string normalized = NormalizeNetworkId(networkId);
            string cli = CliPath;
            if (string.IsNullOrWhiteSpace(cli)) throw new FileNotFoundException("ZeroTier is not installed. Install ZeroTier One, then try again.");
            var info = new ProcessStartInfo
            {
                FileName = cli,
                Arguments = "-q " + (join ? "join " : "leave ") + normalized,
                UseShellExecute = true,
                Verb = "runas",
                WindowStyle = ProcessWindowStyle.Hidden,
                WorkingDirectory = Path.GetDirectoryName(cli)
            };
            using (Process process = Process.Start(info))
            {
                if (process == null) throw new InvalidOperationException("ZeroTier did not start.");
                if (!process.WaitForExit(30000)) throw new TimeoutException("ZeroTier did not finish within 30 seconds.");
                return process.ExitCode;
            }
        }
    }

    internal sealed class ZeroTierSetupForm : Form
    {
        private readonly string _root;
        private readonly TextBox _networkId = new TextBox();
        private readonly ComboBox _recent = new ComboBox();
        private readonly Label _status = LauncherForm.NewPublicLabel(10F, FontStyle.Regular, Color.FromArgb(192, 207, 218));
        private readonly Button _join;
        private readonly Button _leave;

        internal ZeroTierSetupForm(string root)
        {
            _root = root;
            Text = "Gran Turismo Bulgaria — ZeroTier Networks"; ClientSize = new Size(760, 520); BackColor = Color.FromArgb(11, 16, 21); ForeColor = Color.White;
            var title = LauncherForm.NewPublicLabel(21F, FontStyle.Bold, Color.White); title.Text = "ZEROTIER PRIVATE NETWORKS"; title.AutoSize = true; title.Location = new Point(34, 28); Controls.Add(title);
            var intro = LauncherForm.NewPublicLabel(10.5F, FontStyle.Regular, Color.FromArgb(180, 198, 209)); intro.Text = "Enter a private ZeroTier Network ID created by you or the host.\nOnly the 16 character Network ID is stored. Account logins and passwords are never requested."; intro.AutoSize = true; intro.Location = new Point(36, 74); Controls.Add(intro);

            var idLabel = LauncherForm.NewPublicLabel(9F, FontStyle.Bold, Color.FromArgb(235, 77, 86)); idLabel.Text = "ZEROTIER NETWORK ID"; idLabel.AutoSize = true; idLabel.Location = new Point(36, 138); Controls.Add(idLabel);
            _networkId.Location = new Point(36, 160); _networkId.Size = new Size(430, 31); _networkId.Font = new Font("Consolas", 13F); _networkId.MaxLength = 16; _networkId.CharacterCasing = CharacterCasing.Lower;
            _networkId.BackColor = Color.FromArgb(29, 37, 44); _networkId.ForeColor = Color.White; _networkId.Text = ZeroTierManager.PreferredNetwork(_root); Controls.Add(_networkId);
            _recent.DropDownStyle = ComboBoxStyle.DropDownList; _recent.FlatStyle = FlatStyle.Flat; _recent.BackColor = Color.FromArgb(29, 37, 44); _recent.ForeColor = Color.White;
            _recent.Location = new Point(482, 160); _recent.Size = new Size(240, 31); Controls.Add(_recent);
            ReloadRecent();
            _recent.SelectedIndexChanged += delegate { if (_recent.SelectedItem != null) _networkId.Text = _recent.SelectedItem.ToString(); };

            _join = NewButton("JOIN NETWORK", Color.FromArgb(0, 121, 76), 205); _join.Location = new Point(36, 216); _join.Click += async delegate { await ChangeMembershipAsync(true); }; Controls.Add(_join);
            _leave = NewButton("LEAVE NETWORK", Color.FromArgb(166, 28, 38), 205); _leave.Location = new Point(255, 216); _leave.Click += async delegate { await ChangeMembershipAsync(false); }; Controls.Add(_leave);
            var refresh = NewButton("REFRESH STATUS", Color.FromArgb(45, 55, 64), 205); refresh.Location = new Point(474, 216); refresh.Click += delegate { RefreshStatus(); }; Controls.Add(refresh);

            var node = LauncherForm.NewPublicLabel(10F, FontStyle.Bold, Color.FromArgb(132, 220, 182)); node.Text = "THIS PC DEVICE ID:  " + ZeroTierManager.NodeId; node.AutoSize = true; node.Location = new Point(36, 282); Controls.Add(node);
            var help = LauncherForm.NewPublicLabel(9.5F, FontStyle.Regular, Color.FromArgb(180, 198, 209)); help.Text = "For a network owned by another account: enter its Network ID, choose JOIN NETWORK, then ask that\nowner to authorize the Device ID shown above in ZeroTier Central. Other players repeat this once."; help.AutoSize = true; help.Location = new Point(36, 315); Controls.Add(help);
            _status.AutoSize = false; _status.Location = new Point(36, 375); _status.Size = new Size(686, 86); _status.BorderStyle = BorderStyle.FixedSingle; _status.Padding = new Padding(12); Controls.Add(_status);
            RefreshStatus();
        }

        private void ReloadRecent()
        {
            string selected = _networkId.Text;
            _recent.Items.Clear();
            foreach (string id in ZeroTierManager.LoadRecent(_root)) _recent.Items.Add(id);
            if (_recent.Items.Count > 0) _recent.SelectedIndex = Math.Max(0, Array.FindIndex(ZeroTierManager.LoadRecent(_root), x => string.Equals(x, selected, StringComparison.OrdinalIgnoreCase)));
        }

        private async Task ChangeMembershipAsync(bool join)
        {
            string id;
            try { id = ZeroTierManager.NormalizeNetworkId(_networkId.Text); }
            catch (Exception ex) { _status.Text = ex.Message; return; }
            _join.Enabled = _leave.Enabled = false;
            _status.Text = join ? "Windows will ask for administrator approval to join this private network…" : "Windows will ask for administrator approval to leave this network…";
            try
            {
                int exitCode = await Task.Run(() => ZeroTierManager.ChangeMembership(id, join));
                if (exitCode != 0) throw new InvalidOperationException("ZeroTier returned exit code " + exitCode + ".");
                if (join) { ZeroTierManager.SaveRecent(_root, id); ReloadRecent(); }
                await Task.Delay(1800);
                RefreshStatus();
                if (join && !NetworkAdapterProbe.Detect(ConnectionTransport.ZeroTier).Available)
                    _status.Text = "Join request sent for " + id + ". Ask the network owner to authorize Device ID " + ZeroTierManager.NodeId + ", then choose REFRESH STATUS.";
            }
            catch (Win32Exception ex) { _status.Text = ex.NativeErrorCode == 1223 ? "Administrator approval was cancelled. ZeroTier was not changed." : "ZeroTier could not " + (join ? "join" : "leave") + " the network: " + ex.Message; }
            catch (Exception ex) { _status.Text = "ZeroTier could not " + (join ? "join" : "leave") + " the network: " + ex.Message; }
            finally { _join.Enabled = _leave.Enabled = true; }
        }

        private void RefreshStatus()
        {
            ConnectionProfile profile = NetworkAdapterProbe.Detect(ConnectionTransport.ZeroTier);
            _status.ForeColor = profile.Available ? Color.FromArgb(105, 235, 170) : Color.FromArgb(245, 178, 90);
            _status.Text = profile.Available ? "READY — " + profile.Diagnostic + " Gran Turismo Bulgaria and PCSX2 will bind to this adapter." : "SETUP NEEDED — " + profile.Diagnostic;
        }

        private static Button NewButton(string text, Color color, int width)
        {
            var button = new Button { Text = text, Size = new Size(width, 42), FlatStyle = FlatStyle.Flat, BackColor = color, ForeColor = Color.White, Font = new Font("Segoe UI Semibold", 10F) };
            button.FlatAppearance.BorderSize = 0; return button;
        }
    }

    internal static class ZeroTierManagerSelfTest
    {
        internal static int Run(string root)
        {
            var lines = new List<string> { "Gran Turismo Bulgaria ZeroTier manager self-test " + DateTime.Now.ToString("O") };
            bool valid = ZeroTierManager.IsValidNetworkId("abcdef0123456789") && ZeroTierManager.NormalizeNetworkId("ABCDEF0123456789") == "abcdef0123456789";
            bool invalid = !ZeroTierManager.IsValidNetworkId("not-a-network") && !ZeroTierManager.IsValidNetworkId("abcdef012345678900");
            bool privateByDefault = ZeroTierManager.LoadRecent(root).Length == 0 || ZeroTierManager.LoadRecent(root).All(ZeroTierManager.IsValidNetworkId);
            lines.Add((valid ? "PASS" : "FAIL") + " strict 16-character hexadecimal Network ID validation");
            lines.Add((invalid ? "PASS" : "FAIL") + " invalid and overlong Network IDs rejected");
            lines.Add((privateByDefault ? "PASS" : "FAIL") + " no default ZeroTier Network ID is embedded");
            lines.Add("INFO nodeId=" + ZeroTierManager.NodeId + " cli=" + (ZeroTierManager.CliPath ?? "missing"));
            bool ok = valid && invalid && privateByDefault;
            lines.Add(ok ? "RESULT PASS" : "RESULT FAIL");
            string logs = Path.Combine(root, "logs"); Directory.CreateDirectory(logs); File.WriteAllLines(Path.Combine(logs, "zerotier-self-test.txt"), lines.ToArray(), new UTF8Encoding(false));
            return ok ? 0 : 1;
        }
    }

    internal static class NetworkAdapterProbe
    {
        private sealed class Candidate
        {
            public string Id;
            public string Name;
            public string Description;
            public string IPv4;
            public bool HasGateway;
            public bool Physical;
        }

        internal static ConnectionProfile Detect(ConnectionTransport requested)
        {
            List<Candidate> candidates = ReadCandidates();
            ConnectionTransport resolved = requested;
            Candidate selected = Find(candidates, resolved);
            string missing = resolved == ConnectionTransport.PhysicalLan ? "No active Ethernet or Wi-Fi adapter with IPv4 was found." : DisplayName(resolved) + " is not installed, connected, or assigned an IPv4 address.";
            return Profile(requested, resolved, selected, selected == null ? missing : "Ready on " + selected.Name + " — " + selected.IPv4 + ".");
        }

        internal static string Pcsx2Device() { return Detect(ConnectionTransport.PhysicalLan).AdapterGuid ?? "Auto"; }
        internal static string Pcsx2Device(ConnectionTransport transport) { return Detect(transport).AdapterGuid ?? "Auto"; }

        internal static string DisplayName(ConnectionTransport value)
        {
            switch (value)
            {
                case ConnectionTransport.PhysicalLan: return "LOCAL ROUTER / LAN";
                case ConnectionTransport.ZeroTier: return "ZEROTIER — REMOTE LAN";
                default: throw new ArgumentOutOfRangeException("value");
            }
        }

        internal static ConnectionTransport Parse(string value)
        {
            ConnectionTransport parsed;
            if (Enum.TryParse(value, true, out parsed) && (parsed == ConnectionTransport.ZeroTier || parsed == ConnectionTransport.PhysicalLan)) return parsed;
            throw new InvalidDataException("This invitation uses a connection type that is not supported by the public release.");
        }

        private static ConnectionProfile Profile(ConnectionTransport requested, ConnectionTransport resolved, Candidate selected, string diagnostic)
        {
            return new ConnectionProfile
            {
                Requested = requested, Resolved = resolved, DisplayName = DisplayName(resolved), Available = selected != null,
                AdapterGuid = selected == null ? "Auto" : selected.Id, IPv4 = selected == null ? null : selected.IPv4, Diagnostic = diagnostic
            };
        }

        private static Candidate Find(List<Candidate> candidates, ConnectionTransport transport)
        {
            if (transport == ConnectionTransport.PhysicalLan)
                return candidates.Where(x => x.Physical).OrderByDescending(x => x.HasGateway).FirstOrDefault();
            return candidates.FirstOrDefault(x => Matches(x.Name + " " + x.Description, transport));
        }

        private static bool Matches(string text, ConnectionTransport transport)
        {
            text = (text ?? "").ToLowerInvariant();
            if (transport == ConnectionTransport.ZeroTier) return text.Contains("zerotier");
            return false;
        }

        private static List<Candidate> ReadCandidates()
        {
            var result = new List<Candidate>();
            try
            {
                foreach (NetworkInterface adapter in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (adapter.OperationalStatus != OperationalStatus.Up || adapter.NetworkInterfaceType == NetworkInterfaceType.Loopback || adapter.NetworkInterfaceType == NetworkInterfaceType.Tunnel) continue;
                    UnicastIPAddressInformation ipv4 = adapter.GetIPProperties().UnicastAddresses.FirstOrDefault(x => x.Address.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(x.Address) && !x.Address.ToString().StartsWith("169.254.", StringComparison.Ordinal));
                    if (ipv4 == null) continue;
                    string combined = adapter.Name + " " + adapter.Description;
                    bool virtualLan = Matches(combined, ConnectionTransport.ZeroTier);
                    result.Add(new Candidate
                    {
                        Id = NormalizeGuid(adapter.Id), Name = adapter.Name, Description = adapter.Description, IPv4 = ipv4.Address.ToString(),
                        HasGateway = adapter.GetIPProperties().GatewayAddresses.Any(x => x.Address.AddressFamily == AddressFamily.InterNetwork && !x.Address.Equals(IPAddress.Any)),
                        Physical = !virtualLan
                    });
                }
            }
            catch { }
            return result;
        }

        private static string NormalizeGuid(string value)
        {
            Guid parsed;
            return Guid.TryParse(value, out parsed) ? "{" + parsed.ToString().ToUpperInvariant() + "}" : value;
        }
    }

    internal static class ConnectionTransportSelfTest
    {
        public static int Run(string root)
        {
            var lines = new List<string> { "Gran Turismo Bulgaria connection transport self-test " + DateTime.Now.ToString("O") };
            bool ok = true;
            try
            {
                ConnectionTransport[] values = (ConnectionTransport[])Enum.GetValues(typeof(ConnectionTransport));
                ok &= values.Length == 2;
                lines.Add((values.Length == 2 ? "PASS" : "FAIL") + " only ZeroTier and Local Router LAN are compiled into this release");
                ConnectionTransport[] visible = LauncherForm.VisibleConnectionTransports;
                bool streamlined = visible.Length == 2 && visible[0] == ConnectionTransport.ZeroTier && visible[1] == ConnectionTransport.PhysicalLan;
                ok &= streamlined;
                lines.Add((streamlined ? "PASS" : "FAIL") + " streamlined selector exposes only ZeroTier and Local Router/LAN");
                bool hostMapping = LauncherForm.VisibleConnectionIndex(ConnectionTransport.ZeroTier) == 0 && LauncherForm.VisibleConnectionIndex(ConnectionTransport.PhysicalLan) == 1;
                ok &= hostMapping;
                lines.Add((hostMapping ? "PASS" : "FAIL") + " host activation maps transport values to visible selector indexes");
                bool unique = values.Select(NetworkAdapterProbe.DisplayName).Distinct(StringComparer.OrdinalIgnoreCase).Count() == values.Length;
                ok &= unique; lines.Add((unique ? "PASS" : "FAIL") + " unique themed selector labels");
                foreach (ConnectionTransport value in values)
                {
                    ConnectionProfile profile = NetworkAdapterProbe.Detect(value);
                    bool noSilentFallback = profile.Resolved == value;
                    ok &= noSilentFallback;
                    lines.Add((noSilentFallback ? "PASS " : "FAIL ") + value + " resolved=" + profile.Resolved + " available=" + profile.Available + " adapter=" + (profile.AdapterGuid ?? "none") + " address=" + (profile.IPv4 ?? "none") + " diagnostic=" + profile.Diagnostic);
                }
            }
            catch (Exception ex) { ok = false; lines.Add("FAIL " + ex); }
            lines.Add(ok ? "RESULT PASS" : "RESULT FAIL");
            string logs = Path.Combine(root, "logs"); Directory.CreateDirectory(logs);
            File.WriteAllLines(Path.Combine(logs, "connection-transport-self-test.txt"), lines.ToArray(), new UTF8Encoding(false));
            return ok ? 0 : 1;
        }
    }

    internal abstract class PrivateSessionService : IDisposable
    {
        public string Role { get; protected set; }
        public string Invitation { get; protected set; }
        public string ServerAddress { get; protected set; }
        public volatile bool Connected;
        public string Status { get; protected set; }
        internal byte[] SessionSecret;
        internal SecureUdpRelay Relay;
        internal SecureControlChannel Control;
        public event Action<byte, byte[]> ControlMessage;
        public event Action ConnectionChanged;
        public string RelayStatus { get { return Relay == null ? "Relay not started" : Relay.Status; } }
        protected void AttachControl(Stream stream)
        {
            Control = CreateControl(stream, SessionSecret);
            Control.Closed += delegate { Connected = false; Status = "Private control channel closed."; };
        }
        protected SecureControlChannel CreateControl(Stream stream, byte[] controlSecret)
        {
            var channel = new SecureControlChannel(stream, controlSecret);
            channel.MessageReceived += delegate(byte type, byte[] payload) { Action<byte, byte[]> handler = ControlMessage; if (handler != null) handler(type, payload); };
            return channel;
        }
        protected void NotifyConnectionChanged()
        {
            Action handler = ConnectionChanged;
            if (handler != null) handler();
        }
        public virtual void SendControl(byte type, byte[] payload)
        {
            if (!Connected || Control == null) throw new InvalidOperationException("The private control channel is not ready.");
            Control.Send(type, payload ?? new byte[0]);
        }
        public abstract void StartRelay(int localGamePort = 3658);
        public abstract void Dispose();
    }

    internal sealed class PrivateSessionHost : PrivateSessionService
    {
        private readonly TcpListener _listener;
        private readonly byte[] _secret;
        private readonly object _peerLock = new object();
        private readonly List<TcpClient> _clients = new List<TcpClient>();
        private readonly List<SecureControlChannel> _controls = new List<SecureControlChannel>();
        private readonly object _rateLock = new object();
        private readonly Dictionary<string, Queue<DateTime>> _authAttempts = new Dictionary<string, Queue<DateTime>>(StringComparer.OrdinalIgnoreCase);
        private int _pendingPeers;
        private bool _disposed;
        public int Port { get; private set; }
        public int PeerCount { get { lock (_peerLock) return _clients.Count; } }

        private PrivateSessionHost(string publicIp, int port)
        {
            Role = "HOST"; Status = "Waiting for up to three friends…";
            ServerAddress = publicIp;
            _secret = new byte[32]; using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(_secret);
            SessionSecret = (byte[])_secret.Clone();
            _listener = new TcpListener(IPAddress.Any, port); _listener.Start(3);
            Port = ((IPEndPoint)_listener.LocalEndpoint).Port;
            Invitation = publicIp + ":" + Port + "#" + Convert.ToBase64String(_secret).TrimEnd('=').Replace('+', '-').Replace('/', '_');
            Task.Run((Action)AcceptLoop);
        }

        public static PrivateSessionHost Start(string publicIp, int port) { return new PrivateSessionHost(publicIp, port); }

        public override void StartRelay(int localGamePort = 3658)
        {
            if (!Connected) throw new InvalidOperationException("The friend must authenticate before the race relay starts.");
            if (Relay != null) Relay.Dispose();
            Relay = SecureUdpRelay.CreateHost(SessionSecret, Port, localGamePort);
        }

        private void AcceptLoop()
        {
            while (!_disposed)
            {
                try
                {
                    TcpClient client = _listener.AcceptTcpClient(); client.NoDelay = true;
                    client.ReceiveTimeout = 10000; client.SendTimeout = 10000;
                    IPEndPoint source = client.Client.RemoteEndPoint as IPEndPoint;
                    if (source == null || !AllowAuthentication(source.Address)) { client.Close(); continue; }
                    if (Interlocked.Increment(ref _pendingPeers) > 3) { Interlocked.Decrement(ref _pendingPeers); client.Close(); continue; }
                    Task.Run((Action)delegate { try { AuthenticatePeer(client); } finally { Interlocked.Decrement(ref _pendingPeers); } });
                }
                catch (Exception ex) { if (!_disposed) Status = "Host connection failed: " + ex.Message; }
            }
        }

        private bool AllowAuthentication(IPAddress address)
        {
            string key = address == null ? "unknown" : address.ToString();
            DateTime now = DateTime.UtcNow, cutoff = now.AddMinutes(-1);
            lock (_rateLock)
            {
                Queue<DateTime> attempts;
                if (!_authAttempts.TryGetValue(key, out attempts)) { attempts = new Queue<DateTime>(); _authAttempts[key] = attempts; }
                while (attempts.Count > 0 && attempts.Peek() < cutoff) attempts.Dequeue();
                if (attempts.Count >= 12) { Status = "Repeated connection attempts were rate-limited safely."; return false; }
                attempts.Enqueue(now);
                if (_authAttempts.Count > 128)
                {
                    foreach (string old in _authAttempts.Where(x => x.Value.Count == 0 || x.Value.Last() < cutoff).Select(x => x.Key).Take(_authAttempts.Count - 128).ToArray()) _authAttempts.Remove(old);
                }
                return true;
            }
        }

        private void AuthenticatePeer(TcpClient client)
        {
            try
            {
                byte[] controlSecret = SessionCrypto.AuthenticateHost(client.GetStream(), _secret);
                SecureControlChannel channel = CreateControl(client.GetStream(), controlSecret);
                Array.Clear(controlSecret, 0, controlSecret.Length);
                lock (_peerLock)
                {
                    if (_disposed || _clients.Count >= 3) { channel.Dispose(); client.Close(); return; }
                    _clients.Add(client); _controls.Add(channel); Connected = true;
                    Status = _clients.Count + " friend" + (_clients.Count == 1 ? "" : "s") + " authenticated — private room ready.";
                }
                NotifyConnectionChanged();
                channel.Closed += delegate { RemovePeer(client, channel); };
            }
            catch (Exception ex) { try { client.Close(); } catch { } if (!_disposed) Status = "A friend failed authentication: " + ex.Message; }
        }

        private void RemovePeer(TcpClient client, SecureControlChannel channel)
        {
            lock (_peerLock)
            {
                _clients.Remove(client); _controls.Remove(channel); Connected = _clients.Count > 0;
                Status = Connected ? _clients.Count + " friend" + (_clients.Count == 1 ? "" : "s") + " authenticated — private room ready." : "Waiting for up to three friends…";
            }
            NotifyConnectionChanged();
            try { client.Close(); } catch { }
        }

        public override void SendControl(byte type, byte[] payload)
        {
            SecureControlChannel[] targets; lock (_peerLock) targets = _controls.ToArray();
            if (targets.Length == 0) throw new InvalidOperationException("No authenticated friends are connected.");
            Exception failure = null; int sent = 0;
            foreach (SecureControlChannel channel in targets) try { channel.Send(type, payload ?? new byte[0]); sent++; } catch (Exception ex) { failure = ex; }
            if (sent == 0) throw failure ?? new IOException("No friend accepted the control message.");
        }

        public override void Dispose()
        {
            _disposed = true; Connected = false;
            try { _listener.Stop(); } catch { }
            lock (_peerLock)
            {
                foreach (SecureControlChannel channel in _controls) try { channel.Dispose(); } catch { }
                foreach (TcpClient client in _clients) try { client.Close(); } catch { }
                _controls.Clear(); _clients.Clear();
            }
            try { if (Relay != null) Relay.Dispose(); } catch { }
            Array.Clear(_secret, 0, _secret.Length);
            if (SessionSecret != null) Array.Clear(SessionSecret, 0, SessionSecret.Length);
            Invitation = null;
        }
    }

    internal sealed class PrivateSessionClient : PrivateSessionService
    {
        private TcpClient _client;
        private PrivateSessionClient() { Role = "JOIN"; }

        public static PrivateSessionClient Join(string invitation)
        {
            string[] halves = invitation.Trim().Split('#');
            if (halves.Length != 2) throw new FormatException("Invitation must contain address, port and private key.");
            int split = halves[0].LastIndexOf(':');
            if (split < 1) throw new FormatException("Invitation address is incomplete.");
            string host = halves[0].Substring(0, split);
            int port; if (!int.TryParse(halves[0].Substring(split + 1), out port) || port < 1 || port > 65535) throw new FormatException("Invitation port is invalid.");
            string b64 = halves[1].Replace('-', '+').Replace('_', '/'); while (b64.Length % 4 != 0) b64 += "=";
            byte[] secret = Convert.FromBase64String(b64);
            if (secret.Length != 32) throw new FormatException("Invitation private key is invalid.");
            var result = new PrivateSessionClient { Invitation = invitation, ServerAddress = host, Status = "Connecting…", _client = new TcpClient(), SessionSecret = (byte[])secret.Clone(), _host = host, _port = port };
            IAsyncResult ar = result._client.BeginConnect(host, port, null, null);
            if (!ar.AsyncWaitHandle.WaitOne(8000)) { result._client.Close(); throw new TimeoutException("The host did not answer within eight seconds."); }
            result._client.EndConnect(ar); result._client.NoDelay = true; result._client.ReceiveTimeout = 15000; result._client.SendTimeout = 15000;
            byte[] controlSecret = SessionCrypto.AuthenticateClient(result._client.GetStream(), secret);
            result.Control = result.CreateControl(result._client.GetStream(), controlSecret);
            result.Control.Closed += delegate { result.Connected = false; result.Status = "Private control channel closed."; };
            Array.Clear(controlSecret, 0, controlSecret.Length);
            result.Connected = true; result.Status = "Host authenticated — private room ready.";
            result.NotifyConnectionChanged();
            return result;
        }

        private string _host; private int _port;
        public override void StartRelay(int localGamePort = 3658)
        {
            if (!Connected) throw new InvalidOperationException("The host must authenticate before the race relay starts.");
            if (Relay != null) Relay.Dispose();
            Relay = SecureUdpRelay.CreateClient(SessionSecret, _host, _port, localGamePort);
        }
        public override void Dispose() { Connected = false; try { if (Control != null) Control.Dispose(); } catch { } try { if (_client != null) _client.Close(); } catch { } try { if (Relay != null) Relay.Dispose(); } catch { } if (SessionSecret != null) Array.Clear(SessionSecret, 0, SessionSecret.Length); Invitation = null; }
    }

    internal sealed class SecureControlChannel : IDisposable
    {
        private static readonly byte[] Magic = Encoding.ASCII.GetBytes("GTBC");
        private readonly Stream _stream;
        private readonly byte[] _encKey;
        private readonly byte[] _macKey;
        private readonly object _sendLock = new object();
        private long _sendSequence;
        private long _lastReceived;
        private volatile bool _running = true;
        public event Action<byte, byte[]> MessageReceived;
        public event Action Closed;

        public SecureControlChannel(Stream stream, byte[] secret)
        {
            _stream = stream;
            byte[] seed = Encoding.ASCII.GetBytes("GTB-CONTROL-V1").Concat(secret).ToArray();
            byte[] material; using (var sha = SHA512.Create()) material = sha.ComputeHash(seed);
            _encKey = material.Take(32).ToArray(); _macKey = material.Skip(32).Take(32).ToArray();
            Task.Run((Action)ReadLoop);
        }

        public void Send(byte type, byte[] payload)
        {
            if (!_running) throw new IOException("The campaign channel is closed.");
            if (payload.Length > 16 * 1024 * 1024) throw new InvalidDataException("Campaign package is too large.");
            byte[] iv = new byte[16]; using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(iv);
            byte[] cipher;
            using (var aes = new AesManaged { KeySize = 256, BlockSize = 128, Mode = CipherMode.CBC, Padding = PaddingMode.PKCS7, Key = _encKey, IV = iv })
            using (var transform = aes.CreateEncryptor()) cipher = transform.TransformFinalBlock(payload, 0, payload.Length);
            long sequence = Interlocked.Increment(ref _sendSequence);
            byte[] body = new byte[4 + 1 + 8 + 16 + 4 + cipher.Length];
            Buffer.BlockCopy(Magic, 0, body, 0, 4); body[4] = type; Buffer.BlockCopy(BitConverter.GetBytes(sequence), 0, body, 5, 8);
            Buffer.BlockCopy(iv, 0, body, 13, 16); Buffer.BlockCopy(BitConverter.GetBytes(cipher.Length), 0, body, 29, 4); Buffer.BlockCopy(cipher, 0, body, 33, cipher.Length);
            byte[] mac; using (var h = new HMACSHA256(_macKey)) mac = h.ComputeHash(body);
            byte[] frame = body.Concat(mac).ToArray(); byte[] length = BitConverter.GetBytes(frame.Length);
            lock (_sendLock) { _stream.Write(length, 0, length.Length); _stream.Write(frame, 0, frame.Length); _stream.Flush(); }
        }

        private void ReadLoop()
        {
            try
            {
                while (_running)
                {
                    int frameLength = BitConverter.ToInt32(SessionCrypto.ReadExactPublic(_stream, 4), 0);
                    if (frameLength < 81 || frameLength > 17 * 1024 * 1024) throw new InvalidDataException("Invalid campaign frame size.");
                    byte[] frame = SessionCrypto.ReadExactPublic(_stream, frameLength);
                    int bodyLength = frame.Length - 32; byte[] body = frame.Take(bodyLength).ToArray(); byte[] supplied = frame.Skip(bodyLength).ToArray();
                    if (!body.Take(4).SequenceEqual(Magic)) throw new InvalidDataException("Invalid campaign channel marker.");
                    byte[] expected; using (var h = new HMACSHA256(_macKey)) expected = h.ComputeHash(body);
                    if (!SessionCrypto.FixedEqualsPublic(supplied, expected)) throw new CryptographicException("Campaign channel authentication failed.");
                    byte type = body[4]; long sequence = BitConverter.ToInt64(body, 5); int cipherLength = BitConverter.ToInt32(body, 29);
                    if (sequence <= Interlocked.Read(ref _lastReceived)) throw new CryptographicException("Campaign replay or rollback frame rejected.");
                    if (cipherLength < 16 || 33 + cipherLength != body.Length) throw new InvalidDataException("Invalid encrypted campaign frame.");
                    byte[] iv = body.Skip(13).Take(16).ToArray(); byte[] cipher = body.Skip(33).Take(cipherLength).ToArray(); byte[] payload;
                    using (var aes = new AesManaged { KeySize = 256, BlockSize = 128, Mode = CipherMode.CBC, Padding = PaddingMode.PKCS7, Key = _encKey, IV = iv })
                    using (var transform = aes.CreateDecryptor()) payload = transform.TransformFinalBlock(cipher, 0, cipher.Length);
                    Interlocked.Exchange(ref _lastReceived, sequence);
                    Action<byte, byte[]> handler = MessageReceived; if (handler != null) handler(type, payload);
                }
            }
            catch { _running = false; }
            finally { Action closed = Closed; if (closed != null) try { closed(); } catch { } }
        }

        public void Dispose() { _running = false; Array.Clear(_encKey, 0, _encKey.Length); Array.Clear(_macKey, 0, _macKey.Length); }
    }

    internal sealed class SecureUdpRelay : IDisposable
    {
        private static readonly byte[] Magic = Encoding.ASCII.GetBytes("GTBU");
        private static readonly byte[] BridgeMagic = Encoding.ASCII.GetBytes("GTBP");
        private readonly byte[] _encKey;
        private readonly byte[] _macKey;
        private readonly UdpClient _tunnel;
        private readonly bool _host;
        private readonly int _localGamePort;
        private UdpClient _capture;
        private UdpClient _injector;
        private Process _captureProcess;
        private byte[] _captureToken;
        private bool _packetCapture;
        private readonly ManualResetEventSlim _captureReady = new ManualResetEventSlim(false);
        private IPEndPoint _remote;
        private readonly object _remoteLock = new object();
        private readonly List<IPEndPoint> _remotes = new List<IPEndPoint>();
        private readonly Dictionary<string, DateTime> _remoteLastSeen = new Dictionary<string, DateTime>();
        private long _sendSequence;
        private readonly object _replayLock = new object();
        private readonly Dictionary<string, ReplayWindow> _replay = new Dictionary<string, ReplayWindow>();
        private readonly object _injectedLock = new object();
        private readonly HashSet<string> _injected = new HashSet<string>();
        private readonly Queue<string> _injectedOrder = new Queue<string>();
        private volatile bool _running = true;
        private long _sent;
        private long _received;
        public string Status { get; private set; }
        public long SentPackets { get { return Interlocked.Read(ref _sent); } }
        public long ReceivedPackets { get { return Interlocked.Read(ref _received); } }
        public event Action<byte[]> PayloadReceived;

        private SecureUdpRelay(byte[] secret, bool host, int tunnelPort, string remoteHost, int remotePort, int localGamePort)
        {
            _host = host; _localGamePort = localGamePort;
            byte[] material; using (var sha = SHA512.Create()) material = sha.ComputeHash(secret);
            _encKey = material.Take(32).ToArray(); _macKey = material.Skip(32).Take(32).ToArray();
            if (host)
            {
                _tunnel = NewUdp(); _tunnel.Client.Bind(new IPEndPoint(IPAddress.Any, tunnelPort));
                Status = "Encrypted UDP relay listening on Proton port " + tunnelPort + ".";
            }
            else
            {
                _tunnel = NewUdp(); _tunnel.Client.Bind(new IPEndPoint(IPAddress.Any, 0));
                IPAddress address; if (!IPAddress.TryParse(remoteHost, out address)) address = Dns.GetHostAddresses(remoteHost).First(a => a.AddressFamily == AddressFamily.InterNetwork);
                _remote = new IPEndPoint(address, remotePort);
                Status = "Encrypted UDP relay connected to host.";
            }
            if (localGamePort > 0)
            {
                try { StartLocalBridge(); }
                catch { _running = false; try { _tunnel.Close(); } catch { } throw; }
            }
            Task.Run((Action)TunnelReceiveLoop);
            Task.Run((Action)KeepAliveLoop);
        }

        public static SecureUdpRelay CreateHost(byte[] secret, int tunnelPort, int localGamePort) { return new SecureUdpRelay(secret, true, tunnelPort, null, 0, localGamePort); }
        public static SecureUdpRelay CreateClient(byte[] secret, string remoteHost, int remotePort, int localGamePort) { return new SecureUdpRelay(secret, false, 0, remoteHost, remotePort, localGamePort); }

        private static UdpClient NewUdp()
        {
            var udp = new UdpClient(AddressFamily.InterNetwork); udp.ExclusiveAddressUse = false;
            udp.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
            udp.Client.ReceiveBufferSize = 128 * 1024;
            udp.Client.SendBufferSize = 1024 * 1024;
            return udp;
        }

        private void StartLocalBridge()
        {
            _injector = NewUdp(); _injector.EnableBroadcast = true;
            if (_localGamePort == 3658)
            {
                StartPacketCapture();
                return;
            }
            _capture = NewUdp(); _capture.EnableBroadcast = true; _capture.Client.Bind(new IPEndPoint(IPAddress.Any, _localGamePort));
            Task.Run((Action)CaptureLoop);
        }

        private void StartPacketCapture()
        {
            string helper = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "GT4PacketBridge.exe");
            string runtime = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "WinDivert-2.2.2-A.zip");
            if (!File.Exists(helper) || !File.Exists(runtime))
                throw new FileNotFoundException("The verified GT4 packet bridge is missing. Reinstall Gran Turismo Bulgaria.");
            ReleaseIntegrity.VerifyShippedFile(AppDomain.CurrentDomain.BaseDirectory, "GT4PacketBridge.exe");
            ReleaseIntegrity.VerifyShippedFile(AppDomain.CurrentDomain.BaseDirectory, "WinDivert-2.2.2-A.zip");
            _packetCapture = true;
            _captureToken = new byte[32]; using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(_captureToken);
            _capture = new UdpClient(new IPEndPoint(IPAddress.Loopback, 0));
            int bridgePort = ((IPEndPoint)_capture.Client.LocalEndPoint).Port;
            Task.Run((Action)CaptureLoop);
            string pipeName = "GTB-Bridge-" + RandomHex(24).ToLowerInvariant();
            using (NamedPipeServerStream pipe = CreateBridgePipe(pipeName))
            {
                var start = new ProcessStartInfo
                {
                    FileName = helper,
                    Arguments = Process.GetCurrentProcess().Id + " " + bridgePort + " " + pipeName,
                    UseShellExecute = true,
                    Verb = "runas",
                    WindowStyle = ProcessWindowStyle.Hidden
                };
                try { _captureProcess = Process.Start(start); }
                catch (Win32Exception ex)
                {
                    try { _capture.Close(); } catch { }
                    throw new InvalidOperationException("Secure GT4 packet capture needs administrator approval. No game traffic was opened or forwarded.", ex);
                }
                IAsyncResult connected = pipe.BeginWaitForConnection(null, null);
                if (!connected.AsyncWaitHandle.WaitOne(8000))
                {
                    try { if (_captureProcess != null && !_captureProcess.HasExited) _captureProcess.Kill(); } catch { }
                    throw new TimeoutException("The protected packet bridge handshake timed out.");
                }
                pipe.EndWaitForConnection(connected);
                using (var writer = new BinaryWriter(pipe, new UTF8Encoding(false), true))
                {
                    byte[] root = Encoding.UTF8.GetBytes(AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar));
                    writer.Write(Process.GetCurrentProcess().Id);
                    writer.Write(_captureToken.Length); writer.Write(_captureToken);
                    writer.Write(root.Length); writer.Write(root); writer.Flush();
                }
            }
            if (!_captureReady.Wait(8000))
            {
                int code = -1;
                try { if (_captureProcess.HasExited) code = _captureProcess.ExitCode; } catch { }
                try { if (_captureProcess != null && !_captureProcess.HasExited) _captureProcess.Kill(); } catch { }
                try { _capture.Close(); } catch { }
                throw new InvalidOperationException(code == 5
                    ? "Windows denied the signed GT4 packet-capture driver. Approve the administrator prompt and try again."
                    : "The GT4 packet bridge did not start (code " + code + "). Reinstall the app and export a Support ZIP if it repeats.");
            }
            Status = "Protected packet bridge ready — only packaged PCSX2 UDP port 3658 flows are captured.";
        }

        private static NamedPipeServerStream CreateBridgePipe(string name)
        {
            var security = new PipeSecurity();
            security.SetAccessRuleProtection(true, false);
            SecurityIdentifier user = WindowsIdentity.GetCurrent().User;
            security.AddAccessRule(new PipeAccessRule(user, PipeAccessRights.ReadWrite, AccessControlType.Allow));
            security.AddAccessRule(new PipeAccessRule(new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null), PipeAccessRights.ReadWrite, AccessControlType.Allow));
            security.AddAccessRule(new PipeAccessRule(new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid, null), PipeAccessRights.ReadWrite, AccessControlType.Allow));
            return new NamedPipeServerStream(name, PipeDirection.Out, 1, PipeTransmissionMode.Byte, PipeOptions.Asynchronous, 4096, 4096, security);
        }

        private static string RandomHex(int bytes)
        {
            byte[] value = new byte[bytes]; using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(value);
            return BitConverter.ToString(value).Replace("-", "");
        }

        private void KeepAliveLoop()
        {
            while (_running)
            {
                try { SendTunnel(0, new byte[0]); } catch { }
                Thread.Sleep(750);
            }
        }

        private void CaptureLoop()
        {
            var from = new IPEndPoint(IPAddress.Any, 0);
            while (_running)
            {
                try
                {
                    byte[] payload = _capture.Receive(ref from);
                    if (_packetCapture)
                    {
                        if (!IPAddress.Loopback.Equals(from.Address) || payload.Length < 38 || !payload.Take(4).SequenceEqual(BridgeMagic)) continue;
                        if (!SessionCrypto.FixedEqualsPublic(payload.Skip(4).Take(32).ToArray(), _captureToken)) continue;
                        int length = (payload[36] << 8) | payload[37];
                        if (length < 0 || length > 4096 || payload.Length != 38 + length) continue;
                        if (length == 0) { _captureReady.Set(); continue; }
                        payload = payload.Skip(38).Take(length).ToArray();
                        if ((_host && RemoteCount > 0) || (!_host && _remote != null)) SendTunnel(1, payload);
                        continue;
                    }
                    string fingerprint = Fingerprint(payload);
                    lock (_injectedLock)
                    {
                        if (_injected.Remove(fingerprint)) continue;
                    }
                    if ((_host && RemoteCount > 0) || (!_host && _remote != null)) SendTunnel(1, payload);
                }
                catch (SocketException) { if (_running) Status = "Local GT4 UDP capture stopped unexpectedly."; }
                catch (ObjectDisposedException) { }
            }
        }

        private void TunnelReceiveLoop()
        {
            var from = new IPEndPoint(IPAddress.Any, 0);
            while (_running)
            {
                try
                {
                    byte[] packet = _tunnel.Receive(ref from);
                    if (packet == null || packet.Length > 8192) continue;
                    byte type; long sequence; byte[] payload;
                    if (!TryOpen(packet, out type, out sequence, out payload)) continue;
                    if (_host)
                    {
                        if (!RegisterRemote(from)) continue;
                    }
                    else if (!_remote.Address.Equals(from.Address) || _remote.Port != from.Port) continue;
                    if (!AcceptSequence(from, sequence)) continue;
                    Interlocked.Increment(ref _received);
                    if (type == 1)
                    {
                        Action<byte[]> handler = PayloadReceived; if (handler != null) handler(payload);
                        if (_localGamePort > 0) InjectLocal(payload);
                        if (_host) BroadcastTunnel(1, payload, from);
                    }
                }
                catch (SocketException) { if (_running) Status = "Encrypted UDP relay stopped unexpectedly."; }
                catch (ObjectDisposedException) { }
                catch (Exception ex) { if (_running) Status = "Relay error: " + ex.Message; }
            }
        }

        private void InjectLocal(byte[] payload)
        {
            if (_packetCapture)
            {
                _injector.Send(payload, payload.Length, new IPEndPoint(IPAddress.Loopback, _localGamePort));
                return;
            }
            string fingerprint = Fingerprint(payload);
            lock (_injectedLock)
            {
                _injected.Add(fingerprint); _injectedOrder.Enqueue(fingerprint);
                while (_injectedOrder.Count > 256) _injected.Remove(_injectedOrder.Dequeue());
            }
            _injector.Send(payload, payload.Length, new IPEndPoint(IPAddress.Broadcast, _localGamePort));
        }

        public void SendPayload(byte[] payload) { if (payload == null || payload.Length > 4096) throw new ArgumentOutOfRangeException("payload"); SendTunnel(1, payload); }

        private void SendTunnel(byte type, byte[] payload)
        {
            if (_host) { BroadcastTunnel(type, payload, null); return; }
            IPEndPoint remote = _remote; if (remote == null) return;
            long sequence = Interlocked.Increment(ref _sendSequence);
            byte[] packet = Seal(type, sequence, payload);
            _tunnel.Send(packet, packet.Length, remote); Interlocked.Increment(ref _sent);
        }

        private int RemoteCount { get { lock (_remoteLock) return _remotes.Count; } }
        private bool RegisterRemote(IPEndPoint endpoint)
        {
            lock (_remoteLock)
            {
                PruneRemotesLocked();
                string key = EndpointKey(endpoint);
                if (_remotes.Any(x => x.Address.Equals(endpoint.Address) && x.Port == endpoint.Port)) { _remoteLastSeen[key] = DateTime.UtcNow; return true; }
                if (_remotes.Count >= 3) return false;
                _remotes.Add(new IPEndPoint(endpoint.Address, endpoint.Port));
                _remoteLastSeen[key] = DateTime.UtcNow;
                Status = _remotes.Count + " friend UDP path" + (_remotes.Count == 1 ? "" : "s") + " authenticated — race relay ready.";
                return true;
            }
        }
        private void BroadcastTunnel(byte type, byte[] payload, IPEndPoint except)
        {
            IPEndPoint[] targets;
            lock (_remoteLock) { PruneRemotesLocked(); targets = _remotes.Where(x => except == null || !x.Address.Equals(except.Address) || x.Port != except.Port).ToArray(); }
            if (targets.Length == 0) return;
            long sequence = Interlocked.Increment(ref _sendSequence); byte[] packet = Seal(type, sequence, payload);
            foreach (IPEndPoint target in targets) { _tunnel.Send(packet, packet.Length, target); Interlocked.Increment(ref _sent); }
        }

        private byte[] Seal(byte type, long sequence, byte[] payload)
        {
            byte[] iv = new byte[16]; using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(iv);
            byte[] cipher;
            using (var aes = new AesManaged { KeySize = 256, BlockSize = 128, Mode = CipherMode.CBC, Padding = PaddingMode.PKCS7, Key = _encKey, IV = iv })
            using (var transform = aes.CreateEncryptor()) cipher = transform.TransformFinalBlock(payload, 0, payload.Length);
            byte[] body = new byte[4 + 1 + 8 + 16 + 2 + cipher.Length];
            Buffer.BlockCopy(Magic, 0, body, 0, 4); body[4] = type; Buffer.BlockCopy(BitConverter.GetBytes(sequence), 0, body, 5, 8); Buffer.BlockCopy(iv, 0, body, 13, 16);
            Buffer.BlockCopy(BitConverter.GetBytes((ushort)cipher.Length), 0, body, 29, 2); Buffer.BlockCopy(cipher, 0, body, 31, cipher.Length);
            byte[] mac; using (var h = new HMACSHA256(_macKey)) mac = h.ComputeHash(body);
            return body.Concat(mac).ToArray();
        }

        private bool TryOpen(byte[] packet, out byte type, out long sequence, out byte[] payload)
        {
            type = 0; sequence = 0; payload = null;
            if (packet == null || packet.Length < 79 || !packet.Take(4).SequenceEqual(Magic)) return false;
            int bodyLength = packet.Length - 32; byte[] body = packet.Take(bodyLength).ToArray(); byte[] supplied = packet.Skip(bodyLength).ToArray();
            byte[] expected; using (var h = new HMACSHA256(_macKey)) expected = h.ComputeHash(body);
            if (!SessionCrypto.FixedEqualsPublic(supplied, expected)) return false;
            type = body[4]; sequence = BitConverter.ToInt64(body, 5); ushort cipherLength = BitConverter.ToUInt16(body, 29);
            if (cipherLength < 16 || 31 + cipherLength != body.Length) return false;
            byte[] iv = body.Skip(13).Take(16).ToArray(); byte[] cipher = body.Skip(31).Take(cipherLength).ToArray();
            try
            {
                using (var aes = new AesManaged { KeySize = 256, BlockSize = 128, Mode = CipherMode.CBC, Padding = PaddingMode.PKCS7, Key = _encKey, IV = iv })
                using (var transform = aes.CreateDecryptor()) payload = transform.TransformFinalBlock(cipher, 0, cipher.Length);
                return type <= 1;
            }
            catch (CryptographicException) { return false; }
        }

        private bool AcceptSequence(IPEndPoint sender, long sequence)
        {
            if (sequence <= 0) return false;
            string key = EndpointKey(sender);
            lock (_replayLock)
            {
                ReplayWindow window;
                if (!_replay.TryGetValue(key, out window)) { window = new ReplayWindow(); _replay[key] = window; }
                return window.Accept(sequence);
            }
        }

        private static string EndpointKey(IPEndPoint endpoint) { return endpoint.Address + ":" + endpoint.Port; }
        private void PruneRemotesLocked()
        {
            DateTime cutoff = DateTime.UtcNow.AddSeconds(-20);
            for (int i = _remotes.Count - 1; i >= 0; i--)
            {
                string key = EndpointKey(_remotes[i]); DateTime seen;
                if (!_remoteLastSeen.TryGetValue(key, out seen) || seen < cutoff) { _remoteLastSeen.Remove(key); _remotes.RemoveAt(i); lock (_replayLock) _replay.Remove(key); }
            }
        }

        private sealed class ReplayWindow
        {
            private long _highest;
            private ulong _bitmap;
            public bool Accept(long sequence)
            {
                if (sequence <= 0) return false;
                if (_highest == 0) { _highest = sequence; _bitmap = 1; return true; }
                if (sequence > _highest)
                {
                    long shift = sequence - _highest; _bitmap = shift >= 64 ? 1UL : (_bitmap << (int)shift) | 1UL; _highest = sequence; return true;
                }
                long behind = _highest - sequence; if (behind >= 64) return false;
                ulong mask = 1UL << (int)behind; if ((_bitmap & mask) != 0) return false; _bitmap |= mask; return true;
            }
        }

        private static string Fingerprint(byte[] payload) { using (var sha = SHA256.Create()) return Convert.ToBase64String(sha.ComputeHash(payload)); }
        public void Dispose()
        {
            _running = false;
            try { _tunnel.Close(); } catch { }
            try { if (_capture != null) _capture.Close(); } catch { }
            try { if (_injector != null) _injector.Close(); } catch { }
            try { if (_captureProcess != null && !_captureProcess.HasExited) _captureProcess.Kill(); } catch { }
            if (_captureToken != null) Array.Clear(_captureToken, 0, _captureToken.Length);
            Array.Clear(_encKey, 0, _encKey.Length); Array.Clear(_macKey, 0, _macKey.Length);
            _captureReady.Dispose();
            Status = "Relay stopped.";
        }
    }

    internal static class SessionCrypto
    {
        public static byte[] AuthenticateHost(Stream stream, byte[] secret)
        {
            byte[] clientNonce = ReadExact(stream, 32), hostNonce = RandomBytes(32);
            byte[] transcript = Combine(Encoding.ASCII.GetBytes("GTB-HANDSHAKE-V2-HOST"), Combine(clientNonce, hostNonce));
            byte[] proof = Hmac(secret, transcript);
            stream.Write(hostNonce, 0, hostNonce.Length); stream.Write(proof, 0, proof.Length); stream.Flush();
            byte[] response = ReadExact(stream, 32);
            byte[] expected = Hmac(secret, Combine(Encoding.ASCII.GetBytes("GTB-HANDSHAKE-V2-CLIENT"), Combine(hostNonce, clientNonce)));
            if (!FixedEquals(response, expected)) throw new CryptographicException("Friend authentication failed.");
            return Expand(secret, Combine(clientNonce, hostNonce), "GTB-CONTROL-SESSION-V2", 64);
        }

        public static byte[] AuthenticateClient(Stream stream, byte[] secret)
        {
            byte[] clientNonce = RandomBytes(32); stream.Write(clientNonce, 0, clientNonce.Length); stream.Flush();
            byte[] hostNonce = ReadExact(stream, 32), proof = ReadExact(stream, 32);
            byte[] expected = Hmac(secret, Combine(Encoding.ASCII.GetBytes("GTB-HANDSHAKE-V2-HOST"), Combine(clientNonce, hostNonce)));
            if (!FixedEquals(proof, expected)) throw new CryptographicException("Host authentication failed.");
            byte[] response = Hmac(secret, Combine(Encoding.ASCII.GetBytes("GTB-HANDSHAKE-V2-CLIENT"), Combine(hostNonce, clientNonce))); stream.Write(response, 0, response.Length); stream.Flush();
            return Expand(secret, Combine(clientNonce, hostNonce), "GTB-CONTROL-SESSION-V2", 64);
        }

        private static byte[] RandomBytes(int count) { byte[] b = new byte[count]; using (var r = RandomNumberGenerator.Create()) r.GetBytes(b); return b; }
        private static byte[] Hmac(byte[] key, byte[] data) { using (var h = new HMACSHA256(key)) return h.ComputeHash(data); }
        private static byte[] Expand(byte[] secret, byte[] salt, string label, int length)
        {
            byte[] prk = Hmac(salt, secret), result = new byte[length], previous = new byte[0], info = Encoding.ASCII.GetBytes(label); int at = 0; byte counter = 1;
            try
            {
                while (at < length)
                {
                    byte[] block = Hmac(prk, Combine(Combine(previous, info), new[] { counter++ }));
                    int take = Math.Min(block.Length, length - at); Buffer.BlockCopy(block, 0, result, at, take); at += take;
                    if (previous.Length > 0) Array.Clear(previous, 0, previous.Length); previous = block;
                }
                return result;
            }
            finally { Array.Clear(prk, 0, prk.Length); if (previous.Length > 0) Array.Clear(previous, 0, previous.Length); }
        }
        private static byte[] Combine(byte[] a, byte[] b) { byte[] c = new byte[a.Length + b.Length]; Buffer.BlockCopy(a, 0, c, 0, a.Length); Buffer.BlockCopy(b, 0, c, a.Length, b.Length); return c; }
        private static byte[] ReadExact(Stream stream, int count) { byte[] b = new byte[count]; int at = 0; while (at < count) { int n = stream.Read(b, at, count - at); if (n <= 0) throw new EndOfStreamException("Private session closed during authentication."); at += n; } return b; }
        internal static byte[] ReadExactPublic(Stream stream, int count) { return ReadExact(stream, count); }
        private static bool FixedEquals(byte[] a, byte[] b) { if (a.Length != b.Length) return false; int diff = 0; for (int i = 0; i < a.Length; i++) diff |= a[i] ^ b[i]; return diff == 0; }
        internal static bool FixedEqualsPublic(byte[] a, byte[] b) { return FixedEquals(a, b); }
    }

    internal sealed class CampaignInfo
    {
        public string Id;
        public string Name;
        public int Version;
        public string ParentHash;
        public string SaveHash;
        public string CreatedUtc;
        public string Committer;
        public string Signature;
    }

    internal sealed class SharedCampaignStore
    {
        private readonly string _root;
        private readonly string _campaignRoot;
        private static readonly UTF8Encoding Utf8 = new UTF8Encoding(false);
        public SharedCampaignStore(string root) { _root = root; _campaignRoot = Path.Combine(root, "data", "shared-campaign-store"); Directory.CreateDirectory(_campaignRoot); }

        public CampaignInfo Create(string name)
        {
            name = string.IsNullOrWhiteSpace(name) ? "Co-op Campaign" : name.Trim();
            string id = Guid.NewGuid().ToString("N"); string dir = Dir(id); Directory.CreateDirectory(dir);
            CreateSigningIdentity(dir, id);
            var info = new CampaignInfo { Id = id, Name = name, Version = 0, ParentHash = new string('0', 64), SaveHash = Hash(new byte[0]), CreatedUtc = DateTime.UtcNow.ToString("O"), Committer = "CREATED" };
            Sign(info, dir); WriteVersion(dir, info, null); SetActive(dir, 0); return info;
        }

        public List<CampaignInfo> List()
        {
            var result = new List<CampaignInfo>();
            if (!Directory.Exists(_campaignRoot)) return result;
            foreach (string dir in Directory.GetDirectories(_campaignRoot))
            {
                try { CampaignInfo item = Load(Path.GetFileName(dir)); if (item != null) result.Add(item); } catch { }
            }
            return result.OrderByDescending(x => x.CreatedUtc).ToList();
        }

        public CampaignInfo Load(string id)
        {
            string dir = Dir(id); EnsureModernIdentity(dir, id); int version = ReadActive(dir); CampaignInfo info = ReadManifest(ManifestPath(dir, version));
            Verify(info, ReadPublicKey(dir), SaveBytes(dir, version)); return info;
        }

        public List<CampaignInfo> History(string id)
        {
            string dir = Dir(id); string publicKey = ReadPublicKey(dir); var list = new List<CampaignInfo>();
            foreach (string path in Directory.GetFiles(dir, "v*.manifest").OrderBy(x => x))
            {
                CampaignInfo info = ReadManifest(path); Verify(info, publicKey, SaveBytes(dir, info.Version)); list.Add(info);
            }
            return list;
        }

        public CampaignInfo Commit(string id, string memoryCard, string committer)
        {
            if (!File.Exists(memoryCard)) throw new FileNotFoundException("Campaign memory card is missing.", memoryCard);
            string dir = Dir(id); CampaignInfo previous = Load(id); byte[] save = File.ReadAllBytes(memoryCard);
            if (Hash(save) == previous.SaveHash) return previous;
            if (!File.Exists(Path.Combine(dir, "campaign.private.dpapi"))) throw new CryptographicException("This synchronized campaign copy is verified but read-only. Host from the computer that owns its protected signing authority.");
            var next = new CampaignInfo { Id = previous.Id, Name = previous.Name, Version = previous.Version + 1, ParentHash = ChainHash(previous), SaveHash = Hash(save), CreatedUtc = DateTime.UtcNow.ToString("O"), Committer = committer };
            Sign(next, dir); WriteVersion(dir, next, save); SetActive(dir, next.Version); return next;
        }

        public CampaignInfo Recover(string id, int version)
        {
            string dir = Dir(id); CampaignInfo source = ReadManifest(ManifestPath(dir, version)); byte[] save = SaveBytes(dir, version);
            Verify(source, ReadPublicKey(dir), save);
            string temp = Path.Combine(dir, "recovery.tmp.ps2"); File.WriteAllBytes(temp, save);
            try { return Commit(id, temp, "RECOVERY FROM v" + version); } finally { try { File.Delete(temp); } catch { } }
        }

        public void RestoreToMemoryCard(string id, string destination)
        {
            CampaignInfo info = Load(id); if (info.Version == 0) return;
            byte[] save = SaveBytes(Dir(id), info.Version); if (Hash(save) != info.SaveHash) throw new CryptographicException("Campaign save hash does not match its signed manifest.");
            Directory.CreateDirectory(Path.GetDirectoryName(destination)); File.WriteAllBytes(destination, save);
        }

        public byte[] ExportPackage(string id)
        {
            string dir = Dir(id); CampaignInfo info = Load(id);
            using (var output = new MemoryStream())
            {
                using (var zip = new ZipArchive(output, ZipArchiveMode.Create, true))
                {
                    Add(zip, "campaign.public.xml", Utf8.GetBytes(ReadPublicKey(dir)));
                    Add(zip, "latest.manifest", Utf8.GetBytes(Serialize(info)));
                    Add(zip, "latest.ps2", SaveBytes(dir, info.Version));
                }
                return output.ToArray();
            }
        }

        public byte[] ExportHostingAuthority(string id)
        {
            string dir = Dir(id); CampaignInfo info = Load(id);
            string privatePath = Path.Combine(dir, "campaign.private.dpapi");
            if (!File.Exists(privatePath)) throw new UnauthorizedAccessException("Only a current campaign host can transfer hosting authority.");
            byte[] entropy = Utf8.GetBytes("GTB-CAMPAIGN-AUTHORITY-V2\n" + info.Id.ToLowerInvariant());
            byte[] privateXml = ProtectedData.Unprotect(File.ReadAllBytes(privatePath), entropy, DataProtectionScope.CurrentUser);
            try
            {
                using (var output = new MemoryStream())
                using (var writer = new BinaryWriter(output, Utf8, true))
                {
                    writer.Write(Utf8.GetBytes("GTB-AUTHORITY-V1"));
                    writer.Write(info.Id.ToLowerInvariant());
                    writer.Write(privateXml.Length); writer.Write(privateXml); writer.Flush();
                    return output.ToArray();
                }
            }
            finally { Array.Clear(privateXml, 0, privateXml.Length); }
        }

        public void ImportHostingAuthority(byte[] package)
        {
            if (package == null || package.Length < 64 || package.Length > 32 * 1024) throw new InvalidDataException("Campaign hosting authority package is invalid.");
            byte[] privateXml = null;
            try
            {
                string id;
                using (var input = new MemoryStream(package, false))
                using (var reader = new BinaryReader(input, Utf8, true))
                {
                    byte[] marker = reader.ReadBytes(16);
                    if (!marker.SequenceEqual(Utf8.GetBytes("GTB-AUTHORITY-V1"))) throw new InvalidDataException("Campaign hosting authority marker is invalid.");
                    id = reader.ReadString();
                    if (!Regex.IsMatch(id ?? "", "^[a-f0-9]{32}$")) throw new InvalidDataException("Campaign hosting authority identity is invalid.");
                    int length = reader.ReadInt32(); if (length < 512 || length > 24 * 1024) throw new InvalidDataException("Campaign hosting authority length is invalid.");
                    privateXml = reader.ReadBytes(length); if (privateXml.Length != length || input.Position != input.Length) throw new InvalidDataException("Campaign hosting authority data is incomplete.");
                }
                string dir = Dir(id), expectedPublic = ReadPublicKey(dir), actualPublic;
                using (var rsa = new RSACryptoServiceProvider())
                {
                    rsa.PersistKeyInCsp = false; rsa.FromXmlString(Utf8.GetString(privateXml)); if (rsa.KeySize < 3072) throw new CryptographicException("Campaign hosting authority key is too small.");
                    actualPublic = rsa.ToXmlString(false);
                }
                if (!FixedText(expectedPublic, actualPublic)) throw new CryptographicException("Campaign hosting authority does not match the signed campaign identity.");
                byte[] entropy = Utf8.GetBytes("GTB-CAMPAIGN-AUTHORITY-V2\n" + id);
                byte[] protectedKey = ProtectedData.Protect(privateXml, entropy, DataProtectionScope.CurrentUser);
                try { AtomicWriteBytes(Path.Combine(dir, "campaign.private.dpapi"), protectedKey); }
                finally { Array.Clear(protectedKey, 0, protectedKey.Length); }
            }
            finally { if (privateXml != null) Array.Clear(privateXml, 0, privateXml.Length); }
        }

        public CampaignInfo ImportPackage(byte[] package)
        {
            byte[] save; string publicKey, manifestText;
            using (var input = new MemoryStream(package))
            using (var zip = new ZipArchive(input, ZipArchiveMode.Read))
            {
                if (zip.Entries.Count != 3 || zip.Entries.GroupBy(e => e.FullName, StringComparer.Ordinal).Any(g => g.Count() != 1)) throw new InvalidDataException("Campaign package contains unexpected or duplicate entries.");
                publicKey = Utf8.GetString(ReadEntry(zip, "campaign.public.xml", 16 * 1024)); save = ReadEntry(zip, "latest.ps2", 10 * 1024 * 1024);
                manifestText = Utf8.GetString(ReadEntry(zip, "latest.manifest", 64 * 1024));
            }
            ValidatePublicKey(publicKey);
            CampaignInfo incoming = Parse(manifestText); Verify(incoming, publicKey, save);
            string dir = Dir(incoming.Id); Directory.CreateDirectory(dir); string keyPath = Path.Combine(dir, "campaign.public.xml");
            if (File.Exists(keyPath) && !FixedText(File.ReadAllText(keyPath, Utf8), publicKey)) throw new CryptographicException("Campaign identity conflict: signing identities differ.");
            CampaignInfo local = null; try { local = Load(incoming.Id); } catch (FileNotFoundException) { } catch (DirectoryNotFoundException) { }
            if (local != null)
            {
                if (incoming.Version < local.Version) throw new CryptographicException("Older campaign rollback rejected.");
                if (incoming.Version == local.Version)
                {
                    if (ChainHash(incoming) != ChainHash(local)) throw new CryptographicException("Conflicting campaign copy rejected.");
                    return local;
                }
                if (incoming.Version != local.Version + 1) throw new CryptographicException("Campaign version gap rejected; synchronize each signed version in order.");
                if (incoming.ParentHash != ChainHash(local)) throw new CryptographicException("Divergent campaign history rejected.");
            }
            AtomicWriteText(keyPath, publicKey); WriteVersion(dir, incoming, save.Length == 0 ? null : save); SetActive(dir, incoming.Version); return incoming;
        }

        private string Dir(string id)
        {
            if (string.IsNullOrWhiteSpace(id) || !Regex.IsMatch(id, "^[a-fA-F0-9]{32}$")) throw new InvalidDataException("Campaign identifier is invalid.");
            return Path.Combine(_campaignRoot, id.ToLowerInvariant());
        }
        private static string ManifestPath(string dir, int version) { return Path.Combine(dir, "v" + version.ToString("D8") + ".manifest"); }
        private static string SavePath(string dir, int version) { return Path.Combine(dir, "v" + version.ToString("D8") + ".ps2"); }
        private static byte[] SaveBytes(string dir, int version) { string path = SavePath(dir, version); return File.Exists(path) ? File.ReadAllBytes(path) : new byte[0]; }
        private static void WriteVersion(string dir, CampaignInfo info, byte[] save) { AtomicWriteText(ManifestPath(dir, info.Version), Serialize(info)); if (save != null) AtomicWriteBytes(SavePath(dir, info.Version), save); }
        private static void SetActive(string dir, int version) { AtomicWriteText(Path.Combine(dir, "active.txt"), version.ToString()); }
        private static int ReadActive(string dir) { int v; if (!int.TryParse(File.ReadAllText(Path.Combine(dir, "active.txt")).Trim(), out v) || v < 0) throw new InvalidDataException("Campaign active version is invalid."); return v; }
        private static void CreateSigningIdentity(string dir, string id)
        {
            using (var rsa = new RSACryptoServiceProvider(3072))
            {
                rsa.PersistKeyInCsp = false;
                string publicXml = rsa.ToXmlString(false);
                byte[] privateXml = Utf8.GetBytes(rsa.ToXmlString(true));
                byte[] entropy = Utf8.GetBytes("GTB-CAMPAIGN-AUTHORITY-V2\n" + id.ToLowerInvariant());
                byte[] protectedKey = ProtectedData.Protect(privateXml, entropy, DataProtectionScope.CurrentUser);
                try
                {
                    AtomicWriteText(Path.Combine(dir, "campaign.public.xml"), publicXml);
                    AtomicWriteBytes(Path.Combine(dir, "campaign.private.dpapi"), protectedKey);
                }
                finally
                {
                    Array.Clear(privateXml, 0, privateXml.Length); Array.Clear(protectedKey, 0, protectedKey.Length);
                }
            }
        }
        private static void EnsureModernIdentity(string dir, string id)
        {
            if (File.Exists(Path.Combine(dir, "campaign.public.xml"))) return;
            string legacyPath = Path.Combine(dir, "campaign.key");
            if (!File.Exists(legacyPath)) throw new FileNotFoundException("Campaign signing identity is missing.");
            byte[] legacy = File.ReadAllBytes(legacyPath);
            if (legacy.Length != 32) throw new CryptographicException("Legacy campaign signing key is invalid.");
            var manifests = new List<CampaignInfo>();
            foreach (string path in Directory.GetFiles(dir, "v*.manifest").OrderBy(x => x))
            {
                CampaignInfo info = ReadManifest(path); byte[] save = SaveBytes(dir, info.Version);
                if (!FixedText(Hash(save), info.SaveHash)) throw new CryptographicException("Legacy campaign save is corrupt.");
                string expected; using (var h = new HMACSHA256(legacy)) expected = Hex(h.ComputeHash(Utf8.GetBytes(Canonical(info))));
                if (!FixedText(expected, info.Signature)) throw new CryptographicException("Legacy campaign signature is invalid.");
                manifests.Add(info);
            }
            CreateSigningIdentity(dir, id);
            foreach (CampaignInfo info in manifests) { Sign(info, dir); AtomicWriteText(ManifestPath(dir, info.Version), Serialize(info)); }
            string disabled = Path.Combine(dir, "campaign.key.legacy-disabled");
            if (!File.Exists(disabled)) File.Move(legacyPath, disabled); else File.Delete(legacyPath);
            Array.Clear(legacy, 0, legacy.Length);
        }
        private static string ReadPublicKey(string dir)
        {
            string path = Path.Combine(dir, "campaign.public.xml");
            if (!File.Exists(path)) throw new FileNotFoundException("Campaign public signing identity is missing.", path);
            string value = File.ReadAllText(path, Utf8); ValidatePublicKey(value); return value;
        }
        private static void ValidatePublicKey(string publicKey)
        {
            if (string.IsNullOrWhiteSpace(publicKey) || publicKey.Length > 16 * 1024 || publicKey.Contains("<D>") || publicKey.Contains("<P>")) throw new CryptographicException("Campaign public signing identity is invalid.");
            using (var rsa = new RSACryptoServiceProvider()) { rsa.PersistKeyInCsp = false; rsa.FromXmlString(publicKey); if (rsa.KeySize < 3072) throw new CryptographicException("Campaign signing key is too small."); }
        }
        private static void Sign(CampaignInfo info, string dir)
        {
            string privatePath = Path.Combine(dir, "campaign.private.dpapi");
            byte[] entropy = Utf8.GetBytes("GTB-CAMPAIGN-AUTHORITY-V2\n" + info.Id.ToLowerInvariant());
            byte[] privateXml = ProtectedData.Unprotect(File.ReadAllBytes(privatePath), entropy, DataProtectionScope.CurrentUser);
            try
            {
                using (var rsa = new RSACryptoServiceProvider())
                {
                    rsa.PersistKeyInCsp = false; rsa.FromXmlString(Utf8.GetString(privateXml));
                    info.Signature = Convert.ToBase64String(rsa.SignData(Utf8.GetBytes(Canonical(info)), CryptoConfig.MapNameToOID("SHA256")));
                }
            }
            finally { Array.Clear(privateXml, 0, privateXml.Length); }
        }
        private static void Verify(CampaignInfo info, string publicKey, byte[] save)
        {
            ValidateManifest(info);
            if (!FixedText(Hash(save), info.SaveHash)) throw new CryptographicException("Campaign save data is corrupt.");
            byte[] signature;
            try { signature = Convert.FromBase64String(info.Signature); } catch { throw new CryptographicException("Campaign signature encoding is invalid."); }
            using (var rsa = new RSACryptoServiceProvider())
            {
                rsa.PersistKeyInCsp = false; rsa.FromXmlString(publicKey);
                if (!rsa.VerifyData(Utf8.GetBytes(Canonical(info)), CryptoConfig.MapNameToOID("SHA256"), signature)) throw new CryptographicException("Campaign signature is invalid or the manifest was changed.");
            }
        }
        private static void ValidateManifest(CampaignInfo info)
        {
            if (info == null || !Regex.IsMatch(info.Id ?? "", "^[a-fA-F0-9]{32}$") || info.Version < 0 || info.Version > 99999999) throw new InvalidDataException("Campaign identity or version is invalid.");
            if ((info.Name ?? "").Length > 120 || (info.Committer ?? "").Length > 120) throw new InvalidDataException("Campaign text field is too long.");
            if (!Regex.IsMatch(info.ParentHash ?? "", "^[a-f0-9]{64}$") || !Regex.IsMatch(info.SaveHash ?? "", "^[a-f0-9]{64}$")) throw new InvalidDataException("Campaign hash field is invalid.");
            DateTime timestamp; if (!DateTime.TryParse(info.CreatedUtc, null, System.Globalization.DateTimeStyles.RoundtripKind, out timestamp)) throw new InvalidDataException("Campaign timestamp is invalid.");
            if (string.IsNullOrWhiteSpace(info.Signature) || info.Signature.Length > 2048) throw new InvalidDataException("Campaign signature field is invalid.");
        }
        private static string Canonical(CampaignInfo x) { return x.Id + "\n" + B64(x.Name) + "\n" + x.Version + "\n" + x.ParentHash + "\n" + x.SaveHash + "\n" + x.CreatedUtc + "\n" + B64(x.Committer); }
        private static string Serialize(CampaignInfo x) { return Canonical(x) + "\n" + x.Signature + "\n"; }
        private static CampaignInfo Parse(string value)
        {
            if (value == null || value.Length > 64 * 1024) throw new InvalidDataException("Campaign manifest is too large.");
            string[] p = value.Replace("\r", "").Split('\n'); if (p.Length != 9 || p[8].Length != 0) throw new InvalidDataException("Campaign manifest is incomplete or has trailing data."); int v; if (!int.TryParse(p[2], out v)) throw new InvalidDataException("Campaign version is invalid.");
            CampaignInfo info = new CampaignInfo { Id = p[0], Name = FromB64(p[1]), Version = v, ParentHash = p[3], SaveHash = p[4], CreatedUtc = p[5], Committer = FromB64(p[6]), Signature = p[7] }; ValidateManifest(info); return info;
        }
        private static CampaignInfo ReadManifest(string path) { return Parse(File.ReadAllText(path, Utf8)); }
        private static string ChainHash(CampaignInfo info) { return Hash(Utf8.GetBytes(Serialize(info))); }
        private static string Hash(byte[] data) { using (var sha = SHA256.Create()) return Hex(sha.ComputeHash(data)); }
        private static string Hex(byte[] data) { return BitConverter.ToString(data).Replace("-", "").ToLowerInvariant(); }
        private static bool FixedText(string a, string b) { if (a == null || b == null || a.Length != b.Length) return false; byte[] aa = Utf8.GetBytes(a), bb = Utf8.GetBytes(b); return SessionCrypto.FixedEqualsPublic(aa, bb); }
        private static string B64(string s) { return Convert.ToBase64String(Utf8.GetBytes(s ?? "")); }
        private static string FromB64(string s) { return Utf8.GetString(Convert.FromBase64String(s)); }
        private static void Add(ZipArchive zip, string name, byte[] data) { var e = zip.CreateEntry(name, CompressionLevel.Fastest); using (Stream s = e.Open()) s.Write(data, 0, data.Length); }
        private static byte[] ReadEntry(ZipArchive zip, string name, int limit)
        {
            ZipArchiveEntry e = zip.GetEntry(name); if (e == null || e.Length < 0 || e.Length > limit) throw new InvalidDataException("Campaign package entry is missing or too large: " + name);
            using (Stream s = e.Open()) using (var m = new MemoryStream())
            {
                byte[] buffer = new byte[32768]; int read, total = 0;
                while ((read = s.Read(buffer, 0, buffer.Length)) > 0) { total += read; if (total > limit) throw new InvalidDataException("Campaign package expands beyond its allowed size: " + name); m.Write(buffer, 0, read); }
                return m.ToArray();
            }
        }
        private static void AtomicWriteText(string path, string value) { AtomicWriteBytes(path, Utf8.GetBytes(value)); }
        private static void AtomicWriteBytes(string path, byte[] value)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path)); string temp = path + ".new-" + Guid.NewGuid().ToString("N");
            try
            {
                using (var output = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None)) { output.Write(value, 0, value.Length); output.Flush(true); }
                if (File.Exists(path)) File.Replace(temp, path, null, true); else File.Move(temp, path);
            }
            finally { try { if (File.Exists(temp)) File.Delete(temp); } catch { } }
        }
    }

    internal sealed class SharedCampaignForm : Form
    {
        private readonly SharedCampaignStore _store; private readonly ListBox _list = new ListBox(); private readonly List<CampaignInfo> _items = new List<CampaignInfo>();
        public CampaignInfo SelectedCampaign { get; private set; }
        public SharedCampaignForm(SharedCampaignStore store)
        {
            _store = store; Text = "Gran Turismo Bulgaria — Co-op Campaign"; ClientSize = new Size(700, 430); StartPosition = FormStartPosition.CenterParent; FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false; MinimizeBox = false; BackColor = Color.FromArgb(10, 15, 20); ForeColor = Color.White;
            Label title = LauncherForm.NewPublicLabel(21, FontStyle.Bold, Color.White); title.Text = "CO-OP CAMPAIGN"; title.Location = new Point(28, 22); title.AutoSize = true; Controls.Add(title);
            Label copy = LauncherForm.NewPublicLabel(10, FontStyle.Regular, Color.FromArgb(185, 198, 208)); copy.Text = "Signed, versioned saves. The session host commits results; verified friends may host the latest copy later."; copy.Location = new Point(30, 64); copy.Size = new Size(640, 42); Controls.Add(copy);
            _list.Location = new Point(30, 112); _list.Size = new Size(640, 210); _list.BackColor = Color.FromArgb(25, 34, 42); _list.ForeColor = Color.White; _list.Font = new Font("Segoe UI", 11F); Controls.Add(_list);
            Button create = Button("NEW CAMPAIGN", Color.FromArgb(0, 121, 76), 155); create.Location = new Point(30, 342); create.Click += delegate { CreateCampaign(); }; Controls.Add(create);
            Button history = Button("HISTORY / RECOVER", Color.FromArgb(48, 58, 67), 175); history.Location = new Point(195, 342); history.Click += delegate { Recover(); }; Controls.Add(history);
            Button load = Button("LOAD CAMPAIGN", Color.FromArgb(190, 19, 38), 155); load.Location = new Point(515, 342); load.Click += delegate { Choose(); }; Controls.Add(load);
            _list.DoubleClick += delegate { Choose(); }; RefreshList();
        }
        private void RefreshList() { _items.Clear(); _items.AddRange(_store.List()); _list.Items.Clear(); foreach (CampaignInfo x in _items) _list.Items.Add(x.Name + "    v" + x.Version + "    " + x.CreatedUtc); if (_list.Items.Count > 0) _list.SelectedIndex = 0; }
        private void CreateCampaign() { using (var prompt = new CampaignNameForm()) if (prompt.ShowDialog(this) == DialogResult.OK) { SelectedCampaign = _store.Create(prompt.CampaignName); DialogResult = DialogResult.OK; Close(); } }
        private void Choose() { if (_list.SelectedIndex < 0) return; SelectedCampaign = _items[_list.SelectedIndex]; DialogResult = DialogResult.OK; Close(); }
        private void Recover()
        {
            if (_list.SelectedIndex < 0) return; CampaignInfo selected = _items[_list.SelectedIndex]; List<CampaignInfo> history = _store.History(selected.Id);
            using (var picker = new Form { Text = "Campaign history", ClientSize = new Size(540, 350), StartPosition = FormStartPosition.CenterParent, BackColor = Color.FromArgb(10, 15, 20), ForeColor = Color.White })
            {
                var versions = new ListBox { Location = new Point(20, 20), Size = new Size(500, 250), BackColor = Color.FromArgb(25, 34, 42), ForeColor = Color.White, Font = new Font("Segoe UI", 10F) };
                foreach (CampaignInfo x in history) versions.Items.Add("v" + x.Version + "  " + x.CreatedUtc + "  " + x.Committer); picker.Controls.Add(versions); if (versions.Items.Count > 0) versions.SelectedIndex = versions.Items.Count - 1;
                Button recover = Button("RECOVER AS NEW VERSION", Color.FromArgb(190, 19, 38), 220); recover.Location = new Point(300, 290); recover.Click += delegate { if (versions.SelectedIndex >= 0) { SelectedCampaign = _store.Recover(selected.Id, history[versions.SelectedIndex].Version); picker.DialogResult = DialogResult.OK; picker.Close(); } }; picker.Controls.Add(recover);
                if (picker.ShowDialog(this) == DialogResult.OK) { DialogResult = DialogResult.OK; Close(); }
            }
        }
        private static Button Button(string text, Color color, int width) { var b = new Button { Text = text, Size = new Size(width, 42), FlatStyle = FlatStyle.Flat, BackColor = color, ForeColor = Color.White }; b.FlatAppearance.BorderSize = 0; return b; }
    }

    internal sealed class CampaignNameForm : Form
    {
        private readonly TextBox _name = new TextBox(); public string CampaignName { get { return _name.Text.Trim(); } }
        public CampaignNameForm()
        {
            Text = "New Co-op Campaign"; ClientSize = new Size(470, 160); StartPosition = FormStartPosition.CenterParent; BackColor = Color.FromArgb(10, 15, 20); ForeColor = Color.White;
            var label = LauncherForm.NewPublicLabel(11, FontStyle.Bold, Color.White); label.Text = "CAMPAIGN NAME"; label.Location = new Point(24, 22); label.AutoSize = true; Controls.Add(label);
            _name.Location = new Point(25, 56); _name.Size = new Size(420, 28); _name.Text = "Bulgaria Co-op"; Controls.Add(_name);
            var ok = new Button { Text = "CREATE", DialogResult = DialogResult.OK, Location = new Point(320, 105), Size = new Size(125, 35), BackColor = Color.FromArgb(190, 19, 38), ForeColor = Color.White, FlatStyle = FlatStyle.Flat }; ok.FlatAppearance.BorderSize = 0; Controls.Add(ok); AcceptButton = ok;
        }
    }

    internal static class SharedCampaignSelfTest
    {
        public static int Run(string root)
        {
            // Keep the test name deliberately short for the legacy MAX_PATH boundary.
            string testRoot = Path.Combine(root, "ct"); var lines = new List<string> { "Gran Turismo Bulgaria campaign self-test " + DateTime.Now.ToString("O") }; bool ok = true;
            try
            {
                if (Directory.Exists(testRoot)) Directory.Delete(testRoot, true);
                var a = new SharedCampaignStore(testRoot); CampaignInfo created = a.Create("Test Campaign"); lines.Add((created.Version == 0 ? "PASS " : "FAIL ") + "new campaign version zero"); ok &= created.Version == 0;
                string card = Path.Combine(testRoot, "card.ps2"); byte[] sample = new byte[8 * 1024 * 1024]; new Random(12345).NextBytes(sample); File.WriteAllBytes(card, sample);
                CampaignInfo one = a.Commit(created.Id, card, "HOST"); lines.Add((one.Version == 1 ? "PASS " : "FAIL ") + "host-authoritative commit v1"); ok &= one.Version == 1;
                byte[] package = a.ExportPackage(created.Id); string peerRoot = Path.Combine(testRoot, "peer"); var b = new SharedCampaignStore(peerRoot); CampaignInfo copy = b.ImportPackage(package); lines.Add((copy.Version == 1 ? "PASS " : "FAIL ") + "secure participant import"); ok &= copy.Version == 1;
                string changedCard = Path.Combine(peerRoot, "changed.ps2"); byte[] changed = (byte[])sample.Clone(); changed[0] ^= 0x3c; File.WriteAllBytes(changedCard, changed);
                bool participantBlocked = false; try { b.Commit(copy.Id, changedCard, "PARTICIPANT"); } catch (UnauthorizedAccessException) { participantBlocked = true; } catch (CryptographicException) { participantBlocked = true; } catch (InvalidOperationException) { participantBlocked = true; }
                lines.Add((participantBlocked ? "PASS " : "FAIL ") + "participant cannot forge host campaign commit"); ok &= participantBlocked;
                byte[] authority = a.ExportHostingAuthority(created.Id); b.ImportHostingAuthority(authority); Array.Clear(authority, 0, authority.Length); CampaignInfo delegated = b.Commit(copy.Id, changedCard, "SYNCHRONIZED HOST"); bool canHost = delegated.Version == 2;
                lines.Add((canHost ? "PASS " : "FAIL ") + "authenticated authority transfer permits later hosting"); ok &= canHost;
                string restored = Path.Combine(peerRoot, "restored.ps2"); b.RestoreToMemoryCard(copy.Id, restored); bool same = File.ReadAllBytes(restored).SequenceEqual(changed); lines.Add((same ? "PASS " : "FAIL ") + "memory card hash and restore"); ok &= same;
                byte[] tampered = (byte[])package.Clone(); tampered[tampered.Length / 2] ^= 0x55; bool rejected = false; try { b.ImportPackage(tampered); } catch { rejected = true; } lines.Add((rejected ? "PASS " : "FAIL ") + "tampered package rejected"); ok &= rejected;
                CampaignInfo recovered = a.Recover(created.Id, 0); bool recovery = recovered.Version == 2; lines.Add((recovery ? "PASS " : "FAIL ") + "history recovery creates forward-only version"); ok &= recovery;
            }
            catch (Exception ex) { ok = false; lines.Add("FAIL " + ex); }
            finally { try { if (Directory.Exists(testRoot)) Directory.Delete(testRoot, true); } catch { } }
            lines.Add(ok ? "RESULT PASS" : "RESULT FAIL"); string logs = Path.Combine(root, "logs"); Directory.CreateDirectory(logs); File.WriteAllLines(Path.Combine(logs, "campaign-self-test.txt"), lines.ToArray(), Utf8NoBom()); return ok ? 0 : 1;
        }
        private static Encoding Utf8NoBom() { return new UTF8Encoding(false); }
    }

    internal sealed class PrivateSessionForm : Form
    {
        private readonly string _root;
        private readonly TextBox _invite = new TextBox();
        private readonly Label _status = LauncherForm.NewPublicLabel(10, FontStyle.Regular, Color.FromArgb(205, 215, 223));
        private readonly Button _use;
        private readonly ComboBox _hostMethod = new ComboBox();
        private readonly ComboBox _engine = new ComboBox();
        private readonly TextBox _publicAddress = new TextBox();
        private readonly NumericUpDown _manualPort = new NumericUpDown();
        private readonly Label _addressLabel = LauncherForm.NewPublicLabel(8, FontStyle.Bold, Color.FromArgb(218, 71, 84));
        private readonly Label _portLabel = LauncherForm.NewPublicLabel(8, FontStyle.Bold, Color.FromArgb(218, 71, 84));
        private readonly System.Windows.Forms.Timer _timer = new System.Windows.Forms.Timer();
        private readonly SessionEntryMode _entryMode;
        private ConnectionProfile _profile;
        public PrivateSessionService ActiveSession { get; private set; }
        public OnlineEngineMode SelectedMode { get; private set; }
        public ConnectionTransport SelectedTransport { get; private set; }
        private string ModeName { get { return "ONLINE BETA — PRIVATE GT4 SERVER"; } }

        public PrivateSessionForm(string root, ConnectionTransport transport, ConnectionProfile profile, SessionEntryMode entryMode = SessionEntryMode.Manage)
        {
            _root = root;
            _entryMode = entryMode;
            SelectedTransport = transport;
            _profile = profile ?? NetworkAdapterProbe.Detect(transport);
            Text = "Gran Turismo Bulgaria — Private Race"; ClientSize = new Size(620, 492); FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false; StartPosition = FormStartPosition.CenterParent; BackColor = Color.FromArgb(11, 16, 21); ForeColor = Color.White;
            var title = LauncherForm.NewPublicLabel(20, FontStyle.Bold, Color.White); title.Text = "PRIVATE RACE — UP TO 4 COMPUTERS"; title.AutoSize = true; title.Location = new Point(28, 24); Controls.Add(title);
            var copy = LauncherForm.NewPublicLabel(10, FontStyle.Regular, Color.FromArgb(180, 192, 202)); copy.Text = "Host creates one private invitation. Up to three joining computers use it."; copy.AutoSize = true; copy.Location = new Point(30, 66); Controls.Add(copy);
            _engine.DropDownStyle = ComboBoxStyle.DropDownList; _engine.FlatStyle = FlatStyle.Flat; _engine.BackColor = Color.FromArgb(29, 37, 44); _engine.ForeColor = Color.White;
            _engine.Items.Add("ONLINE BETA — PRIVATE GT4 SERVER"); _engine.SelectedIndex = 0; _engine.Enabled = false; _engine.Location = new Point(30, 96); _engine.Size = new Size(557, 29); Controls.Add(_engine);
            _hostMethod.DropDownStyle = ComboBoxStyle.DropDownList; _hostMethod.FlatStyle = FlatStyle.Flat; _hostMethod.BackColor = Color.FromArgb(29, 37, 44); _hostMethod.ForeColor = Color.White;
            _hostMethod.Items.Add(NetworkAdapterProbe.DisplayName(_profile.Resolved)); _hostMethod.SelectedIndex = 0; _hostMethod.Enabled = false; _hostMethod.Location = new Point(30, 153); _hostMethod.Size = new Size(250, 29); Controls.Add(_hostMethod);
            _addressLabel.Text = "PUBLIC IPv4 OR HOSTNAME"; _addressLabel.Location = new Point(290, 136); _addressLabel.AutoSize = true; Controls.Add(_addressLabel);
            _publicAddress.Location = new Point(290, 153); _publicAddress.Size = new Size(180, 29); _publicAddress.Font = new Font("Consolas", 9F); _publicAddress.BackColor = Color.FromArgb(29, 37, 44); _publicAddress.ForeColor = Color.White; Controls.Add(_publicAddress);
            _portLabel.Text = "PORT"; _portLabel.Location = new Point(482, 136); _portLabel.AutoSize = true; Controls.Add(_portLabel);
            _manualPort.Location = new Point(482, 153); _manualPort.Size = new Size(105, 29); _manualPort.Minimum = 1; _manualPort.Maximum = 65535; _manualPort.Value = 36580; _manualPort.BackColor = Color.FromArgb(29, 37, 44); _manualPort.ForeColor = Color.White; Controls.Add(_manualPort);
            SelectedMode = OnlineEngineMode.OnlineBetaMedius;
            UpdateHostMethod();
            var host = NewButton(entryMode == SessionEntryMode.Host ? "CREATE HOST INVITE" : "HOST RACE", Color.FromArgb(190, 19, 38), entryMode == SessionEntryMode.Host ? 250 : 165); host.Location = new Point(30, 203); host.Click += delegate { if (Host() && _entryMode == SessionEntryMode.Host) { CopyInviteSafely(); host.Enabled = false; _use.Enabled = true; _status.Text = "HOSTING: " + ModeName + "\nHost ready. Send the displayed invitation, then choose LAUNCH HOST GAME."; } }; Controls.Add(host);
            var join = NewButton(entryMode == SessionEntryMode.Join ? "JOIN & LAUNCH" : "JOIN RACE", Color.FromArgb(0, 121, 76), entryMode == SessionEntryMode.Join ? 250 : 165); join.Location = new Point(entryMode == SessionEntryMode.Join ? 30 : 207, 203); join.Click += delegate { if (Join() && _entryMode == SessionEntryMode.Join) CompleteAndLaunch(); }; Controls.Add(join);
            var copyInvite = NewButton("COPY INVITE", Color.FromArgb(45, 55, 64), 165); copyInvite.Location = new Point(384, 203); copyInvite.Click += delegate { CopyInviteSafely(); }; Controls.Add(copyInvite);
            var pasteInvite = NewButton("PASTE INVITE", Color.FromArgb(45, 55, 64), 165); pasteInvite.Location = new Point(294, 203); pasteInvite.Click += delegate { PasteInviteFromClipboard(); }; Controls.Add(pasteInvite);
            _invite.Location = new Point(30, 257); _invite.Size = new Size(519, 29); _invite.Font = new Font("Consolas", 10F); _invite.BackColor = Color.FromArgb(29, 37, 44); _invite.ForeColor = Color.White; Controls.Add(_invite);
            _status.Text = "Choose how the single complete game connects. Joiners only paste the invitation."; _status.AutoSize = false; _status.Location = new Point(30, 304); _status.Size = new Size(555, 82); Controls.Add(_status);
            _use = NewButton("USE THIS SESSION", Color.FromArgb(190, 19, 38), 200); _use.Location = new Point(350, 424); _use.Enabled = false; _use.Click += delegate { DialogResult = DialogResult.OK; Close(); }; Controls.Add(_use);
            var cancel = NewButton("CANCEL", Color.FromArgb(45, 55, 64), 130); cancel.Location = new Point(208, 424); cancel.Click += delegate { if (ActiveSession != null) ActiveSession.Dispose(); ActiveSession = null; DialogResult = DialogResult.Cancel; Close(); }; Controls.Add(cancel);
            if (entryMode == SessionEntryMode.Host)
            {
                join.Visible = false; pasteInvite.Visible = false; copyInvite.Visible = true; copyInvite.Location = new Point(294, 203);
                _use.Visible = true; _use.Text = "LAUNCH HOST GAME"; _use.Enabled = false;
                title.Text = "HOST PRIVATE MATCH"; copy.Text = "Create a secure invitation, copy or select it manually, then launch the host game.";
            }
            else if (entryMode == SessionEntryMode.Join)
            {
                host.Visible = false; copyInvite.Visible = false; pasteInvite.Visible = true; _use.Visible = false; title.Text = "JOIN PRIVATE MATCH";
                copy.Text = "Paste the host's private invitation, connect securely, and launch directly.";
                _engine.Visible = false; _hostMethod.Visible = false; _publicAddress.Visible = false; _manualPort.Visible = false; _addressLabel.Visible = false; _portLabel.Visible = false;
                _invite.Location = new Point(30, 153); _invite.Size = new Size(557, 29);
                _status.Location = new Point(30, 257); _status.Text = "Paste the GTB2 invitation above, then choose JOIN & LAUNCH.";
            }
            _timer.Interval = 300; _timer.Tick += delegate { if (ActiveSession != null) { _status.Text = (ActiveSession.Role == "HOST" ? "HOSTING: " : "JOINING: ") + ModeName + "\n" + ActiveSession.Status; _use.Enabled = ActiveSession.Connected || ActiveSession.Role == "HOST"; } }; _timer.Start();
            Shown += delegate
            {
                if (_entryMode == SessionEntryMode.Join)
                {
                    try
                    {
                        if (Clipboard.ContainsText())
                        {
                            string clipboardInvite = Clipboard.GetText().Trim();
                            if (clipboardInvite.StartsWith("GTB2|", StringComparison.OrdinalIgnoreCase) || clipboardInvite.StartsWith("GTB3|", StringComparison.OrdinalIgnoreCase)) _invite.Text = clipboardInvite;
                        }
                    }
                    catch { }
                    _invite.Focus(); _invite.SelectAll();
                }
                else if (_entryMode == SessionEntryMode.Host) host.Focus();
            };
            FormClosed += delegate
            {
                _timer.Stop();
                if (DialogResult != DialogResult.OK && ActiveSession != null) { ActiveSession.Dispose(); ActiveSession = null; }
            };
        }

        private void CompleteAndLaunch()
        {
            if (ActiveSession == null) return;
            DialogResult = DialogResult.OK;
            Close();
        }

        private void PasteInviteFromClipboard()
        {
            try
            {
                if (!Clipboard.ContainsText()) { _status.Text = "The clipboard does not contain an invitation."; return; }
                string value = Clipboard.GetText().Trim();
                if (!value.StartsWith("GTB2|", StringComparison.OrdinalIgnoreCase) && !value.StartsWith("GTB3|", StringComparison.OrdinalIgnoreCase)) { _status.Text = "The clipboard text is not a Gran Turismo Bulgaria invitation."; return; }
                _invite.Text = value;
                _invite.Focus();
                _invite.SelectionStart = _invite.TextLength;
                _status.Text = "Invitation pasted. Choose JOIN & LAUNCH.";
            }
            catch (Exception ex) { _status.Text = "Clipboard paste failed: " + ex.Message + " You can still click the box and press Ctrl+V."; }
        }

        private void CopyInviteSafely()
        {
            string copied = _invite.Text;
            if (string.IsNullOrWhiteSpace(copied)) return;
            Clipboard.SetText(copied);
            _status.Text = "HOSTING: " + ModeName + "\nInvitation copied. Windows clipboard will be cleared after 60 seconds if unchanged.";
            var clear = new System.Windows.Forms.Timer { Interval = 60000 };
            clear.Tick += delegate
            {
                clear.Stop(); clear.Dispose();
                try { if (Clipboard.ContainsText() && string.Equals(Clipboard.GetText(), copied, StringComparison.Ordinal)) Clipboard.Clear(); } catch { }
            };
            clear.Start();
        }

        private void UpdateHostMethod()
        {
            _publicAddress.Enabled = false; _manualPort.Enabled = false; _addressLabel.Enabled = false; _portLabel.Enabled = false;
            _publicAddress.Visible = false; _manualPort.Visible = false; _addressLabel.Visible = false; _portLabel.Visible = false;
            if (_profile.UsesPrivateOverlay)
                _status.Text = "SELECTED: " + ModeName + "\n" + _profile.Diagnostic + " Both computers must be authorized on the same private " + _profile.DisplayName.Split('—')[0].Trim() + " network. No router port forwarding is needed.";
            else if (_profile.Resolved == ConnectionTransport.PhysicalLan)
                _status.Text = _profile.Diagnostic + " Use this only when every computer is on the same trusted router/LAN.";
            if (!_status.Text.StartsWith("SELECTED:", StringComparison.Ordinal))
                _status.Text = "SELECTED: " + ModeName + "\n" + _status.Text;
        }

        private bool Host()
        {
            try
            {
                SelectedMode = OnlineEngineMode.OnlineBetaMedius;
                if (!File.Exists(Path.Combine(_root, "game", UnifiedDisc.FileName)))
                    throw new FileNotFoundException("The verified GT4 Online Beta disc has not been imported. Run the public installer again and select your own dumped image.");
                _profile = NetworkAdapterProbe.Detect(SelectedTransport);
                string address; int port;
                IPAddress localAddress;
                bool usable = IPAddress.TryParse(_profile.IPv4, out localAddress) && localAddress.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(localAddress);
                if (!_profile.Available || !usable) throw new InvalidOperationException(_profile.Diagnostic);
                if (_profile.Resolved == ConnectionTransport.PhysicalLan && !IsPrivateLanAddress(_profile.IPv4))
                    throw new InvalidOperationException("Local Router LAN requires a private router address. Use ZeroTier when the computers are on different networks.");
                address = _profile.IPv4; port = (int)_manualPort.Value;
                if (ActiveSession != null) ActiveSession.Dispose();
                ActiveSession = PrivateSessionHost.Start(address, port);
                string networkField = _profile.Resolved == ConnectionTransport.ZeroTier ? ZeroTierManager.CurrentNetwork(_root) : "-";
                _invite.Text = "GTB3|" + _profile.Resolved + "|" + networkField + "|BETA|" + ActiveSession.Invitation;
                _status.Text = ActiveSession.Status;
                _use.Enabled = true;
                return true;
            }
            catch (Exception ex) { _status.Text = ex.Message; return false; }
        }

        private static bool IsPublicAddressOrHostname(string value)
        {
            if (string.IsNullOrWhiteSpace(value) || value.IndexOf(':') >= 0 || value.IndexOf('/') >= 0 || value.IndexOf('#') >= 0) return false;
            IPAddress address;
            if (!IPAddress.TryParse(value, out address)) return Uri.CheckHostName(value) == UriHostNameType.Dns;
            if (address.AddressFamily != AddressFamily.InterNetwork || IPAddress.IsLoopback(address)) return false;
            byte[] b = address.GetAddressBytes();
            return b[0] != 0 && b[0] < 224 && b[0] != 10 && !(b[0] == 172 && b[1] >= 16 && b[1] <= 31) && !(b[0] == 192 && b[1] == 168) && !(b[0] == 169 && b[1] == 254) && !(b[0] == 100 && b[1] >= 64 && b[1] <= 127);
        }

        private static bool IsPrivateLanAddress(string value)
        {
            IPAddress address;
            if (!IPAddress.TryParse(value, out address) || address.AddressFamily != AddressFamily.InterNetwork) return false;
            byte[] b = address.GetAddressBytes();
            return b[0] == 10 || (b[0] == 172 && b[1] >= 16 && b[1] <= 31) || (b[0] == 192 && b[1] == 168);
        }

        private bool Join()
        {
            try
            {
                string invitation = _invite.Text.Trim();
                if (invitation.StartsWith("GTB3|", StringComparison.OrdinalIgnoreCase))
                {
                    string[] fields = invitation.Split(new[] { '|' }, 5);
                    if (fields.Length != 5) throw new InvalidDataException("This Gran Turismo Bulgaria invitation is incomplete.");
                    SelectedTransport = NetworkAdapterProbe.Parse(fields[1]);
                    if (SelectedTransport == ConnectionTransport.ZeroTier)
                    {
                        string networkId = ZeroTierManager.NormalizeNetworkId(fields[2]);
                        ConnectionProfile zeroTier = NetworkAdapterProbe.Detect(ConnectionTransport.ZeroTier);
                        if (!zeroTier.Available || !ZeroTierManager.IsJoined(networkId))
                        {
                            int exitCode = ZeroTierManager.ChangeMembership(networkId, true);
                            if (exitCode != 0) throw new InvalidOperationException("ZeroTier returned exit code " + exitCode + " while joining the host network.");
                            ZeroTierManager.SaveRecent(_root, networkId);
                            Thread.Sleep(1800);
                        }
                    }
                    _profile = NetworkAdapterProbe.Detect(SelectedTransport);
                    _hostMethod.Items.Clear(); _hostMethod.Items.Add(NetworkAdapterProbe.DisplayName(SelectedTransport)); _hostMethod.SelectedIndex = 0;
                    if ((_profile.UsesPrivateOverlay || SelectedTransport == ConnectionTransport.PhysicalLan) && !_profile.Available)
                        throw new InvalidOperationException(_profile.Diagnostic + (SelectedTransport == ConnectionTransport.ZeroTier ? " The join request was sent; ask the network owner to authorize Device ID " + ZeroTierManager.NodeId + "." : " Install/connect the selected network before joining."));
                    invitation = fields[3] + "|" + fields[4];
                }
                else if (invitation.StartsWith("GTB2|", StringComparison.OrdinalIgnoreCase))
                {
                    string[] fields = invitation.Split(new[] { '|' }, 4);
                    if (fields.Length != 4) throw new InvalidDataException("This Gran Turismo Bulgaria invitation is incomplete.");
                    SelectedTransport = NetworkAdapterProbe.Parse(fields[1]);
                    _profile = NetworkAdapterProbe.Detect(SelectedTransport);
                    _hostMethod.Items.Clear(); _hostMethod.Items.Add(NetworkAdapterProbe.DisplayName(SelectedTransport)); _hostMethod.SelectedIndex = 0;
                    if ((_profile.UsesPrivateOverlay || SelectedTransport == ConnectionTransport.PhysicalLan) && !_profile.Available)
                        throw new InvalidOperationException(_profile.Diagnostic + " Install/connect the selected network before joining.");
                    invitation = fields[2] + "|" + fields[3];
                }
                if (invitation.StartsWith("BETA|", StringComparison.OrdinalIgnoreCase)) { SelectedMode = OnlineEngineMode.OnlineBetaMedius; _engine.SelectedIndex = 0; invitation = invitation.Substring(5); }
                else if (invitation.StartsWith("LAN|", StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("This public release supports the Online Beta only.");
                else SelectedMode = OnlineEngineMode.OnlineBetaMedius;
                if (!File.Exists(Path.Combine(_root, "game", UnifiedDisc.FileName)))
                    throw new FileNotFoundException("The verified GT4 Online Beta disc has not been imported. Run the public installer again and select your own dumped image.");
                if (ActiveSession != null) ActiveSession.Dispose(); ActiveSession = PrivateSessionClient.Join(invitation); _status.Text = ActiveSession.Status; _use.Enabled = true;
                return true;
            }
            catch (Exception ex) { ActiveSession = null; _status.Text = ex.Message; return false; }
        }

        private static Button NewButton(string text, Color color, int width) { var b = new Button { Text = text, Size = new Size(width, 38), FlatStyle = FlatStyle.Flat, BackColor = color, ForeColor = Color.White }; b.FlatAppearance.BorderSize = 0; return b; }
    }

    internal static class TwoAppOnlineTest
    {
        public static int Run(string root)
        {
            string state = Path.Combine(root, "logs", "two-app-online-" + DateTime.Now.ToString("yyyyMMdd-HHmmss-fff"));
            Directory.CreateDirectory(state);
            string executable = Process.GetCurrentProcess().MainModule.FileName;
            var report = new List<string> { "Gran Turismo Bulgaria two-app online test " + DateTime.Now.ToString("O") };
            Process host = null, client = null;
            try
            {
                host = Process.Start(new ProcessStartInfo(executable, "--online-test-node host \"" + state + "\"") { UseShellExecute = false, WorkingDirectory = root });
                if (!WaitForFile(Path.Combine(state, "invitation.txt"), 8000)) throw new TimeoutException("Host app did not create an invitation.");
                client = Process.Start(new ProcessStartInfo(executable, "--online-test-node client \"" + state + "\"") { UseShellExecute = false, WorkingDirectory = root });
                bool hostDone = host.WaitForExit(20000);
                bool clientDone = client.WaitForExit(20000);
                if (!hostDone) { host.Kill(); report.Add("FAIL host app timed out"); }
                if (!clientDone) { client.Kill(); report.Add("FAIL client app timed out"); }
                string hostResult = ReadResult(Path.Combine(state, "host-result.txt"));
                string clientResult = ReadResult(Path.Combine(state, "client-result.txt"));
                report.Add("HOST " + hostResult);
                report.Add("CLIENT " + clientResult);
                bool ok = hostDone && clientDone && host.ExitCode == 0 && client.ExitCode == 0 && hostResult.StartsWith("PASS") && clientResult.StartsWith("PASS");
                report.Add(ok ? "RESULT PASS" : "RESULT FAIL");
                File.WriteAllLines(Path.Combine(root, "logs", "two-app-online-test.txt"), report.ToArray(), new UTF8Encoding(false));
                return ok ? 0 : 1;
            }
            catch (Exception ex)
            {
                report.Add("FAIL " + ex);
                report.Add("RESULT FAIL");
                File.WriteAllLines(Path.Combine(root, "logs", "two-app-online-test.txt"), report.ToArray(), new UTF8Encoding(false));
                return 1;
            }
            finally
            {
                foreach (Process process in new[] { host, client })
                    try { if (process != null && !process.HasExited) process.Kill(); } catch { }
            }
        }

        public static int RunNode(string role, string state)
        {
            Directory.CreateDirectory(state);
            try
            {
                return string.Equals(role, "host", StringComparison.OrdinalIgnoreCase) ? RunHost(state) : RunClient(state);
            }
            catch (Exception ex)
            {
                File.WriteAllText(Path.Combine(state, role + "-result.txt"), "FAIL " + ex, new UTF8Encoding(false));
                return 1;
            }
        }

        private static int RunHost(string state)
        {
            using (var session = PrivateSessionHost.Start("127.0.0.1", 0))
            {
                File.WriteAllText(Path.Combine(state, "invitation.txt"), session.Invitation, new UTF8Encoding(false));
                if (!WaitUntil(delegate { return session.Connected; }, 10000)) throw new TimeoutException("Client app did not authenticate.");
                session.StartRelay(0);
                int received = 0;
                session.Relay.PayloadReceived += delegate(byte[] payload) { if (payload != null && payload.Length >= 2 && payload[0] == (byte)'C') Interlocked.Increment(ref received); };
                File.WriteAllText(Path.Combine(state, "host-relay-ready"), "ready", new UTF8Encoding(false));
                if (!WaitForFile(Path.Combine(state, "client-sent"), 10000)) throw new TimeoutException("Client app did not send packets.");
                Thread.Sleep(750);
                for (int i = 0; i < 100; i++) { session.Relay.SendPayload(new byte[] { (byte)'H', (byte)i }); Thread.Sleep(2); }
                Thread.Sleep(750);
                bool ok = received >= 95;
                File.WriteAllText(Path.Combine(state, "host-result.txt"), (ok ? "PASS" : "FAIL") + " authenticated=true received=" + received + "/100 sent=100", new UTF8Encoding(false));
                return ok ? 0 : 1;
            }
        }

        private static int RunClient(string state)
        {
            if (!WaitForFile(Path.Combine(state, "invitation.txt"), 8000)) throw new TimeoutException("Invitation was not available.");
            string invitation = File.ReadAllText(Path.Combine(state, "invitation.txt"));
            using (var session = PrivateSessionClient.Join(invitation))
            {
                session.StartRelay(0);
                int received = 0;
                session.Relay.PayloadReceived += delegate(byte[] payload) { if (payload != null && payload.Length >= 2 && payload[0] == (byte)'H') Interlocked.Increment(ref received); };
                if (!WaitForFile(Path.Combine(state, "host-relay-ready"), 8000)) throw new TimeoutException("Host relay was not ready.");
                for (int i = 0; i < 100; i++) { session.Relay.SendPayload(new byte[] { (byte)'C', (byte)i }); Thread.Sleep(2); }
                File.WriteAllText(Path.Combine(state, "client-sent"), "sent", new UTF8Encoding(false));
                WaitUntil(delegate { return received >= 100; }, 6000);
                bool ok = received >= 95;
                File.WriteAllText(Path.Combine(state, "client-result.txt"), (ok ? "PASS" : "FAIL") + " authenticated=true received=" + received + "/100 sent=100", new UTF8Encoding(false));
                return ok ? 0 : 1;
            }
        }

        private static bool WaitForFile(string path, int timeoutMs) { return WaitUntil(delegate { return File.Exists(path); }, timeoutMs); }
        private static bool WaitUntil(Func<bool> condition, int timeoutMs)
        {
            Stopwatch watch = Stopwatch.StartNew();
            while (watch.ElapsedMilliseconds < timeoutMs) { if (condition()) return true; Thread.Sleep(25); }
            return condition();
        }
        private static string ReadResult(string path) { return File.Exists(path) ? File.ReadAllText(path).Trim() : "FAIL missing result"; }
    }

    internal static class FourAppOnlineTest
    {
        public static int Run(string root)
        {
            string state = Path.Combine(root, "logs", "four-app-online-" + DateTime.Now.ToString("yyyyMMdd-HHmmss-fff")); Directory.CreateDirectory(state);
            string executable = Process.GetCurrentProcess().MainModule.FileName; var processes = new List<Process>(); var report = new List<string> { "Gran Turismo Bulgaria four-app online test " + DateTime.Now.ToString("O") };
            try
            {
                processes.Add(Process.Start(new ProcessStartInfo(executable, "--four-app-test-node host \"" + state + "\"") { UseShellExecute = false, WorkingDirectory = root }));
                if (!WaitForFile(Path.Combine(state, "invitation.txt"), 8000)) throw new TimeoutException("Host app did not create an invitation.");
                for (int i = 1; i <= 3; i++) processes.Add(Process.Start(new ProcessStartInfo(executable, "--four-app-test-node client" + i + " \"" + state + "\"") { UseShellExecute = false, WorkingDirectory = root }));
                bool complete = true; foreach (Process p in processes) if (!p.WaitForExit(30000)) { complete = false; try { p.Kill(); } catch { } }
                bool ok = complete;
                foreach (string role in new[] { "host", "client1", "client2", "client3" })
                {
                    string path = Path.Combine(state, role + "-result.txt"); string value = File.Exists(path) ? File.ReadAllText(path).Trim() : "FAIL missing result"; report.Add(role.ToUpperInvariant() + " " + value); ok &= value.StartsWith("PASS");
                }
                foreach (Process p in processes) if (p.HasExited) ok &= p.ExitCode == 0; else ok = false;
                report.Add(ok ? "RESULT PASS" : "RESULT FAIL"); File.WriteAllLines(Path.Combine(root, "logs", "four-app-online-test.txt"), report.ToArray(), new UTF8Encoding(false)); return ok ? 0 : 1;
            }
            catch (Exception ex) { report.Add("FAIL " + ex); report.Add("RESULT FAIL"); File.WriteAllLines(Path.Combine(root, "logs", "four-app-online-test.txt"), report.ToArray(), new UTF8Encoding(false)); return 1; }
            finally { foreach (Process p in processes) try { if (p != null && !p.HasExited) p.Kill(); } catch { } }
        }

        public static int RunNode(string role, string state)
        {
            try { return role == "host" ? RunHost(state) : RunClient(state, int.Parse(role.Substring(6))); }
            catch (Exception ex) { File.WriteAllText(Path.Combine(state, role + "-result.txt"), "FAIL " + ex, new UTF8Encoding(false)); return 1; }
        }

        private static int RunHost(string state)
        {
            using (var host = PrivateSessionHost.Start("127.0.0.1", 0))
            {
                File.WriteAllText(Path.Combine(state, "invitation.txt"), host.Invitation, new UTF8Encoding(false));
                if (!WaitUntil(delegate { return host.PeerCount == 3; }, 12000)) throw new TimeoutException("Three clients did not authenticate; count=" + host.PeerCount);
                int controlReplies = 0; host.ControlMessage += delegate(byte type, byte[] payload) { if (type == 91 && payload.Length == 1) Interlocked.Increment(ref controlReplies); };
                for (int i = 1; i <= 3; i++) if (!WaitForFile(Path.Combine(state, "client" + i + "-control-ready"), 8000)) throw new TimeoutException("Client " + i + " control channel was not ready.");
                host.SendControl(90, Encoding.UTF8.GetBytes("FOUR-APP-AUTHENTICATED-CONTROL"));
                if (!WaitUntil(delegate { return controlReplies == 3; }, 8000)) throw new TimeoutException("Not all clients returned encrypted control acknowledgements.");
                host.StartRelay(0); int received = 0; host.Relay.PayloadReceived += delegate(byte[] p) { if (p.Length == 3 && p[0] == (byte)'C') Interlocked.Increment(ref received); };
                File.WriteAllText(Path.Combine(state, "relay-ready"), "ready", new UTF8Encoding(false));
                for (int i = 1; i <= 3; i++) if (!WaitForFile(Path.Combine(state, "client" + i + "-udp-ready"), 12000)) throw new TimeoutException("Client " + i + " UDP path was not ready.");
                Thread.Sleep(1000); File.WriteAllText(Path.Combine(state, "send-now"), "send", new UTF8Encoding(false));
                for (int i = 1; i <= 3; i++) if (!WaitForFile(Path.Combine(state, "client" + i + "-sent"), 12000)) throw new TimeoutException("Client " + i + " did not send race packets.");
                for (int i = 0; i < 100; i++) { host.Relay.SendPayload(new byte[] { (byte)'H', 0, (byte)i }); Thread.Sleep(2); }
                WaitUntil(delegate { return received >= 300; }, 6000); bool ok = received >= 285;
                File.WriteAllText(Path.Combine(state, "host-result.txt"), (ok ? "PASS" : "FAIL") + " peers=" + host.PeerCount + "/3 control=3/3 UDP-from-clients=" + received + "/300", new UTF8Encoding(false)); return ok ? 0 : 1;
            }
        }

        private static int RunClient(string state, int id)
        {
            string role = "client" + id; if (!WaitForFile(Path.Combine(state, "invitation.txt"), 8000)) throw new TimeoutException("Invitation missing.");
            using (var client = PrivateSessionClient.Join(File.ReadAllText(Path.Combine(state, "invitation.txt"))))
            {
                var control = new AutoResetEvent(false); client.ControlMessage += delegate(byte type, byte[] payload) { if (type == 90 && Encoding.UTF8.GetString(payload) == "FOUR-APP-AUTHENTICATED-CONTROL") { client.SendControl(91, new[] { (byte)id }); control.Set(); } };
                File.WriteAllText(Path.Combine(state, role + "-control-ready"), "ready", new UTF8Encoding(false));
                if (!control.WaitOne(10000)) throw new TimeoutException("Encrypted host broadcast was not received.");
                client.StartRelay(0); int fromHost = 0, fromPeers = 0;
                client.Relay.PayloadReceived += delegate(byte[] p) { if (p.Length == 3 && p[0] == (byte)'H') Interlocked.Increment(ref fromHost); else if (p.Length == 3 && p[0] == (byte)'C' && p[1] != id) Interlocked.Increment(ref fromPeers); };
                if (!WaitForFile(Path.Combine(state, "relay-ready"), 8000)) throw new TimeoutException("Host relay missing."); Thread.Sleep(1000); File.WriteAllText(Path.Combine(state, role + "-udp-ready"), "ready", new UTF8Encoding(false));
                if (!WaitForFile(Path.Combine(state, "send-now"), 8000)) throw new TimeoutException("Host send signal missing.");
                for (int i = 0; i < 100; i++) { client.Relay.SendPayload(new byte[] { (byte)'C', (byte)id, (byte)i }); Thread.Sleep(2); }
                File.WriteAllText(Path.Combine(state, role + "-sent"), "sent", new UTF8Encoding(false));
                WaitUntil(delegate { return fromHost >= 100 && fromPeers >= 190; }, 8000); bool ok = fromHost >= 95 && fromPeers >= 190;
                File.WriteAllText(Path.Combine(state, role + "-result.txt"), (ok ? "PASS" : "FAIL") + " authenticated=true hostUDP=" + fromHost + "/100 peerUDP=" + fromPeers + "/200", new UTF8Encoding(false)); return ok ? 0 : 1;
            }
        }

        private static bool WaitForFile(string path, int timeout) { return WaitUntil(delegate { return File.Exists(path); }, timeout); }
        private static bool WaitUntil(Func<bool> condition, int timeout) { Stopwatch w = Stopwatch.StartNew(); while (w.ElapsedMilliseconds < timeout) { if (condition()) return true; Thread.Sleep(25); } return condition(); }
    }

    internal static class PrivateSessionSelfTest
    {
        public static int Run(string root)
        {
            var lines = new List<string> { "Gran Turismo Bulgaria private-session self-test " + DateTime.Now.ToString("O") };
            bool ok = false; PrivateSessionHost host = null; PrivateSessionClient client = null;
            try
            {
                host = PrivateSessionHost.Start("127.0.0.1", 0);
                bool waitingHost = !host.Connected && !string.IsNullOrWhiteSpace(host.Invitation);
                lines.Add((waitingHost ? "PASS " : "FAIL ") + "host can launch before friends and keep invitation listener ready");
                var peerConnected = new AutoResetEvent(false);
                host.ConnectionChanged += delegate { if (host.Connected) peerConnected.Set(); };
                client = PrivateSessionClient.Join(host.Invitation);
                for (int i = 0; i < 30 && !host.Connected; i++) Thread.Sleep(50);
                bool deferredConnection = peerConnected.WaitOne(2000);
                lines.Add((deferredConnection ? "PASS " : "FAIL ") + "deferred host notification starts relay after friend joins");
                ok = waitingHost && deferredConnection && host.Connected && client.Connected;
                lines.Add((ok ? "PASS " : "FAIL ") + "mutual one-time-key authentication");
                lines.Add("PASS invitation contains no account credentials");
                var controlSignal = new AutoResetEvent(false); byte[] controlCopy = null;
                client.ControlMessage += delegate(byte type, byte[] data) { if (type == 77) { controlCopy = data; controlSignal.Set(); } };
                var serverReadySignal = new AutoResetEvent(false);
                client.ControlMessage += delegate(byte type, byte[] data) { if (type == 30 && Encoding.ASCII.GetString(data) == "GT4-ONLINE-READY-V1") serverReadySignal.Set(); };
                host.SendControl(30, Encoding.ASCII.GetBytes("GT4-ONLINE-READY-V1"));
                bool readyOk = serverReadySignal.WaitOne(3000);
                ok &= readyOk; lines.Add((readyOk ? "PASS " : "FAIL ") + "authenticated host-ready launch barrier");
                byte[] campaignFrame = new byte[2 * 1024 * 1024]; new Random(2468).NextBytes(campaignFrame);
                host.SendControl(77, campaignFrame);
                bool controlOk = controlSignal.WaitOne(5000) && controlCopy != null && campaignFrame.SequenceEqual(controlCopy);
                ok &= controlOk; lines.Add((controlOk ? "PASS " : "FAIL ") + "encrypted reliable campaign channel 2 MiB");
                host.StartRelay(0); client.StartRelay(0);
                var signal = new AutoResetEvent(false); byte[] echoed = null;
                host.Relay.PayloadReceived += delegate(byte[] data) { host.Relay.SendPayload(data); };
                client.Relay.PayloadReceived += delegate(byte[] data) { echoed = data; signal.Set(); };
                Thread.Sleep(900);
                var timings = new List<long>(); int delivered = 0;
                for (int i = 0; i < 100; i++)
                {
                    byte[] sample = Encoding.ASCII.GetBytes("GT4-RACE-PACKET-" + i.ToString("D4") + new string('x', 256));
                    echoed = null; var watch = Stopwatch.StartNew(); client.Relay.SendPayload(sample);
                    if (signal.WaitOne(750) && echoed != null && sample.SequenceEqual(echoed)) { delivered++; timings.Add(watch.ElapsedTicks); }
                }
                timings.Sort(); double p95 = timings.Count == 0 ? 0 : timings[(int)Math.Min(timings.Count - 1, Math.Ceiling(timings.Count * 0.95) - 1)] * 1000.0 / Stopwatch.Frequency;
                bool tunnelOk = delivered == 100;
                ok &= tunnelOk;
                lines.Add((tunnelOk ? "PASS " : "FAIL ") + "encrypted UDP relay packets " + delivered + "/100, loopback p95=" + p95.ToString("0.00") + "ms");
                bool bridgeOk = false;
                for (int attempt = 0; attempt < 3 && !bridgeOk; attempt++) { bridgeOk = TestLocalGameBridge(); if (!bridgeOk) Thread.Sleep(250); }
                ok &= bridgeOk;
                lines.Add((bridgeOk ? "PASS " : "FAIL ") + "synthetic UDP bridge transport (real GT4 uses the signed packet-capture helper)");
            }
            catch (Exception ex) { lines.Add("FAIL " + ex); }
            finally { if (client != null) client.Dispose(); if (host != null) host.Dispose(); }
            lines.Add(ok ? "RESULT PASS" : "RESULT FAIL");
            string logs = Path.Combine(root, "logs"); Directory.CreateDirectory(logs); File.WriteAllLines(Path.Combine(logs, "network-self-test.txt"), lines.ToArray(), new UTF8Encoding(false));
            return ok ? 0 : 1;
        }

        private static bool TestLocalGameBridge()
        {
            int tunnelPort = FreeUdpPort(), hostGamePort = FreeUdpPort(), clientGamePort = FreeUdpPort();
            byte[] secret = new byte[32]; using (var rng = RandomNumberGenerator.Create()) rng.GetBytes(secret);
            SecureUdpRelay host = null, client = null;
            UdpClient hostGame = null, clientGame = null;
            try
            {
                host = SecureUdpRelay.CreateHost(secret, tunnelPort, hostGamePort);
                client = SecureUdpRelay.CreateClient(secret, "127.0.0.1", tunnelPort, clientGamePort);
                hostGame = BindSharedGameSocket(hostGamePort); clientGame = BindSharedGameSocket(clientGamePort);
                clientGame.Client.ReceiveTimeout = 3000; hostGame.Client.ReceiveTimeout = 3000;
                Thread.Sleep(900);
                byte[] outbound = Encoding.ASCII.GetBytes("GT4-LOCAL-BRIDGE-HOST-TO-CLIENT");
                hostGame.Send(outbound, outbound.Length, new IPEndPoint(IPAddress.Broadcast, hostGamePort));
                byte[] atClient = ReceiveExpected(clientGame, outbound, 3000);
                byte[] reverse = Encoding.ASCII.GetBytes("GT4-LOCAL-BRIDGE-CLIENT-TO-HOST");
                clientGame.Send(reverse, reverse.Length, new IPEndPoint(IPAddress.Broadcast, clientGamePort));
                byte[] atHost = ReceiveExpected(hostGame, reverse, 3000);
                return atClient != null && atHost != null;
            }
            catch { return false; }
            finally
            {
                if (hostGame != null) hostGame.Close(); if (clientGame != null) clientGame.Close();
                if (client != null) client.Dispose(); if (host != null) host.Dispose();
            }
        }

        private static UdpClient BindSharedGameSocket(int port)
        {
            var socket = new UdpClient(AddressFamily.InterNetwork); socket.ExclusiveAddressUse = false; socket.EnableBroadcast = true;
            socket.Client.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);
            socket.Client.Bind(new IPEndPoint(IPAddress.Any, port));
            return socket;
        }

        private static byte[] ReceiveExpected(UdpClient socket, byte[] expected, int timeoutMs)
        {
            Stopwatch watch = Stopwatch.StartNew();
            while (watch.ElapsedMilliseconds < timeoutMs)
            {
                try
                {
                    socket.Client.ReceiveTimeout = Math.Max(100, timeoutMs - (int)watch.ElapsedMilliseconds);
                    var from = new IPEndPoint(IPAddress.Any, 0); byte[] data = socket.Receive(ref from);
                    if (data.SequenceEqual(expected)) return data;
                }
                catch (SocketException) { return null; }
            }
            return null;
        }

        private static int FreeUdpPort()
        {
            using (var socket = new UdpClient(new IPEndPoint(IPAddress.Loopback, 0))) return ((IPEndPoint)socket.Client.LocalEndPoint).Port;
        }
    }

    internal sealed class GraphicsOptions
    {
        public string Profile = "Auto";
        public string Renderer = "Auto";
        public int Scale = 3;
        public int Anisotropy = 16;
        public bool Vsync;
        public bool Widescreen = true;
        public bool NoInterlace = true;
        public bool Fxaa = true;
        public bool LaunchFullscreen = true;
        public int MenuVolume = 28;
        public int UiScalePercent;
        private HardwareInfo _detected;

        public int RendererCode
        {
            get
            {
                switch (Renderer)
                {
                    case "Direct3D 11": return 3;
                    case "OpenGL": return 12;
                    case "Software": return 13;
                    case "Vulkan": return 14;
                    case "Direct3D 12": return 15;
                    default: return -1;
                }
            }
        }

        public GraphicsOptions ResolveAuto()
        {
            if (Profile != "Auto") return Clone();
            var hardware = _detected ?? HardwareProbe.Detect();
            var resolved = Clone();
            resolved.Renderer = "Auto";
            if (hardware.Tier >= 3) { resolved.Scale = 6; resolved.Anisotropy = 16; resolved.Fxaa = true; }
            else if (hardware.Tier == 2) { resolved.Scale = 4; resolved.Anisotropy = 16; resolved.Fxaa = true; }
            else if (hardware.Tier == 1) { resolved.Scale = 2; resolved.Anisotropy = 8; resolved.Fxaa = false; }
            else { resolved.Scale = 1; resolved.Anisotropy = 0; resolved.Fxaa = false; }
            return resolved;
        }

        public GraphicsOptions Clone()
        {
            return new GraphicsOptions { Profile = Profile, Renderer = Renderer, Scale = Scale, Anisotropy = Anisotropy, Vsync = Vsync, Widescreen = Widescreen, NoInterlace = NoInterlace, Fxaa = Fxaa, LaunchFullscreen = LaunchFullscreen, MenuVolume = MenuVolume, UiScalePercent = UiScalePercent, _detected = _detected };
        }

        public string Describe()
        {
            GraphicsOptions value = ResolveAuto();
            return (Profile == "Auto" ? "Auto → " : Profile + " • ") + value.Renderer + " • " + value.Scale + "x • AF " + (value.Anisotropy == 0 ? "Off" : value.Anisotropy + "x") + " • " + (LaunchFullscreen ? "Fullscreen" : "Windowed");
        }

        public void ApplyProfile(string profile)
        {
            Profile = profile;
            if (profile == "Performance") { Renderer = "Auto"; Scale = 1; Anisotropy = 0; Fxaa = false; }
            else if (profile == "Balanced") { Renderer = "Auto"; Scale = 3; Anisotropy = 8; Fxaa = true; }
            else if (profile == "Quality") { Renderer = "Auto"; Scale = 6; Anisotropy = 16; Fxaa = true; }
        }

        public static GraphicsOptions LoadOrDetect(string root)
        {
            var options = new GraphicsOptions();
            options._detected = HardwareProbe.Detect();
            string path = Path.Combine(root, "config", "launcher-settings.ini");
            if (!File.Exists(path)) return options;
            try
            {
                var values = File.ReadAllLines(path).Where(l => l.Contains("=")).Select(l => l.Split(new[] { '=' }, 2)).ToDictionary(p => p[0].Trim(), p => p[1].Trim(), StringComparer.OrdinalIgnoreCase);
                string value;
                int number;
                bool flag;
                if (values.TryGetValue("Profile", out value)) options.Profile = value;
                if (values.TryGetValue("Renderer", out value)) options.Renderer = value;
                if (values.TryGetValue("Scale", out value) && int.TryParse(value, out number)) options.Scale = Math.Max(1, Math.Min(8, number));
                if (values.TryGetValue("Anisotropy", out value) && int.TryParse(value, out number)) options.Anisotropy = number;
                if (values.TryGetValue("Vsync", out value) && bool.TryParse(value, out flag)) options.Vsync = flag;
                if (values.TryGetValue("Widescreen", out value) && bool.TryParse(value, out flag)) options.Widescreen = flag;
                if (values.TryGetValue("NoInterlace", out value) && bool.TryParse(value, out flag)) options.NoInterlace = flag;
                if (values.TryGetValue("Fxaa", out value) && bool.TryParse(value, out flag)) options.Fxaa = flag;
                if (values.TryGetValue("LaunchFullscreen", out value) && bool.TryParse(value, out flag)) options.LaunchFullscreen = flag;
                if (values.TryGetValue("MenuVolume", out value) && int.TryParse(value, out number)) options.MenuVolume = Math.Max(0, Math.Min(100, number));
                if (values.TryGetValue("UiScalePercent", out value) && int.TryParse(value, out number) && (number == 0 || number == 100 || number == 125 || number == 150 || number == 175)) options.UiScalePercent = number;
            }
            catch { }
            return options;
        }

        public void Save(string root)
        {
            string directory = Path.Combine(root, "config");
            Directory.CreateDirectory(directory);
            File.WriteAllLines(Path.Combine(directory, "launcher-settings.ini"), new[]
            {
                "Profile=" + Profile, "Renderer=" + Renderer, "Scale=" + Scale, "Anisotropy=" + Anisotropy,
                "Vsync=" + Vsync, "Widescreen=" + Widescreen, "NoInterlace=" + NoInterlace, "Fxaa=" + Fxaa,
                "LaunchFullscreen=" + LaunchFullscreen, "MenuVolume=" + MenuVolume, "UiScalePercent=" + UiScalePercent
            }, new UTF8Encoding(false));
        }
    }

    internal static class UiScaleManager
    {
        public static float Current = 1F;

        public static float Resolve(int requestedPercent, Rectangle workingArea, float dpiScale)
        {
            if (requestedPercent >= 100) return Math.Max(1F, Math.Min(1.75F, requestedPercent / 100F));
            float resolution = workingArea.Height >= 1350 ? 1.5F : (workingArea.Height >= 950 ? 1.25F : 1F);
            float dpi = dpiScale >= 1.75F ? 1.5F : (dpiScale >= 1.25F ? 1.25F : 1F);
            return Math.Max(resolution, dpi);
        }
    }

    internal sealed class HardwareInfo
    {
        public int Tier;
        public string Summary;
    }

    internal static class HardwareProbe
    {
        public static HardwareInfo Detect()
        {
            string gpu = "Unknown GPU";
            ulong gpuRam = 0;
            ulong systemRam = 0;
            int cores = Environment.ProcessorCount;
            try
            {
                using (var searcher = new ManagementObjectSearcher("SELECT Name, AdapterRAM FROM Win32_VideoController"))
                    foreach (ManagementObject item in searcher.Get())
                    {
                        string name = Convert.ToString(item["Name"]);
                        ulong ram = 0;
                        try { ram = Convert.ToUInt64(item["AdapterRAM"]); } catch { }
                        if (ram >= gpuRam && !string.IsNullOrWhiteSpace(name)) { gpu = name.Trim(); gpuRam = ram; }
                    }
                using (var searcher = new ManagementObjectSearcher("SELECT TotalPhysicalMemory FROM Win32_ComputerSystem"))
                    foreach (ManagementObject item in searcher.Get()) { try { systemRam = Convert.ToUInt64(item["TotalPhysicalMemory"]); } catch { } }
            }
            catch { }
            if (gpu == "Unknown GPU")
            {
                try
                {
                    string log = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data", "player1", "PCSX2", "logs", "emulog.txt");
                    if (File.Exists(log))
                    {
                        foreach (string line in File.ReadLines(log))
                        {
                            var match = Regex.Match(line, @"GPU\s*=\s*(.+)$", RegexOptions.IgnoreCase);
                            if (match.Success && !match.Groups[1].Value.Contains("Microsoft Basic")) { gpu = match.Groups[1].Value.Trim(); break; }
                        }
                    }
                }
                catch { }
            }
            string lower = gpu.ToLowerInvariant();
            int tier = 1;
            if (lower.Contains("7900") || lower.Contains("7800") || lower.Contains("7700") || lower.Contains("6900") || lower.Contains("6800") || Regex.IsMatch(lower, @"rtx\s*(30|40|50)")) tier = 3;
            else if (lower.Contains("radeon rx") || lower.Contains("rtx") || lower.Contains("gtx 16") || gpuRam >= 4UL * 1024 * 1024 * 1024) tier = 2;
            else if (gpu == "Unknown GPU" && cores >= 8) tier = 2;
            if (cores < 4 || (systemRam > 0 && systemRam < 8UL * 1024 * 1024 * 1024)) tier = Math.Min(tier, 1);
            string summary = gpu + " • " + cores + " logical CPUs" + (systemRam == 0 ? "" : " • " + Math.Round(systemRam / 1073741824.0) + " GB RAM") + " • tier " + tier;
            return new HardwareInfo { Tier = tier, Summary = summary };
        }
    }

    internal static class IniEditor
    {
        public static string GetInSection(string text, string section, string key)
        {
            string sectionPattern = "(?ms)(^\\[" + Regex.Escape(section) + @"\]\s*\r?\n)(.*?)(?=^\[|\z)";
            Match sectionMatch = Regex.Match(text ?? string.Empty, sectionPattern);
            if (!sectionMatch.Success) return "missing";
            Match keyMatch = Regex.Match(sectionMatch.Groups[2].Value, "(?m)^" + Regex.Escape(key) + @"\s*=\s*(.*?)\s*$");
            return keyMatch.Success ? keyMatch.Groups[1].Value.Trim() : "missing";
        }

        public static string Set(string text, string key, string value)
        {
            string pattern = "(?m)^" + Regex.Escape(key) + @"\s*=.*$";
            if (Regex.IsMatch(text, pattern)) return new Regex(pattern).Replace(text, key + " = " + value, 1);
            return text + Environment.NewLine + key + " = " + value + Environment.NewLine;
        }

        public static string SetInSection(string text, string section, string key, string value)
        {
            string sectionPattern = "(?ms)(^\\[" + Regex.Escape(section) + @"\]\s*\r?\n)(.*?)(?=^\[|\z)";
            Match match = Regex.Match(text, sectionPattern);
            if (!match.Success)
            {
                if (!text.EndsWith(Environment.NewLine)) text += Environment.NewLine;
                return text + "[" + section + "]" + Environment.NewLine + key + " = " + value + Environment.NewLine;
            }
            string body = match.Groups[2].Value;
            string keyPattern = "(?m)^" + Regex.Escape(key) + @"\s*=.*$";
            if (Regex.IsMatch(body, keyPattern))
                body = new Regex(keyPattern).Replace(body, key + " = " + value, 1);
            else
                body = key + " = " + value + Environment.NewLine + body;
            return text.Substring(0, match.Groups[2].Index) + body + text.Substring(match.Groups[2].Index + match.Groups[2].Length);
        }

        public static string SetListInSection(string text, string section, string key, params string[] values)
        {
            string sectionPattern = "(?ms)(^\\[" + Regex.Escape(section) + @"\]\s*\r?\n)(.*?)(?=^\[|\z)";
            Match match = Regex.Match(text, sectionPattern);
            string replacement = string.Join(Environment.NewLine, values.Select(v => key + " = " + v).ToArray());
            if (replacement.Length > 0) replacement += Environment.NewLine;
            if (!match.Success)
            {
                if (!text.EndsWith(Environment.NewLine)) text += Environment.NewLine;
                return text + "[" + section + "]" + Environment.NewLine + replacement;
            }
            string body = match.Groups[2].Value;
            string keyPattern = "(?m)^" + Regex.Escape(key) + @"\s*=.*(?:\r?\n|$)";
            body = Regex.Replace(body, keyPattern, string.Empty);
            body = replacement + body;
            return text.Substring(0, match.Groups[2].Index) + body + text.Substring(match.Groups[2].Index + match.Groups[2].Length);
        }
    }

    internal sealed class GraphicsSettingsForm : Form
    {
        private readonly ComboBox _profile = NewCombo();
        private readonly ComboBox _renderer = NewCombo();
        private readonly ComboBox _scale = NewCombo();
        private readonly ComboBox _af = NewCombo();
        private readonly ComboBox _uiScale = NewCombo();
        private readonly CheckBox _vsync = NewCheck("VSync");
        private readonly CheckBox _widescreen = NewCheck("16:9 widescreen patch");
        private readonly CheckBox _noInterlace = NewCheck("No-interlacing patch");
        private readonly CheckBox _fxaa = NewCheck("FXAA smoothing");
        private readonly CheckBox _launchFullscreen = NewCheck("Start game fullscreen (off = windowed)");
        private readonly TrackBar _menuVolume = new TrackBar { Minimum = 0, Maximum = 100, TickFrequency = 10, Width = 260, Height = 38, BackColor = Color.FromArgb(13, 18, 23) };
        public GraphicsOptions Options { get; private set; }

        public GraphicsSettingsForm(GraphicsOptions current, HardwareInfo hardware)
        {
            Options = current.Clone();
            Text = "Gran Turismo Bulgaria — Graphics";
            ClientSize = new Size(620, 650);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Color.FromArgb(13, 18, 23);
            ForeColor = Color.White;
            Font = new Font("Segoe UI", 10F);

            var heading = LauncherForm.NewPublicLabel(19, FontStyle.Bold, Color.White);
            heading.Text = "GRAPHICS & EMULATION";
            heading.AutoSize = true;
            heading.Location = new Point(26, 22);
            Controls.Add(heading);
            var detected = LauncherForm.NewPublicLabel(9, FontStyle.Regular, Color.FromArgb(170, 190, 199));
            detected.Text = "Detected: " + hardware.Summary;
            detected.AutoSize = false; detected.Size = new Size(565, 42); detected.Location = new Point(27, 61);
            Controls.Add(detected);

            AddRow("Preset", _profile, 108);
            _profile.Items.AddRange(new object[] { "Auto", "Performance", "Balanced", "Quality", "Custom" });
            AddRow("Renderer", _renderer, 157);
            _renderer.Items.AddRange(new object[] { "Auto", "Vulkan", "Direct3D 12", "Direct3D 11", "OpenGL", "Software" });
            AddRow("Internal resolution", _scale, 206);
            _scale.Items.AddRange(Enumerable.Range(1, 8).Select(x => (object)(x + "x")).ToArray());
            AddRow("Anisotropic filtering", _af, 255);
            _af.Items.AddRange(new object[] { "Off", "2x", "4x", "8x", "16x" });
            _vsync.Location = new Point(29, 313); _widescreen.Location = new Point(150, 313);
            _noInterlace.Location = new Point(350, 313); _fxaa.Location = new Point(29, 347);
            _launchFullscreen.Location = new Point(150, 347);
            Controls.AddRange(new Control[] { _vsync, _widescreen, _noInterlace, _fxaa, _launchFullscreen });

            AddRow("Menu sound volume", _menuVolume, 388);
            _menuVolume.ValueChanged += delegate { MenuAudio.Volume = _menuVolume.Value; };
            AddRow("Interface scale", _uiScale, 437);
            _uiScale.Items.AddRange(new object[] { "Auto (desktop + DPI)", "100%", "125%", "150%", "175%" });

            var note = LauncherForm.NewPublicLabel(8.5F, FontStyle.Regular, Color.FromArgb(165, 178, 188));
            note.Text = "Interface scale applies to Graphics, Online Status, Shared Campaign and other opened pages.\nThe main home artwork is unchanged. Pages are automatically limited to the available desktop size.";
            note.AutoSize = true; note.Location = new Point(29, 491); Controls.Add(note);

            var save = NewButton("SAVE", Color.FromArgb(206, 17, 38)); save.Location = new Point(403, 590);
            var cancel = NewButton("CANCEL", Color.FromArgb(47, 56, 64)); cancel.Location = new Point(497, 590);
            save.Click += delegate { SaveAndClose(); }; cancel.Click += delegate { DialogResult = DialogResult.Cancel; Close(); };
            Controls.AddRange(new Control[] { save, cancel });
            AcceptButton = save; CancelButton = cancel;

            LoadValues();
            _profile.SelectedIndexChanged += delegate { if (_profile.SelectedItem != null && _profile.SelectedItem.ToString() != "Custom") { Options.ApplyProfile(_profile.SelectedItem.ToString()); LoadValues(false); } };
            foreach (var combo in new[] { _renderer, _scale, _af }) combo.SelectedIndexChanged += delegate { if (_profile.SelectedItem != null && _profile.SelectedItem.ToString() != "Auto") _profile.SelectedItem = "Custom"; };
        }

        private static ComboBox NewCombo() { return new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(34, 42, 49), ForeColor = Color.White, Width = 260, Height = 30 }; }
        private static CheckBox NewCheck(string text) { return new CheckBox { Text = text, AutoSize = true, ForeColor = Color.White, BackColor = Color.Transparent }; }
        private static Button NewButton(string text, Color color) { var b = new Button { Text = text, Size = new Size(88, 34), FlatStyle = FlatStyle.Flat, BackColor = color, ForeColor = Color.White }; b.FlatAppearance.BorderSize = 0; return b; }
        private void AddRow(string caption, Control control, int y) { var label = LauncherForm.NewPublicLabel(9, FontStyle.Bold, Color.FromArgb(210, 218, 225)); label.Text = caption; label.AutoSize = true; label.Location = new Point(29, y + 6); Controls.Add(label); control.Location = new Point(255, y); Controls.Add(control); }
        private void LoadValues(bool profileToo = true)
        {
            if (profileToo) _profile.SelectedItem = Options.Profile;
            var display = Options.ResolveAuto();
            _renderer.SelectedItem = display.Renderer;
            _scale.SelectedItem = display.Scale + "x";
            _af.SelectedItem = display.Anisotropy == 0 ? "Off" : display.Anisotropy + "x";
            _vsync.Checked = display.Vsync; _widescreen.Checked = display.Widescreen; _noInterlace.Checked = display.NoInterlace; _fxaa.Checked = display.Fxaa;
            _launchFullscreen.Checked = Options.LaunchFullscreen;
            _menuVolume.Value = Math.Max(0, Math.Min(100, Options.MenuVolume));
            _uiScale.SelectedItem = Options.UiScalePercent == 0 ? "Auto (desktop + DPI)" : Options.UiScalePercent + "%";
        }
        private void SaveAndClose()
        {
            Options.Profile = Convert.ToString(_profile.SelectedItem);
            Options.Renderer = Convert.ToString(_renderer.SelectedItem);
            Options.Scale = int.Parse(Convert.ToString(_scale.SelectedItem).TrimEnd('x'));
            string af = Convert.ToString(_af.SelectedItem); Options.Anisotropy = af == "Off" ? 0 : int.Parse(af.TrimEnd('x'));
            Options.Vsync = _vsync.Checked; Options.Widescreen = _widescreen.Checked; Options.NoInterlace = _noInterlace.Checked; Options.Fxaa = _fxaa.Checked;
            Options.LaunchFullscreen = _launchFullscreen.Checked;
            Options.MenuVolume = _menuVolume.Value;
            string uiScale = Convert.ToString(_uiScale.SelectedItem);
            Options.UiScalePercent = uiScale.StartsWith("Auto", StringComparison.OrdinalIgnoreCase) ? 0 : int.Parse(uiScale.TrimEnd('%'));
            MenuAudio.Volume = Options.MenuVolume;
            DialogResult = DialogResult.OK; Close();
        }
    }

    internal static class MenuAudio
    {
        private static readonly object Sync = new object();
        private static readonly Queue<Tuple<System.Media.SoundPlayer, MemoryStream>> Active = new Queue<Tuple<System.Media.SoundPlayer, MemoryStream>>();
        private static int _volume = 28;
        public static int Volume { get { return _volume; } set { _volume = Math.Max(0, Math.Min(100, value)); } }
        public static void PlayMove() { Play("menu-move.wav"); }
        public static void PlayConfirm() { Play("menu-confirm.wav"); }
        public static void PlayBack() { Play("menu-back.wav"); }

        private static void Play(string fileName)
        {
            int volume = Math.Max(0, Math.Min(100, Volume));
            if (volume == 0) return;
            try
            {
                string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "assets", fileName);
                byte[] wave = File.ReadAllBytes(path);
                if (wave.Length < 44 || Encoding.ASCII.GetString(wave, 0, 4) != "RIFF") return;
                for (int i = 44; i + 1 < wave.Length; i += 2)
                {
                    short source = (short)(wave[i] | (wave[i + 1] << 8));
                    short scaled = (short)(source * (volume / 100.0));
                    wave[i] = (byte)(scaled & 255); wave[i + 1] = (byte)((scaled >> 8) & 255);
                }
                var stream = new MemoryStream(wave, false);
                var player = new System.Media.SoundPlayer(stream); player.Play();
                lock (Sync) { Active.Enqueue(Tuple.Create(player, stream)); while (Active.Count > 6) { var old = Active.Dequeue(); old.Item1.Dispose(); old.Item2.Dispose(); } }
            }
            catch { }
        }
    }

    internal sealed class BulgarianFlagPanel : Panel
    {
        public BulgarianFlagPanel() { DoubleBuffered = true; }
        protected override void OnPaint(PaintEventArgs e)
        {
            int third = Height / 3;
            e.Graphics.FillRectangle(Brushes.White, 0, 0, Width, third);
            using (var green = new SolidBrush(Color.FromArgb(0, 150, 110))) e.Graphics.FillRectangle(green, 0, third, Width, third);
            using (var red = new SolidBrush(Color.FromArgb(214, 38, 50))) e.Graphics.FillRectangle(red, 0, third * 2, Width, Height - third * 2);
            using (var pen = new Pen(Color.FromArgb(110, 255, 255, 255))) e.Graphics.DrawRectangle(pen, 0, 0, Width - 1, Height - 1);
        }
    }

    internal sealed class GtbLogoControl : Control
    {
        public GtbLogoControl() { SetStyle(ControlStyles.SupportsTransparentBackColor | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true); BackColor = Color.Transparent; }
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            using (var white = new SolidBrush(Color.White))
            using (var green = new SolidBrush(Color.FromArgb(0, 150, 110)))
            using (var red = new SolidBrush(Color.FromArgb(214, 38, 50)))
            using (var big = new Font("Segoe UI Black", 25F, FontStyle.Bold | FontStyle.Italic))
            using (var small = new Font("Segoe UI Semibold", 8.5F, FontStyle.Bold))
            {
                e.Graphics.DrawString("GT", big, white, -2, -6);
                e.Graphics.FillPolygon(green, new[] { new Point(89, 8), new Point(124, 8), new Point(105, 29), new Point(70, 29) });
                e.Graphics.FillPolygon(red, new[] { new Point(78, 31), new Point(114, 31), new Point(104, 45), new Point(68, 45) });
                e.Graphics.DrawString("GRAN TURISMO", small, white, 134, 4);
                e.Graphics.DrawString("B U L G A R I A", small, green, 134, 25);
                using (var pen = new Pen(Color.FromArgb(190, 220, 226, 232), 1F)) e.Graphics.DrawLine(pen, 134, 46, 354, 46);
            }
        }
    }

    internal static class ControllerConfiguration
    {
        private static readonly KeyValuePair<string, string>[] KeyboardBindings = new[]
        {
            Pair("Up", "Keyboard/Up"), Pair("Right", "Keyboard/Right"), Pair("Down", "Keyboard/Down"), Pair("Left", "Keyboard/Left"),
            Pair("Triangle", "Keyboard/I"), Pair("Circle", "Keyboard/L"), Pair("Cross", "Keyboard/K"), Pair("Square", "Keyboard/J"),
            Pair("Select", "Keyboard/Backspace"), Pair("Start", "Keyboard/Return"), Pair("L1", "Keyboard/Q"), Pair("L2", "Keyboard/1"),
            Pair("R1", "Keyboard/E"), Pair("R2", "Keyboard/3"), Pair("L3", "Keyboard/2"), Pair("R3", "Keyboard/4"),
            Pair("LUp", "Keyboard/W"), Pair("LRight", "Keyboard/D"), Pair("LDown", "Keyboard/S"), Pair("LLeft", "Keyboard/A"),
            Pair("RUp", "Keyboard/T"), Pair("RRight", "Keyboard/H"), Pair("RDown", "Keyboard/G"), Pair("RLeft", "Keyboard/F")
        };

        private static readonly KeyValuePair<string, string>[] GamepadBindings = new[]
        {
            Pair("Up", "DPadUp"), Pair("Right", "DPadRight"), Pair("Down", "DPadDown"), Pair("Left", "DPadLeft"),
            Pair("Triangle", "Y"), Pair("Circle", "B"), Pair("Cross", "A"), Pair("Square", "X"),
            Pair("Select", "Back"), Pair("Start", "Start"), Pair("L1", "LeftShoulder"), Pair("L2", "+LeftTrigger"),
            Pair("R1", "RightShoulder"), Pair("R2", "+RightTrigger"), Pair("L3", "LeftStick"), Pair("R3", "RightStick"),
            Pair("LUp", "-LeftY"), Pair("LRight", "+LeftX"), Pair("LDown", "+LeftY"), Pair("LLeft", "-LeftX"),
            Pair("RUp", "-RightY"), Pair("RRight", "+RightX"), Pair("RDown", "+RightY"), Pair("RLeft", "-RightX")
        };

        private static KeyValuePair<string, string> Pair(string key, string value)
        {
            return new KeyValuePair<string, string>(key, value);
        }

        public static void Apply(string appDataTarget, int controllerIndex)
        {
            string ini = Path.Combine(appDataTarget, "inis", "PCSX2.ini");
            if (!File.Exists(ini)) return;
            File.WriteAllText(ini, ApplyToText(File.ReadAllText(ini), controllerIndex), new UTF8Encoding(false));
        }

        internal static string ApplyToText(string text, int controllerIndex)
        {
            controllerIndex = Math.Max(0, Math.Min(3, controllerIndex));
            string device = "SDL-" + controllerIndex;
            text = IniEditor.SetInSection(text, "InputSources", "Keyboard", "true");
            text = IniEditor.SetInSection(text, "InputSources", "Mouse", "true");
            text = IniEditor.SetInSection(text, "InputSources", "SDL", "true");
            text = IniEditor.SetInSection(text, "InputSources", "DInput", "false");
            text = IniEditor.SetInSection(text, "InputSources", "XInput", "false");
            text = IniEditor.SetInSection(text, "InputSources", "SDLControllerEnhancedMode", "false");
            text = IniEditor.SetInSection(text, "Pad1", "Type", "DualShock2");
            text = IniEditor.SetInSection(text, "Pad1", "Deadzone", "0.10");
            text = IniEditor.SetInSection(text, "Pad1", "AxisScale", "1.33");
            text = IniEditor.SetInSection(text, "Pad1", "ButtonDeadzone", "0");
            foreach (var gamepad in GamepadBindings)
            {
                string keyboard = KeyboardBindings.First(k => k.Key == gamepad.Key).Value;
                text = IniEditor.SetListInSection(text, "Pad1", gamepad.Key, keyboard, device + "/" + gamepad.Value);
            }
            text = IniEditor.SetListInSection(text, "Pad1", "Analog", device + "/Guide");
            text = IniEditor.SetListInSection(text, "Pad1", "LargeMotor", device + "/LargeMotor");
            text = IniEditor.SetListInSection(text, "Pad1", "SmallMotor", device + "/SmallMotor");
            return text;
        }
    }

    internal static class ControllerConfigurationSelfTest
    {
        public static int Run(string root)
        {
            var lines = new List<string>();
            bool ok = true;
            try
            {
                string sample = "[InputSources]\r\nSDL = false\r\nXInput = true\r\n\r\n[Pad1]\r\nType = DualShock2\r\nCross = Keyboard/K\r\n";
                string mapped = ControllerConfiguration.ApplyToText(sample, 0);
                Action<string, bool> check = delegate(string name, bool passed) { lines.Add((passed ? "PASS " : "FAIL ") + name); if (!passed) ok = false; };
                check("SDL enabled", Regex.IsMatch(mapped, "(?m)^SDL = true\\r?$"));
                check("XInput duplicate source disabled", Regex.IsMatch(mapped, "(?m)^XInput = false\\r?$"));
                check("Xbox A maps to PS2 Cross", mapped.Contains("Cross = SDL-0/A"));
                check("keyboard Cross remains available", mapped.Contains("Cross = Keyboard/K"));
                check("left stick mapped", mapped.Contains("LLeft = SDL-0/-LeftX") && mapped.Contains("LRight = SDL-0/+LeftX"));
                check("triggers mapped", mapped.Contains("L2 = SDL-0/+LeftTrigger") && mapped.Contains("R2 = SDL-0/+RightTrigger"));
                check("vibration mapped", mapped.Contains("LargeMotor = SDL-0/LargeMotor") && mapped.Contains("SmallMotor = SDL-0/SmallMotor"));
                string remapped = ControllerConfiguration.ApplyToText(mapped, 0);
                check("mapping is repeat-safe", Regex.Matches(remapped, "(?m)^Cross = ").Count == 2);
                string mappedPlayerFour = ControllerConfiguration.ApplyToText(sample, 3);
                check("fourth controller isolation", mappedPlayerFour.Contains("Cross = SDL-3/A"));
                check("launcher ignores controller while game runs", !LauncherForm.LauncherControllerInputAllowed(FormWindowState.Normal, true, true));
                check("launcher ignores controller while minimized", !LauncherForm.LauncherControllerInputAllowed(FormWindowState.Minimized, true, false));
                check("launcher accepts controller only while focused", LauncherForm.LauncherControllerInputAllowed(FormWindowState.Normal, true, false) && !LauncherForm.LauncherControllerInputAllowed(FormWindowState.Normal, false, false));
                lines.Add("Detected now: " + string.Join(" | ", ControllerScanner.GetControllers().ToArray()));
            }
            catch (Exception ex) { ok = false; lines.Add("FAIL " + ex); }
            lines.Add(ok ? "RESULT PASS" : "RESULT FAIL");
            string logs = Path.Combine(root, "logs"); Directory.CreateDirectory(logs);
            File.WriteAllLines(Path.Combine(logs, "controller-self-test.txt"), lines.ToArray(), new UTF8Encoding(false));
            return ok ? 0 : 1;
        }
    }

    internal static class ControllerScanner
    {
        public static List<string> GetControllers()
        {
            var found = new List<string>();
            for (uint i = 0; i < 4; i++)
            {
                var state = new XInputState();
                if (TryGetState(i, ref state)) found.Add("Xbox/XInput controller " + (i + 1));
            }
            if (found.Count == 0) try
            {
                using (var searcher = new ManagementObjectSearcher("SELECT Name, Status, ConfigManagerErrorCode FROM Win32_PnPEntity WHERE PNPClass='HIDClass'"))
                {
                    foreach (ManagementObject item in searcher.Get())
                    {
                        if (!string.Equals(Convert.ToString(item["Status"]), "OK", StringComparison.OrdinalIgnoreCase)) continue;
                        if (Convert.ToUInt32(item["ConfigManagerErrorCode"]) != 0) continue;
                        string name = Convert.ToString(item["Name"]);
                        if (string.IsNullOrWhiteSpace(name)) continue;
                        string lower = name.ToLowerInvariant();
                        if ((lower.Contains("controller") || lower.Contains("gamepad") || lower.Contains("joystick") || lower.Contains("wheel")) && !found.Any(x => string.Equals(x, name, StringComparison.OrdinalIgnoreCase)))
                            found.Add(name.Trim());
                    }
                }
            }
            catch { }
            return found.Distinct(StringComparer.OrdinalIgnoreCase).Take(8).ToList();
        }

        public static bool TryGetButtons(uint userIndex, out ushort buttons)
        {
            buttons = 0;
            try
            {
                var state = new XInputState();
                if (!TryGetState(userIndex, ref state)) return false;
                buttons = state.Gamepad.Buttons;
                const int stickThreshold = 16000;
                if (state.Gamepad.ThumbLY > stickThreshold) buttons |= 0x0001;
                if (state.Gamepad.ThumbLY < -stickThreshold) buttons |= 0x0002;
                if (state.Gamepad.ThumbLX < -stickThreshold) buttons |= 0x0004;
                if (state.Gamepad.ThumbLX > stickThreshold) buttons |= 0x0008;
                return true;
            }
            catch { return false; }
        }

        private static bool TryGetState(uint userIndex, ref XInputState state)
        {
            try { if (XInputGetState14(userIndex, ref state) == 0) return true; } catch (DllNotFoundException) { } catch (EntryPointNotFoundException) { }
            try { if (XInputGetState13(userIndex, ref state) == 0) return true; } catch (DllNotFoundException) { } catch (EntryPointNotFoundException) { }
            try { if (XInputGetState910(userIndex, ref state) == 0) return true; } catch (DllNotFoundException) { } catch (EntryPointNotFoundException) { }
            return false;
        }

        [StructLayout(LayoutKind.Sequential)] private struct XInputGamepad { public ushort Buttons; public byte LeftTrigger; public byte RightTrigger; public short ThumbLX; public short ThumbLY; public short ThumbRX; public short ThumbRY; }
        [StructLayout(LayoutKind.Sequential)] private struct XInputState { public uint PacketNumber; public XInputGamepad Gamepad; }
        [DllImport("xinput1_4.dll", EntryPoint = "XInputGetState")] private static extern uint XInputGetState14(uint userIndex, ref XInputState state);
        [DllImport("xinput1_3.dll", EntryPoint = "XInputGetState")] private static extern uint XInputGetState13(uint userIndex, ref XInputState state);
        [DllImport("xinput9_1_0.dll", EntryPoint = "XInputGetState")] private static extern uint XInputGetState910(uint userIndex, ref XInputState state);
    }

    internal sealed class ExactInterfaceSurface : Control
    {
        private sealed class Hotspot
        {
            public string Name;
            public Rectangle Bounds;
            public Action Action;
            public bool Selectable;
        }

        private readonly Image _interfaceImage;
        private readonly List<Hotspot> _hotspots = new List<Hotspot>();
        private RectangleF _imageBounds;
        private int _selectedIndex;
        private int _hoverIndex = -1;
        private int _pressedIndex = -1;
        private int _controllerCount = -1;
        private string _connectionLabel = "AUTO — BEST AVAILABLE";
        private string _connectionDetail = "CHECKING CONNECTION…";
        private bool _connectionReady;
        private string _clockText = "--:--";

        public ExactInterfaceSurface(string imagePath)
        {
            if (!File.Exists(imagePath))
                throw new FileNotFoundException("The exact launcher interface image is missing.", imagePath);
            using (var source = Image.FromFile(imagePath))
                _interfaceImage = new Bitmap(source);
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
            TabStop = true;
            BackColor = Color.Black;
        }

        public void AddHotspot(string name, Rectangle bounds, Action action, bool selectable = true)
        {
            _hotspots.Add(new Hotspot { Name = name, Bounds = bounds, Action = action, Selectable = selectable });
        }

        public void SetControllerStatus(int count)
        {
            count = Math.Max(0, Math.Min(4, count));
            if (_controllerCount == count) return;
            _controllerCount = count;
            Invalidate();
        }

        public void SetConnectionStatus(string label, string detail, bool ready)
        {
            _connectionLabel = (label ?? "AUTO — BEST AVAILABLE").ToUpperInvariant();
            _connectionDetail = detail ?? string.Empty;
            _connectionReady = ready;
            Invalidate();
        }

        public void SetClock(string value)
        {
            if (string.Equals(_clockText, value, StringComparison.Ordinal)) return;
            _clockText = value ?? "--:--";
            Invalidate();
        }

        public bool HasValidLayout
        {
            get
            {
                var imageBounds = new Rectangle(0, 0, _interfaceImage.Width, _interfaceImage.Height);
                return _hotspots.Count == 15 && _hotspots.All(h => !string.IsNullOrWhiteSpace(h.Name) && h.Action != null && h.Bounds.Width > 0 && h.Bounds.Height > 0 && imageBounds.Contains(h.Bounds));
            }
        }

        public void MoveSelection(int delta)
        {
            if (_hotspots.Count == 0) return;
            int candidate = _selectedIndex;
            do
            {
                candidate = (candidate + delta + _hotspots.Count) % _hotspots.Count;
            }
            while (!_hotspots[candidate].Selectable && candidate != _selectedIndex);
            if (candidate != _selectedIndex) MenuAudio.PlayMove();
            _selectedIndex = candidate;
            Invalidate();
        }

        public void ActivateSelected()
        {
            if (_selectedIndex < 0 || _selectedIndex >= _hotspots.Count) return;
            var target = _hotspots[_selectedIndex];
            if (target.Selectable && target.Action != null) { if (target.Name == "BACK") MenuAudio.PlayBack(); else MenuAudio.PlayConfirm(); target.Action(); }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            float scale = Math.Min(ClientSize.Width / (float)_interfaceImage.Width, ClientSize.Height / (float)_interfaceImage.Height);
            float width = _interfaceImage.Width * scale;
            float height = _interfaceImage.Height * scale;
            _imageBounds = new RectangleF((ClientSize.Width - width) / 2F, (ClientSize.Height - height) / 2F, width, height);
            e.Graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
            e.Graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
            e.Graphics.DrawImage(_interfaceImage, _imageBounds);
            DrawLiveHomeState(e.Graphics);
            DrawFeedback(e.Graphics, _selectedIndex, Color.FromArgb(72, 218, 233, 241), 2F);
            if (_hoverIndex >= 0 && _hoverIndex != _selectedIndex)
                DrawFeedback(e.Graphics, _hoverIndex, Color.FromArgb(62, 255, 255, 255), 1.5F);
            if (_pressedIndex >= 0)
                DrawFeedback(e.Graphics, _pressedIndex, Color.FromArgb(105, 218, 35, 53), 3F);
        }

        private void DrawLiveHomeState(Graphics graphics)
        {
            if (_imageBounds.Width <= 0) return;
            float sx = _imageBounds.Width / _interfaceImage.Width;
            float sy = _imageBounds.Height / _interfaceImage.Height;
            RectangleF selector = ScaleRect(new RectangleF(129, 627, 344, 38), sx, sy);
            using (var fill = new SolidBrush(Color.FromArgb(255, 26, 36, 43))) graphics.FillRectangle(fill, selector);
            using (var font = new Font("Segoe UI Semibold", Math.Max(9F, 18F * Math.Min(sx, sy)), FontStyle.Regular, GraphicsUnit.Pixel))
            using (var brush = new SolidBrush(Color.FromArgb(236, 240, 244)))
            using (var format = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center, Trimming = StringTrimming.EllipsisCharacter })
                graphics.DrawString(_connectionLabel, font, brush, selector, format);

            RectangleF status = ScaleRect(new RectangleF(80, 674, 461, 25), sx, sy);
            using (var fill = new SolidBrush(Color.FromArgb(255, 17, 26, 31))) graphics.FillRectangle(fill, status);
            Color statusColor = _connectionReady ? Color.FromArgb(104, 235, 169) : Color.FromArgb(245, 178, 90);
            string detail = _connectionDetail.Replace("SETUP NEEDED  •  ", "SETUP NEEDED • ").Replace("READY  •  ", "READY • ");
            using (var font = new Font("Consolas", Math.Max(7F, 13F * Math.Min(sx, sy)), FontStyle.Regular, GraphicsUnit.Pixel))
            using (var brush = new SolidBrush(statusColor))
            using (var format = new StringFormat { Alignment = StringAlignment.Near, LineAlignment = StringAlignment.Center, Trimming = StringTrimming.EllipsisCharacter })
                graphics.DrawString(detail, font, brush, status, format);

            RectangleF clock = ScaleRect(new RectangleF(1524, 879, 83, 40), sx, sy);
            using (var fill = new SolidBrush(Color.FromArgb(255, 16, 21, 25))) graphics.FillRectangle(fill, clock);
            using (var font = new Font("Consolas", Math.Max(8F, 17F * Math.Min(sx, sy)), FontStyle.Regular, GraphicsUnit.Pixel))
            using (var brush = new SolidBrush(Color.FromArgb(221, 226, 234)))
            using (var format = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                graphics.DrawString(_clockText, font, brush, clock, format);
        }

        private RectangleF ScaleRect(RectangleF source, float sx, float sy)
        {
            return new RectangleF(_imageBounds.Left + source.Left * sx, _imageBounds.Top + source.Top * sy, source.Width * sx, source.Height * sy);
        }

        private void DrawControllerStatus(Graphics graphics)
        {
            if (_controllerCount < 0 || _imageBounds.Width <= 0) return;
            float sx = _imageBounds.Width / _interfaceImage.Width;
            float sy = _imageBounds.Height / _interfaceImage.Height;
            var source = new RectangleF(80, 585, 450, 46);
            var target = new RectangleF(_imageBounds.Left + source.Left * sx, _imageBounds.Top + source.Top * sy, source.Width * sx, source.Height * sy);
            using (var background = new SolidBrush(Color.FromArgb(255, 21, 28, 33))) graphics.FillRectangle(background, target);
            Color color = _controllerCount > 0 ? Color.FromArgb(121, 224, 166) : Color.FromArgb(190, 198, 205);
            string text = _controllerCount == 0 ? "○  No controller detected — keyboard remains available"
                : "●  " + _controllerCount + (_controllerCount == 1 ? " controller ready — auto-mapped" : " controllers ready — isolated mappings");
            float fontSize = Math.Max(7F, 13F * Math.Min(sx, sy));
            using (var font = new Font("Segoe UI", fontSize, FontStyle.Regular, GraphicsUnit.Pixel))
            using (var brush = new SolidBrush(color))
                graphics.DrawString(text, font, brush, target.Left + 3F * sx, target.Top + 5F * sy);
        }

        private void DrawMultiplayerButtons(Graphics graphics)
        {
            if (_imageBounds.Width <= 0) return;
            DrawMultiplayerButton(graphics, new RectangleF(1238, 254, 207, 48), "HOST MATCH", Color.FromArgb(171, 22, 34));
            DrawMultiplayerButton(graphics, new RectangleF(1452, 254, 180, 48), "JOIN MATCH", Color.FromArgb(0, 112, 74));
        }

        private void DrawMinimizeButtons(Graphics graphics)
        {
            if (_imageBounds.Width <= 0) return;
            DrawMultiplayerButton(graphics, new RectangleF(960, 872, 180, 42), "MINIMIZE APP", Color.FromArgb(35, 54, 67));
            DrawMultiplayerButton(graphics, new RectangleF(1150, 872, 200, 42), "MINIMIZE PCSX2", Color.FromArgb(35, 54, 67));
        }

        private void DrawMultiplayerButton(Graphics graphics, RectangleF source, string label, Color color)
        {
            float sx = _imageBounds.Width / _interfaceImage.Width;
            float sy = _imageBounds.Height / _interfaceImage.Height;
            var target = new RectangleF(_imageBounds.Left + source.Left * sx, _imageBounds.Top + source.Top * sy, source.Width * sx, source.Height * sy);
            using (var fill = new LinearGradientBrush(target, ControlPaint.Light(color, .08F), ControlPaint.Dark(color, .18F), LinearGradientMode.Vertical)) graphics.FillRectangle(fill, target);
            using (var border = new Pen(Color.FromArgb(185, 220, 229, 234), Math.Max(1F, sx))) graphics.DrawRectangle(border, target.X, target.Y, target.Width, target.Height);
            float fontSize = Math.Max(8F, 17F * Math.Min(sx, sy));
            using (var font = new Font("Segoe UI Semibold", fontSize, FontStyle.Bold, GraphicsUnit.Pixel))
            using (var brush = new SolidBrush(Color.White))
            using (var format = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                graphics.DrawString(label, font, brush, target, format);
        }

        private void DrawFeedback(Graphics graphics, int index, Color color, float thickness)
        {
            if (index < 0 || index >= _hotspots.Count || !_hotspots[index].Selectable || _imageBounds.Width <= 0) return;
            Rectangle source = _hotspots[index].Bounds;
            float sx = _imageBounds.Width / _interfaceImage.Width;
            float sy = _imageBounds.Height / _interfaceImage.Height;
            var target = new RectangleF(_imageBounds.Left + source.Left * sx, _imageBounds.Top + source.Top * sy, source.Width * sx, source.Height * sy);
            using (var pen = new Pen(Color.FromArgb(210, 236, 244, 249), thickness)) graphics.DrawRectangle(pen, target.X, target.Y, target.Width, target.Height);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            int index = HitTest(e.Location);
            if (_hoverIndex != index) { if (index >= 0 && _hotspots[index].Selectable) MenuAudio.PlayMove(); _hoverIndex = index; Invalidate(); }
            Cursor = index >= 0 ? Cursors.Hand : Cursors.Default;
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            Cursor = Cursors.Default;
            _hoverIndex = -1;
            _pressedIndex = -1;
            Invalidate();
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Button != MouseButtons.Left) return;
            Focus();
            _pressedIndex = HitTest(e.Location);
            Invalidate();
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            if (e.Button != MouseButtons.Left) return;
            int index = HitTest(e.Location);
            int pressed = _pressedIndex;
            _pressedIndex = -1;
            Invalidate();
            if (index < 0 || index != pressed) return;
            if (_hotspots[index].Selectable) _selectedIndex = index;
            if (_hotspots[index].Action != null) { if (_hotspots[index].Name == "BACK") MenuAudio.PlayBack(); else MenuAudio.PlayConfirm(); _hotspots[index].Action(); }
        }

        private int HitTest(Point clientPoint)
        {
            if (_imageBounds.Width <= 0 || !_imageBounds.Contains(clientPoint)) return -1;
            int x = (int)((clientPoint.X - _imageBounds.Left) * _interfaceImage.Width / _imageBounds.Width);
            int y = (int)((clientPoint.Y - _imageBounds.Top) * _interfaceImage.Height / _imageBounds.Height);
            for (int i = 0; i < _hotspots.Count; i++)
                if (_hotspots[i].Bounds.Contains(x, y)) return i;
            return -1;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) _interfaceImage.Dispose();
            base.Dispose(disposing);
        }
    }

    internal sealed class GradientPanel : Panel
    {
        public Color GradientStart { get; set; }
        public Color GradientEnd { get; set; }
        public Image BackgroundArtwork { get; set; }
        public GradientPanel() { DoubleBuffered = true; }
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            if (ClientSize.Width <= 0 || ClientSize.Height <= 0)
                return;
            e.Graphics.Clear(Color.FromArgb(7, 10, 14));
            if (BackgroundArtwork != null)
            {
                float imageRatio = (float)BackgroundArtwork.Width / BackgroundArtwork.Height;
                float panelRatio = (float)ClientSize.Width / Math.Max(1, ClientSize.Height);
                Rectangle destination;
                if (imageRatio > panelRatio)
                {
                    int width = (int)(ClientSize.Height * imageRatio);
                    destination = new Rectangle((ClientSize.Width - width) / 2, 0, width, ClientSize.Height);
                }
                else
                {
                    int height = (int)(ClientSize.Width / imageRatio);
                    destination = new Rectangle(0, (ClientSize.Height - height) / 2, ClientSize.Width, height);
                }
                e.Graphics.DrawImage(BackgroundArtwork, destination);
            }
            using (var brush = new LinearGradientBrush(ClientRectangle, GradientStart, GradientEnd, LinearGradientMode.Horizontal))
                e.Graphics.FillRectangle(brush, ClientRectangle);
        }
    }
}
