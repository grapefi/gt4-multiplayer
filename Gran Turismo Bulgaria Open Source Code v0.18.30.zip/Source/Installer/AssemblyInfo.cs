using System.Reflection;

[assembly: AssemblyTitle("Gran Turismo Bulgaria Open Source Setup")]
[assembly: AssemblyDescription("Online Beta open source installer")]
[assembly: AssemblyCompany("Gran Turismo Bulgaria contributors")]
[assembly: AssemblyProduct("Gran Turismo Bulgaria Online Beta")]
[assembly: AssemblyCopyright("Copyright 2026")]
[assembly: AssemblyVersion("0.18.30.0")]
[assembly: AssemblyFileVersion("0.18.30.0")]
