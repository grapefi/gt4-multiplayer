$ErrorActionPreference = 'Stop'
$compiler = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$output = Join-Path $PSScriptRoot 'Gran Turismo Bulgaria Setup.exe'
$manifest = Join-Path (Split-Path -Parent $PSScriptRoot) 'launcher\app.manifest'
& $compiler /nologo /target:winexe /platform:x64 /optimize+ ('/out:' + $output) ('/win32manifest:' + $manifest) /reference:System.dll /reference:System.Core.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll /reference:System.Security.dll (Join-Path $PSScriptRoot 'Setup.cs') (Join-Path $PSScriptRoot 'ReleaseSecurity.cs') (Join-Path $PSScriptRoot 'AssemblyInfo.cs')
if ($LASTEXITCODE -ne 0) { throw "Installer compiler failed with exit code $LASTEXITCODE" }
Write-Output $output
