using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;

namespace GranTurismoBulgariaInstaller
{
    internal static class Program
    {
        [STAThread]
        private static void Main(string[] args)
        {
            Version version = Environment.OSVersion.Version;
            if (Environment.OSVersion.Platform != PlatformID.Win32NT || !Environment.Is64BitOperatingSystem || version.Major < 10 || version.Build < 22000)
            {
                MessageBox.Show("This release requires 64 bit Windows 11 build 22000 or newer.", "Windows 11 required", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.ExitCode = 1;
                return;
            }
            string payload = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Payload");
            if (args.Length == 1 && args[0].Equals("--verify-only", StringComparison.OrdinalIgnoreCase))
            {
                try { ReleaseSecurity.VerifyDirectory(payload, null); Environment.ExitCode = 0; }
                catch (Exception ex) { WriteError("installer-verify-error.txt", ex); Environment.ExitCode = 1; }
                return;
            }
            if (args.Length == 1 && args[0].Equals("--ui-self-test", StringComparison.OrdinalIgnoreCase))
            {
                using (var form = new SetupForm()) Environment.ExitCode = form.HasAccessibleLayout ? 0 : 1;
                return;
            }
            if (args.Length == 4 && args[0].Equals("--self-test", StringComparison.OrdinalIgnoreCase))
            {
                try { InstallerCore.Install(payload, Path.GetFullPath(args[1]), Path.GetFullPath(args[2]), Path.GetFullPath(args[3]), null); Environment.ExitCode = 0; }
                catch (Exception ex) { WriteError("installer-self-test-error.txt", ex); Environment.ExitCode = 1; }
                return;
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new SetupForm());
        }

        private static void WriteError(string name, Exception ex)
        {
            try { File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, name), ex.ToString()); } catch { }
        }
    }

    internal sealed class SetupForm : Form
    {
        private readonly TextBox _destination = new TextBox();
        private readonly TextBox _iso = new TextBox();
        private readonly TextBox _bios = new TextBox();
        private readonly ProgressBar _progress = new ProgressBar();
        private readonly Label _status = new Label();
        private readonly Button _install = new Button();
        private readonly CheckBox _desktop = new CheckBox();
        private readonly string _payload = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Payload");
        internal bool HasAccessibleLayout { get { return ClientSize.Width >= 850 && ClientSize.Height >= 690 && _iso.Height >= 34 && _bios.Height >= 34 && _install.Width >= 200; } }

        public SetupForm()
        {
            Text = "Gran Turismo Bulgaria Online Beta Open Source Installer";
            ClientSize = new Size(980, 735);
            MinimumSize = new Size(870, 720);
            AutoScroll = true;
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.Sizable;
            MaximizeBox = true;
            BackColor = Color.FromArgb(9, 14, 20);
            ForeColor = Color.White;
            Font = new Font("Segoe UI", 12F);

            Controls.Add(new FlagPanel { Location = new Point(0, 0), Size = new Size(980, 11), Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right });
            Controls.Add(LabelAt("GRAN TURISMO BULGARIA", 30, FontStyle.Bold, Color.White, 36, 34));
            Controls.Add(LabelAt("OPEN SOURCE ONLINE BETA RELEASE", 11, FontStyle.Bold, Color.FromArgb(108, 210, 170), 40, 91));
            var copy = LabelAt("The app and online services are included. Your game image and PS2 BIOS are imported from your own files during installation.", 12, FontStyle.Regular, Color.FromArgb(202, 211, 219), 40, 130);
            copy.Size = new Size(885, 55); copy.AutoSize = false; Controls.Add(copy);

            AddPathRow("INSTALL LOCATION", _destination, 195, false);
            _destination.Text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "Gran Turismo Bulgaria Online Beta");
            AddPathRow("YOUR GRAN TURISMO 4 USA ONLINE BETA ISO", _iso, 295, true);
            AddPathRow("YOUR PS2 BIOS BIN FILE", _bios, 395, true);

            _desktop.Text = "Create a desktop shortcut"; _desktop.Checked = true; _desktop.AutoSize = true; _desktop.Location = new Point(40, 488); Controls.Add(_desktop);
            _progress.Location = new Point(40, 540); _progress.Size = new Size(895, 27); _progress.Style = ProgressBarStyle.Continuous; _progress.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; Controls.Add(_progress);
            _status.Text = "Ready to verify and install"; _status.AutoSize = false; _status.Size = new Size(890, 55); _status.Location = new Point(40, 580); _status.ForeColor = Color.FromArgb(181, 193, 202); Controls.Add(_status);
            _install.Text = "VERIFY AND INSTALL"; _install.Location = new Point(690, 651); _install.Size = new Size(245, 58); _install.Font = new Font("Segoe UI Semibold", 13F); _install.Anchor = AnchorStyles.Right | AnchorStyles.Bottom; _install.BackColor = Color.FromArgb(206, 17, 38); _install.ForeColor = Color.White; _install.FlatStyle = FlatStyle.Flat; _install.FlatAppearance.BorderSize = 0; _install.Click += async delegate { await InstallAsync(); }; Controls.Add(_install);
        }

        private void AddPathRow(string heading, TextBox box, int y, bool file)
        {
            Controls.Add(LabelAt(heading, 10, FontStyle.Bold, Color.FromArgb(225, 75, 90), 40, y));
            box.Location = new Point(40, y + 27); box.Size = new Size(745, 36); box.Font = new Font("Segoe UI", 11F); box.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right; Controls.Add(box);
            var browse = ButtonAt("BROWSE", 800, y + 24, 135, 42, Color.FromArgb(46, 56, 65)); browse.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            browse.Click += delegate
            {
                if (file)
                {
                    using (var dialog = new OpenFileDialog { Title = heading, Filter = heading.Contains("ISO") ? "Disc images (*.iso)|*.iso|All files (*.*)|*.*" : "PS2 BIOS (*.bin)|*.bin|All files (*.*)|*.*" })
                        if (dialog.ShowDialog(this) == DialogResult.OK) box.Text = dialog.FileName;
                }
                else
                {
                    using (var dialog = new FolderBrowserDialog { Description = "Choose the installation parent folder", SelectedPath = Path.GetDirectoryName(box.Text) })
                        if (dialog.ShowDialog(this) == DialogResult.OK) box.Text = Path.Combine(dialog.SelectedPath, "Gran Turismo Bulgaria Online Beta");
                }
            };
            Controls.Add(browse);
        }

        private async Task InstallAsync()
        {
            string destination, iso, bios;
            try { destination = Path.GetFullPath(_destination.Text.Trim()); iso = Path.GetFullPath(_iso.Text.Trim()); bios = Path.GetFullPath(_bios.Text.Trim()); }
            catch { MessageBox.Show("Choose valid installation, ISO and BIOS paths.", "Invalid path", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            _install.Enabled = false; SetInputs(false); _progress.Value = 0; _status.Text = "Checking the signed app and your selected files";
            try
            {
                string installedVersion = await Task.Run(() => InstallerCore.Install(_payload, destination, iso, bios, percent => BeginInvoke((Action)(() => { _progress.Value = percent; _status.Text = "Installing " + percent + "%"; }))));
                try { using (RegistryKey key = Registry.CurrentUser.CreateSubKey(@"Software\GranTurismoBulgaria")) { key.SetValue("InstallPath", destination); key.SetValue("Version", installedVersion); } } catch (UnauthorizedAccessException) { }
                string exe = Path.Combine(destination, "Gran Turismo Bulgaria.exe");
                Shortcut.Create(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Programs", "Gran Turismo Bulgaria Online Beta.lnk"), exe, destination);
                if (_desktop.Checked) Shortcut.Create(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "Gran Turismo Bulgaria Online Beta.lnk"), exe, destination);
                _progress.Value = 100; _status.Text = "Installation complete";
                if (MessageBox.Show("Installation is complete. Launch the app now?", "Installation complete", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes) Process.Start(new ProcessStartInfo(exe) { WorkingDirectory = destination, UseShellExecute = true });
                Close();
            }
            catch (Exception ex) { _status.Text = "Installation failed"; _install.Enabled = true; SetInputs(true); MessageBox.Show(ex.Message, "Installation failed", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void SetInputs(bool enabled) { _destination.Enabled = enabled; _iso.Enabled = enabled; _bios.Enabled = enabled; }
        private static Label LabelAt(string text, float size, FontStyle style, Color color, int x, int y) { return new Label { Text = text, Font = new Font("Segoe UI", size, style), ForeColor = color, BackColor = Color.Transparent, AutoSize = true, Location = new Point(x, y) }; }
        private static Button ButtonAt(string text, int x, int y, int w, int h, Color color) { var b = new Button { Text = text, Location = new Point(x, y), Size = new Size(w, h), FlatStyle = FlatStyle.Flat, BackColor = color, ForeColor = Color.White }; b.FlatAppearance.BorderSize = 0; return b; }
    }

    internal static class InstallerCore
    {
        private const long IsoLength = 2654109696L;
        private const string OriginalIsoHash = "1f49b9d8077801188860b62c3efdbc631ba8af7df979373811ce8c60dcc48ebe";
        private const string PatchedIsoHash = "675622dbb4a4036c03b51a3f8ac00cccdc1cf1a665586e625869dafd45f960bc";
        private static readonly long[] PatchOffsets = { 0x0039FB28, 0x0039FB29, 0x0039FB2A, 0x0039FB2B, 0x0039FB34, 0x003B54B8, 0x003B54B9, 0x003B54BA, 0x003B54BB, 0x003B54C4 };
        private static readonly byte[] PatchBytes = { 0x00, 0x00, 0x00, 0x00, 0x05, 0x00, 0x00, 0x00, 0x00, 0x05 };

        public static string Install(string payload, string destination, string iso, string bios, Action<int> progress)
        {
            if (!File.Exists(iso)) throw new FileNotFoundException("The selected Online Beta ISO was not found.");
            if (!File.Exists(bios)) throw new FileNotFoundException("The selected PS2 BIOS BIN file was not found.");
            if (new FileInfo(iso).Length != IsoLength) throw new InvalidDataException("The selected ISO is not the supported Gran Turismo 4 USA Online Beta image.");
            if (new FileInfo(bios).Length != 4L * 1024 * 1024) throw new InvalidDataException("The selected BIOS BIN is not the expected 4 MiB PS2 BIOS format.");
            string isoHash = ReleaseSecurity.HashFile(iso);
            if (!isoHash.Equals(OriginalIsoHash, StringComparison.OrdinalIgnoreCase) && !isoHash.Equals(PatchedIsoHash, StringComparison.OrdinalIgnoreCase)) throw new CryptographicException("The selected ISO does not match the supported original or prepared Online Beta image.");
            ReleaseInfo release = ReleaseSecurity.VerifyDirectory(payload, null);
            destination = Path.GetFullPath(destination).TrimEnd(Path.DirectorySeparatorChar);
            if (Directory.Exists(destination) && Directory.EnumerateFileSystemEntries(destination).Any()) throw new IOException("The selected installation folder is not empty.");
            string parent = Path.GetDirectoryName(destination); Directory.CreateDirectory(parent);
            string stage = Path.Combine(parent, ".gtb-public-install-" + Guid.NewGuid().ToString("N")); Directory.CreateDirectory(stage);
            try
            {
                CopySignedPayload(payload, stage, release, progress);
                string gameDir = Path.Combine(stage, "game"); Directory.CreateDirectory(gameDir);
                string targetIso = Path.Combine(gameDir, "Gran Turismo 4 (USA) (Online Public Beta).iso"); CopyFile(iso, targetIso);
                if (isoHash.Equals(OriginalIsoHash, StringComparison.OrdinalIgnoreCase)) ApplyPatch(targetIso);
                if (!ReleaseSecurity.HashFile(targetIso).Equals(PatchedIsoHash, StringComparison.OrdinalIgnoreCase)) throw new CryptographicException("The prepared Online Beta image failed its final integrity check.");
                string biosDir = Path.Combine(stage, "private", "bios"); Directory.CreateDirectory(biosDir);
                string biosBase = Path.Combine(biosDir, "ps2-bios"); CopyFile(bios, biosBase + ".bin");
                CopyCompanion(bios, ".nvm", biosBase + ".nvm"); CopyCompanion(bios, ".mec", biosBase + ".mec");
                Directory.CreateDirectory(Path.Combine(stage, "data")); Directory.CreateDirectory(Path.Combine(stage, "logs")); Directory.CreateDirectory(Path.Combine(stage, "support"));
                if (Directory.Exists(destination)) Directory.Delete(destination);
                Directory.Move(stage, destination);
                if (progress != null) progress(100);
                return release.Version;
            }
            catch { try { if (Directory.Exists(stage)) Directory.Delete(stage, true); } catch { } throw; }
        }

        private static void CopySignedPayload(string payload, string stage, ReleaseInfo release, Action<int> progress)
        {
            string[] metadata = { "release.manifest", "release.sig", "release.public.xml" };
            var files = release.Files.Select(f => f.RelativePath).Concat(metadata).ToArray(); long total = files.Sum(f => new FileInfo(ReleaseSecurity.SafeCombine(payload, f)).Length), copied = 0;
            foreach (string relative in files)
            {
                string source = ReleaseSecurity.SafeCombine(payload, relative), target = ReleaseSecurity.SafeCombine(stage, relative); Directory.CreateDirectory(Path.GetDirectoryName(target));
                using (var input = new FileStream(source, FileMode.Open, FileAccess.Read, FileShare.Read)) using (var output = new FileStream(target, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    byte[] buffer = new byte[4 * 1024 * 1024]; int read; while ((read = input.Read(buffer, 0, buffer.Length)) > 0) { output.Write(buffer, 0, read); copied += read; if (progress != null) progress(total == 0 ? 80 : (int)Math.Min(80, copied * 80L / total)); } output.Flush(true);
                }
            }
            ReleaseSecurity.VerifyDirectory(stage, null);
        }

        private static void ApplyPatch(string path)
        {
            using (var file = new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) for (int i = 0; i < PatchOffsets.Length; i++) { file.Position = PatchOffsets[i]; file.WriteByte(PatchBytes[i]); } 
        }
        private static void CopyCompanion(string bios, string extension, string target) { string source = Path.ChangeExtension(bios, extension); if (File.Exists(source)) CopyFile(source, target); }
        private static void CopyFile(string source, string target) { Directory.CreateDirectory(Path.GetDirectoryName(target)); using (var input = new FileStream(source, FileMode.Open, FileAccess.Read, FileShare.Read)) using (var output = new FileStream(target, FileMode.CreateNew, FileAccess.Write, FileShare.None)) { input.CopyTo(output, 4 * 1024 * 1024); output.Flush(true); } }
    }

    internal sealed class FlagPanel : Panel
    {
        protected override void OnPaint(PaintEventArgs e) { int third = Width / 3; e.Graphics.FillRectangle(Brushes.White, 0, 0, third, Height); using (var g = new SolidBrush(Color.FromArgb(0, 150, 110))) e.Graphics.FillRectangle(g, third, 0, third, Height); using (var r = new SolidBrush(Color.FromArgb(214, 38, 50))) e.Graphics.FillRectangle(r, third * 2, 0, Width - third * 2, Height); }
    }

    internal static class Shortcut
    {
        public static void Create(string path, string target, string workingDirectory) { Directory.CreateDirectory(Path.GetDirectoryName(path)); var link = (IShellLinkW)new ShellLink(); link.SetPath(target); link.SetWorkingDirectory(workingDirectory); link.SetDescription("Gran Turismo Bulgaria Online Beta"); link.SetIconLocation(target, 0); ((IPersistFile)link).Save(path, true); }
        [ComImport, Guid("00021401-0000-0000-C000-000000000046")] private class ShellLink { }
        [ComImport, InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("000214F9-0000-0000-C000-000000000046")] private interface IShellLinkW
        {
            void GetPath([Out, MarshalAs(UnmanagedType.LPWStr)] System.Text.StringBuilder path, int length, IntPtr data, uint flags); void GetIDList(out IntPtr list); void SetIDList(IntPtr list); void GetDescription([Out, MarshalAs(UnmanagedType.LPWStr)] System.Text.StringBuilder name, int length); void SetDescription([MarshalAs(UnmanagedType.LPWStr)] string name); void GetWorkingDirectory([Out, MarshalAs(UnmanagedType.LPWStr)] System.Text.StringBuilder directory, int length); void SetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] string directory); void GetArguments([Out, MarshalAs(UnmanagedType.LPWStr)] System.Text.StringBuilder args, int length); void SetArguments([MarshalAs(UnmanagedType.LPWStr)] string args); void GetHotkey(out short hotkey); void SetHotkey(short hotkey); void GetShowCmd(out int command); void SetShowCmd(int command); void GetIconLocation([Out, MarshalAs(UnmanagedType.LPWStr)] System.Text.StringBuilder path, int length, out int index); void SetIconLocation([MarshalAs(UnmanagedType.LPWStr)] string path, int index); void SetRelativePath([MarshalAs(UnmanagedType.LPWStr)] string path, uint reserved); void Resolve(IntPtr window, uint flags); void SetPath([MarshalAs(UnmanagedType.LPWStr)] string path);
        }
        [ComImport, InterfaceType(ComInterfaceType.InterfaceIsIUnknown), Guid("0000010b-0000-0000-C000-000000000046")] private interface IPersistFile { void GetClassID(out Guid id); [PreserveSig] int IsDirty(); void Load([MarshalAs(UnmanagedType.LPWStr)] string name, uint mode); void Save([MarshalAs(UnmanagedType.LPWStr)] string name, bool remember); void SaveCompleted([MarshalAs(UnmanagedType.LPWStr)] string name); void GetCurFile([MarshalAs(UnmanagedType.LPWStr)] out string name); }
    }
}
