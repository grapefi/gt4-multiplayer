using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace GranTurismoBulgariaInstaller
{
    internal sealed class ReleaseFile
    {
        public string RelativePath;
        public long Length;
        public string Hash;
    }

    internal sealed class ReleaseInfo
    {
        public string Version;
        public List<ReleaseFile> Files = new List<ReleaseFile>();
    }

    internal static class ReleaseSecurity
    {
        internal const string TrustedPublicKeySha256 = "bf95c8243a0a4fc955352445e584e917214919d775f342e59e3451a3565c6f0a";
        private static readonly UTF8Encoding Utf8 = new UTF8Encoding(false);

        public static ReleaseInfo VerifyDirectory(string root, Action<int> progress, bool rejectUnsignedExtras = true)
        {
            root = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar);
            RejectReparsePath(root);
            string manifestPath = Path.Combine(root, "release.manifest");
            string signaturePath = Path.Combine(root, "release.sig");
            string publicPath = Path.Combine(root, "release.public.xml");
            if (!File.Exists(manifestPath) || !File.Exists(signaturePath) || !File.Exists(publicPath)) throw new CryptographicException("The installer payload has no signed release manifest.");
            if (!Fixed(HashFile(publicPath), TrustedPublicKeySha256)) throw new CryptographicException("The release public key is not trusted by this installer.");
            byte[] manifest = File.ReadAllBytes(manifestPath); if (manifest.Length > 4 * 1024 * 1024) throw new InvalidDataException("Release manifest is too large.");
            byte[] signature;
            try { signature = Convert.FromBase64String(File.ReadAllText(signaturePath, Utf8).Trim()); } catch { throw new CryptographicException("Release signature encoding is invalid."); }
            using (var rsa = new RSACryptoServiceProvider())
            {
                rsa.PersistKeyInCsp = false; rsa.FromXmlString(File.ReadAllText(publicPath, Utf8));
                if (rsa.KeySize < 3072 || !rsa.VerifyData(manifest, CryptoConfig.MapNameToOID("SHA256"), signature)) throw new CryptographicException("The installer payload signature is invalid.");
            }
            ReleaseInfo info = ParseManifest(Utf8.GetString(manifest));
            long total = info.Files.Sum(f => f.Length), done = 0; var expected = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (ReleaseFile file in info.Files)
            {
                string path = SafeCombine(root, file.RelativePath); expected.Add(Path.GetFullPath(path));
                RejectReparsePath(path);
                var actual = new FileInfo(path); if (!actual.Exists || actual.Length != file.Length) throw new CryptographicException("Release file is missing or has the wrong size: " + file.RelativePath);
                if (!Fixed(HashFile(path), file.Hash)) throw new CryptographicException("Release file failed integrity verification: " + file.RelativePath);
                done += file.Length; if (progress != null) progress(total == 0 ? 100 : (int)Math.Min(100, done * 100L / total));
            }
            if (rejectUnsignedExtras)
            {
                var allowedMetadata = new HashSet<string>(new[] { Path.GetFullPath(manifestPath), Path.GetFullPath(signaturePath), Path.GetFullPath(publicPath) }, StringComparer.OrdinalIgnoreCase);
                foreach (string actual in Directory.GetFiles(root, "*", SearchOption.AllDirectories))
                    if (!expected.Contains(Path.GetFullPath(actual)) && !allowedMetadata.Contains(Path.GetFullPath(actual))) throw new CryptographicException("Unsigned extra file found in the installer payload: " + actual.Substring(root.Length).TrimStart('\\', '/'));
            }
            return info;
        }

        public static string SafeCombine(string root, string relative)
        {
            if (string.IsNullOrWhiteSpace(relative) || Path.IsPathRooted(relative) || relative.IndexOf(':') >= 0 || relative.Split('/', '\\').Any(p => p == ".." || p.Length == 0)) throw new InvalidDataException("Unsafe release path.");
            string basePath = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string result = Path.GetFullPath(Path.Combine(basePath, relative.Replace('/', Path.DirectorySeparatorChar)));
            if (!result.StartsWith(basePath, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("Release path leaves the selected folder.");
            return result;
        }

        private static ReleaseInfo ParseManifest(string text)
        {
            string[] lines = text.Replace("\r", "").Split('\n');
            if (lines.Length < 3 || lines[0] != "GTB-RELEASE-MANIFEST-V1" || !lines[1].StartsWith("Version\t", StringComparison.Ordinal)) throw new InvalidDataException("Release manifest header is invalid.");
            var result = new ReleaseInfo { Version = lines[1].Substring(8) };
            if (string.IsNullOrWhiteSpace(result.Version) || result.Version.Length > 80) throw new InvalidDataException("Release version is invalid.");
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 2; i < lines.Length; i++)
            {
                if (lines[i].Length == 0) continue;
                string[] fields = lines[i].Split('\t'); long length;
                if (fields.Length != 4 || fields[0] != "F" || !long.TryParse(fields[2], out length) || length < 0 || length > 16L * 1024 * 1024 * 1024 || !System.Text.RegularExpressions.Regex.IsMatch(fields[3], "^[a-f0-9]{64}$")) throw new InvalidDataException("Release manifest entry is invalid.");
                string relative;
                try { relative = Utf8.GetString(Convert.FromBase64String(fields[1])); } catch { throw new InvalidDataException("Release path encoding is invalid."); }
                SafeCombine(Path.GetTempPath(), relative);
                if (!seen.Add(relative)) throw new InvalidDataException("Release manifest has a duplicate path: " + relative);
                result.Files.Add(new ReleaseFile { RelativePath = relative, Length = length, Hash = fields[3] });
            }
            if (result.Files.Count == 0 || result.Files.Count > 100000) throw new InvalidDataException("Release manifest file count is invalid.");
            return result;
        }

        private static void RejectReparsePath(string path)
        {
            string current = Path.GetFullPath(path); var parts = new Stack<string>();
            while (!string.IsNullOrEmpty(current) && !Directory.Exists(current) && !File.Exists(current)) { parts.Push(Path.GetFileName(current)); current = Path.GetDirectoryName(current); }
            while (!string.IsNullOrEmpty(current))
            {
                if ((File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0) throw new IOException("Release path contains a reparse point: " + current);
                string parent = Path.GetDirectoryName(current); if (string.Equals(parent, current, StringComparison.OrdinalIgnoreCase)) break; current = parent;
            }
        }

        public static string HashFile(string path)
        {
            using (var input = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
            using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(input)).Replace("-", "").ToLowerInvariant();
        }
        private static bool Fixed(string a, string b) { if (a == null || b == null || a.Length != b.Length) return false; int d = 0; for (int i = 0; i < a.Length; i++) d |= a[i] ^ b[i]; return d == 0; }
    }
}
