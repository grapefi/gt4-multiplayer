using CustomLogger;
using Horizon.RT.Common;
using Horizon.RT.Models;

namespace Horizon.MUM.Models
{
    // GT4-only compatibility switches; never manufacture approval or bypass admission checks.
    public static class GtbRaceJoin
    {
        public static NetAddressList PeerAddresses(int appId, NetAddressList addresses)
        {
            // GT4's UDP implementation attempts internal first and returns an error
            // immediately for a local endpoint (004ac140 -> 004b2860). PCSX2's
            // sockets adapter presents the same non-routable guest IP on each PC.
            // Keep the observed external peer endpoint and omit only that synthetic
            // internal candidate. Never mutate the game's saved address list.
            if (appId != 10782 || Environment.GetEnvironmentVariable("GTB_PEER_ADDRESS") == "legacy"
                || addresses?.AddressList == null || addresses.AddressList.Length != 2) return addresses!;
            var external = addresses.AddressList[0];
            var internalAddress = addresses.AddressList[1];
            if (external == null || internalAddress == null
                || external.AddressType != NetAddressType.NetAddressTypeBinaryExternalVport
                || internalAddress.AddressType != NetAddressType.NetAddressTypeBinaryInternalVport
                || internalAddress.IPBinaryBitOne != 192 || internalAddress.IPBinaryBitTwo != 0
                || internalAddress.IPBinaryBitThree != 2 || internalAddress.IPBinaryBitFour != 100
                || external.BinaryPort == 0 || external.IPBinaryBitOne == 0
                || (external.IPBinaryBitOne == 192 && external.IPBinaryBitTwo == 0 && external.IPBinaryBitThree == 2)) return addresses;
            // Retain the binary record type/virtual port, but use a zero address and
            // zero port: the game's 004ac140 explicitly skips this absent candidate.
            var absent = new NetAddress { AddressType = internalAddress.AddressType,
                BinaryVportPortData = internalAddress.BinaryVportPortData };
            LoggerAccessor.LogInfo("[GTB Peer] omitted duplicate PCSX2 internal candidate; external endpoint and virtual port retained");
            return new NetAddressList { AddressList = new[] { external, absent } };
        }
        public static void LogPeerAddresses(int appId, int room, string direction, NetAddressList? addresses)
        {
            if (appId != 10782) return;
            var list = addresses?.AddressList;
            if (list == null) return;
            for (int i = 0; i < list.Length; i++)
            {
                var address = list[i];
                if (address == null) continue;
                bool emulated = address.IPBinaryBitOne == 192 && address.IPBinaryBitTwo == 0 && address.IPBinaryBitThree == 2;
                int addressBytes = address.BinaryVportAddressData?.Count(b => b != 0) ?? 0;
                int portBytes = address.BinaryVportPortData?.Count(b => b != 0) ?? 0;
                LoggerAccessor.LogInfo($"[GTB Peer] room={room} direction={direction} index={i} type={address.AddressType} port={address.BinaryPort} emulatorSubnet={emulated} opaqueAddressNonzero={addressBytes} opaquePortNonzero={portBytes} preserve={Environment.GetEnvironmentVariable("GTB_VPORT_RECORD") != "legacy"}");
            }
        }
        public static bool ChannelMatches(Channel channel, ulong a, ulong b, ulong c, ulong d, MediusLobbyFilterMaskLevelType level)
        {
            bool legacy = channel.ApplicationId != 10782 || Environment.GetEnvironmentVariable("GTB_CHANNEL_FILTER") == "legacy";
            if (legacy) return channel.GenericField1 == a && channel.GenericField2 == b && channel.GenericField3 == c && channel.GenericField4 == d && channel.GenericFieldLevel == (MediusWorldGenericFieldLevelType)level;
            int fields = level switch
            {
                MediusLobbyFilterMaskLevelType.MediusLobbyFilterMaskLevel0 => 0,
                MediusLobbyFilterMaskLevelType.MediusLobbyFilterMaskLevel1 => 1,
                MediusLobbyFilterMaskLevelType.MediusLobbyFilterMaskLevel2 => 2,
                MediusLobbyFilterMaskLevelType.MediusLobbyFilterMaskLevel3 => 4,
                MediusLobbyFilterMaskLevelType.MediusLobbyFilterMaskLevel4 => 8,
                MediusLobbyFilterMaskLevelType.MediusLobbyFilterMaskLevel12 => 3,
                MediusLobbyFilterMaskLevelType.MediusLobbyFilterMaskLevel123 => 7,
                MediusLobbyFilterMaskLevelType.MediusLobbyFilterMaskLevel1234 => 15,
                MediusLobbyFilterMaskLevelType.MediusLobbyFilterMaskLevel23 => 6,
                MediusLobbyFilterMaskLevelType.MediusLobbyFilterMaskLevel234 => 14,
                MediusLobbyFilterMaskLevelType.MediusLobbyFilterMaskLevel34 => 12,
                _ => -1
            };
            bool match = fields >= 0 && ((fields & 1) == 0 || a == 0 || (channel.GenericField1 & a) != 0)
                && ((fields & 2) == 0 || b == 0 || (channel.GenericField2 & b) != 0)
                && ((fields & 4) == 0 || c == 0 || (channel.GenericField3 & c) != 0)
                && ((fields & 8) == 0 || d == 0 || (channel.GenericField4 & d) != 0);
            LoggerAccessor.LogInfo($"[GTB Channels] candidate={channel.Id} fields={channel.GenericField1}/{channel.GenericField2}/{channel.GenericField3}/{channel.GenericField4} level={channel.GenericFieldLevel} matches={match}");
            return match;
        }

        public static NetConnectionInfo BinaryConnection(Game game, ClientObject guest, MediusServerJoinGameResponse approval)
        {
            LogPeerAddresses(game.ApplicationId, game.MediusWorldId, "host-to-guest", game.netAddressList);
            bool corrected = game.ApplicationId == 10782 && !string.IsNullOrEmpty(approval.AccessKey) && Environment.GetEnvironmentVariable("GTB_RACE_CREDENTIALS") != "legacy";
            if (game.ApplicationId == 10782)
                LoggerAccessor.LogInfo($"[GTB Race] connection room={game.MediusWorldId} approvedKeyPresent={!string.IsNullOrEmpty(approval.AccessKey)} approvedKeyMatchesLobby={approval.AccessKey == guest.AccessToken} credentials={(corrected ? "host-approval" : "legacy-lobby")} externalPort={game.netAddressList?.AddressList?[0].BinaryPort} internalPort={game.netAddressList?.AddressList?[1].BinaryPort}");
            return new NetConnectionInfo
            {
                AccessKey = corrected ? approval.AccessKey : guest.AccessToken,
                SessionKey = guest.SessionKey,
                TargetWorldID = game.MediusWorldId,
                ServerKey = corrected ? approval.pubKey : game.pubKey,
                AddressList = PeerAddresses(game.ApplicationId, game.netAddressList!),
                Type = NetConnectionType.NetConnectionTypePeerToPeerUDP
            };
        }

        public static MediusWorldStatus ListedStatus(Game game)
        {
            // Diagnostic presentation only: do not change the running world's state.
            bool staging = game.ApplicationId == 10782
                && Environment.GetEnvironmentVariable("GTB_RACE_LIST") == "staging"
                && game.WorldStatus == MediusWorldStatus.WorldActive;
            if (game.ApplicationId == 10782)
                LoggerAccessor.LogInfo($"[GTB Race] listing room={game.MediusWorldId} actual={game.WorldStatus} shown={(staging ? MediusWorldStatus.WorldStaging : game.WorldStatus)} players={game.PlayerCount} minimum={game.MinPlayers} maximum={game.MaxPlayers}");
            return staging ? MediusWorldStatus.WorldStaging : game.WorldStatus;
        }

        public static ClientObject? Target(Game game)
        {
            if (game.ApplicationId != 10782) return game.Host;
            bool legacy = Environment.GetEnvironmentVariable("GTB_RACE_ROUTE") == "legacy";
            var target = legacy ? game.Host : game.DMEServer ?? game.Host;
            LoggerAccessor.LogInfo($"[GTB Race] route room={game.MediusWorldId} type={game.GameHostType} route={(ReferenceEquals(target, game.DMEServer) ? "server" : "lobby")} sameConnection={ReferenceEquals(game.Host, game.DMEServer)} available={target != null}");
            return target;
        }

        public static bool TrackApproval(Game game, ClientObject client, bool approved)
        {
            return approved && game.ApplicationId == 10782 && client.ApplicationId == 10782
                && game.GameHostType == MGCL_GAME_HOST_TYPE.MGCLGameHostPeerToPeer
                && Environment.GetEnvironmentVariable("GTB_RACE_MEMBERSHIP") != "legacy"
                && client.CurrentGame != game;
        }
    }
}
