namespace Horizon.MUM.Models
{
    // Only GT4 USA Online Beta: never relax authentication or race filters.
    public static class GtbLobbyPolicy
    {
        public static bool MeetsListingPopulation(int appId, bool staging, int players, int minimum)
        {
            string mode = System.Environment.GetEnvironmentVariable("GTB_LOBBY_COMPAT") ?? "active-rooms";
            return appId == 10782 && mode != "strict" && (staging || mode != "staging-only") ? players > 0 : players >= minimum;
        }

        public static bool ShouldUsePlayerReportTimeout(int appId, bool inGame, bool inParty)
        {
            return appId != 10782 || inGame || inParty;
        }
    }
}
