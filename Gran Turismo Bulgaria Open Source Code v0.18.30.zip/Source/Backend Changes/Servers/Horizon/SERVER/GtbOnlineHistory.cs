using CustomLogger;
using Newtonsoft.Json;
using System.Collections.Concurrent;
using System.Text;

namespace Horizon.SERVER
{
    /// <summary>
    /// Small host-local persistence layer for GT4 Online Beta.  It deliberately
    /// sits beside (rather than replacing) the Medius database so the proven
    /// login/race path remains unchanged when the server is in simulated mode.
    /// </summary>
    public static class GtbOnlineHistory
    {
        private sealed class Store
        {
            public int Version { get; set; } = 1;
            public Dictionary<int, PlayerRecord> Players { get; set; } = new();
            public RaceRecord? LastRace { get; set; }
        }

        public sealed class PlayerRecord
        {
            public int AccountId { get; set; }
            public string Name { get; set; } = string.Empty;
            public int[] WideStats { get; set; } = Array.Empty<int>();
            public DateTime UpdatedUtc { get; set; }
        }

        public sealed class RaceResult
        {
            public int AccountId { get; set; }
            public string Name { get; set; } = string.Empty;
            public int Rank { get; set; }
            public long ElapsedMilliseconds { get; set; }
        }

        public sealed class RaceRecord
        {
            public int WorldId { get; set; }
            public string Mode { get; set; } = string.Empty;
            public int Course { get; set; }
            public DateTime StartedUtc { get; set; }
            public DateTime UpdatedUtc { get; set; }
            public List<RaceResult> Results { get; set; } = new();
        }

        private static readonly object Sync = new();
        private static readonly ConcurrentDictionary<int, RaceRecord> ActiveRaces = new();
        private static Store? _store;
        private static string StorePath => Path.Combine(AppContext.BaseDirectory, "static", "gtb-online-history.json");

        private static Store Current
        {
            get
            {
                lock (Sync)
                {
                    if (_store != null) return _store;
                    try
                    {
                        if (File.Exists(StorePath))
                            _store = JsonConvert.DeserializeObject<Store>(File.ReadAllText(StorePath));
                    }
                    catch (Exception ex)
                    {
                        SafeLogWarn($"[GTB History] Could not read history; starting clean: {ex.Message}");
                    }
                    return _store ??= new Store();
                }
            }
        }

        private static void Save()
        {
            lock (Sync)
            {
                string? directory = Path.GetDirectoryName(StorePath);
                if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);
                string temporary = StorePath + ".tmp";
                File.WriteAllText(temporary, JsonConvert.SerializeObject(Current, Formatting.Indented), new UTF8Encoding(false));
                File.Move(temporary, StorePath, true);
            }
        }

        public static void RecordWideStats(int accountId, string? accountName, int[]? stats)
        {
            if (accountId <= 0 || stats == null) return;
            lock (Sync)
            {
                Current.Players[accountId] = new PlayerRecord
                {
                    AccountId = accountId,
                    Name = accountName ?? string.Empty,
                    WideStats = stats.ToArray(),
                    UpdatedUtc = DateTime.UtcNow
                };
                Save();
            }
            SafeLogInfo($"[GTB Leaderboard] Persisted {stats.Length} stats for {accountName ?? accountId.ToString()}.");
        }

        public static bool TryGetWideStats(int accountId, out int[] stats)
        {
            lock (Sync)
            {
                if (Current.Players.TryGetValue(accountId, out PlayerRecord? player))
                {
                    stats = player.WideStats.ToArray();
                    return true;
                }
            }
            stats = Array.Empty<int>();
            return false;
        }

        public static IReadOnlyList<PlayerRecord> GetLeaderboard(int zeroBasedStatIndex, int start, int count)
        {
            lock (Sync)
            {
                // GT4 time values use lower-is-better.  Zero means no submitted time.
                return Current.Players.Values
                    .Where(x => zeroBasedStatIndex >= 0 && zeroBasedStatIndex < x.WideStats.Length && x.WideStats[zeroBasedStatIndex] > 0)
                    .OrderBy(x => x.WideStats[zeroBasedStatIndex])
                    .ThenBy(x => x.UpdatedUtc)
                    .Skip(Math.Max(0, start))
                    .Take(Math.Clamp(count, 1, 100))
                    .Select(x => new PlayerRecord
                    {
                        AccountId = x.AccountId,
                        Name = x.Name,
                        WideStats = x.WideStats.ToArray(),
                        UpdatedUtc = x.UpdatedUtc
                    }).ToArray();
            }
        }

        public static void ObserveDebugMessage(string? message)
        {
            if (string.IsNullOrWhiteSpace(message)) return;
            int separator = message.IndexOf('?');
            string kind = separator < 0 ? message : message[..separator];
            Dictionary<string, string> values = ParseQuery(separator < 0 ? string.Empty : message[(separator + 1)..]);
            if (!TryInt(values, "WID", out int worldId) || worldId <= 0) return;

            if (kind.Equals("RACEBEGIN", StringComparison.OrdinalIgnoreCase))
            {
                RaceRecord race = ActiveRaces.GetOrAdd(worldId, _ => new RaceRecord
                {
                    WorldId = worldId,
                    Mode = values.GetValueOrDefault("mode", "RACE"),
                    Course = TryInt(values, "course", out int course) ? course : 0,
                    StartedUtc = DateTime.UtcNow,
                    UpdatedUtc = DateTime.UtcNow
                });
                lock (race) race.UpdatedUtc = DateTime.UtcNow;
                return;
            }

            if (!kind.Equals("RACEEND", StringComparison.OrdinalIgnoreCase)) return;
            RaceRecord completed = ActiveRaces.GetOrAdd(worldId, _ => new RaceRecord
            {
                WorldId = worldId,
                Mode = "RACE",
                StartedUtc = DateTime.UtcNow,
                UpdatedUtc = DateTime.UtcNow
            });
            TryInt(values, "uid", out int accountId);
            TryInt(values, "rank", out int rank);
            TryInt(values, "players", out int expectedPlayers);
            bool isComplete;
            lock (Sync)
            {
                completed.Results.RemoveAll(x => x.AccountId == accountId && accountId > 0);
                completed.Results.Add(new RaceResult
                {
                    AccountId = accountId,
                    Name = values.GetValueOrDefault("name", accountId.ToString()),
                    Rank = rank,
                    // GT4 does not include an official finish time in RACEEND.  Keep a
                    // clearly labelled elapsed session time for the news page instead.
                    ElapsedMilliseconds = Math.Max(0, (long)(DateTime.UtcNow - completed.StartedUtc).TotalMilliseconds)
                });
                completed.UpdatedUtc = DateTime.UtcNow;
                completed.Results = completed.Results.OrderBy(x => x.Rank <= 0 ? int.MaxValue : x.Rank).ToList();
                Current.LastRace = completed;
                Save();
                isComplete = expectedPlayers > 0 && completed.Results.Count >= expectedPlayers;
            }
            if (isComplete) ActiveRaces.TryRemove(worldId, out _);
            SafeLogInfo($"[GTB History] Saved race result world={worldId} player={values.GetValueOrDefault("name", "unknown")} rank={rank}.");
        }

        public static string GetNews()
        {
            lock (Sync)
            {
                RaceRecord? race = Current.LastRace;
                if (race == null || race.Results.Count == 0)
                    return "GRAN TURISMO 4 ONLINE\nWelcome drivers. Race together, set new records, and make Bulgarian motorsport history.";

                RaceResult winner = race.Results.OrderBy(x => x.Rank <= 0 ? int.MaxValue : x.Rank).First();
                string results = string.Join("  ", race.Results.OrderBy(x => x.Rank).Take(10).Select(x =>
                    $"{x.Rank}. {x.Name} {FormatElapsed(x.ElapsedMilliseconds)}"));
                return $"GRAN TURISMO 4 ONLINE\nLAST RACE: {winner.Name} wins!  Course {race.Course} / {race.Mode}\nRESULTS (elapsed): {results}";
            }
        }

        private static string FormatElapsed(long milliseconds)
        {
            TimeSpan time = TimeSpan.FromMilliseconds(milliseconds);
            return $"{(int)time.TotalMinutes}:{time.Seconds:00}.{time.Milliseconds:000}";
        }

        private static Dictionary<string, string> ParseQuery(string query)
        {
            Dictionary<string, string> result = new(StringComparer.OrdinalIgnoreCase);
            foreach (string part in query.Split('&', StringSplitOptions.RemoveEmptyEntries))
            {
                int equals = part.IndexOf('=');
                if (equals > 0)
                    result[Uri.UnescapeDataString(part[..equals])] = Uri.UnescapeDataString(part[(equals + 1)..]);
                else
                    result[part] = string.Empty;
            }
            return result;
        }

        private static bool TryInt(Dictionary<string, string> values, string key, out int value)
        {
            value = 0;
            return values.TryGetValue(key, out string? text) && int.TryParse(text, out value);
        }

        private static void SafeLogInfo(string message)
        {
            try { LoggerAccessor.LogInfo(message); }
            catch { /* Persistence must not depend on logger start-up order. */ }
        }

        private static void SafeLogWarn(string message)
        {
            try { LoggerAccessor.LogWarn(message); }
            catch { /* Persistence must not depend on logger start-up order. */ }
        }
    }
}
