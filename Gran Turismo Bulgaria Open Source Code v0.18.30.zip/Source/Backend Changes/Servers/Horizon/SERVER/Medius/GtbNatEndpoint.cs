using System;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using CustomLogger;

namespace Horizon.SERVER.Medius
{
    internal static class GtbNatEndpoint
    {
        // Preserve literal addresses: reverse DNS can replace a selected VPN IP
        // with an unrelated interface or IPv6 address, neither usable by GT4.
        internal static IPHostEntry Resolve(string configured)
        {
            string bind = Environment.GetEnvironmentVariable("GTB_BIND_IP");
            string method;
            IPAddress address = Select(configured, bind, Dns.GetHostAddresses, out method);
            LoggerAccessor.LogInfo($"[GTB NAT] Address selection: {method}; IPv4={address}. Waiting for UDP request on the configured NAT port.");
            return new IPHostEntry { HostName = address.ToString(), AddressList = new[] { address }, Aliases = Array.Empty<string>() };
        }

        internal static IPAddress Select(string configured, string bind, Func<string, IPAddress[]> lookup, out string method)
        {
            IPAddress address;
            if (IPAddress.TryParse(configured, out address) && address.AddressFamily == AddressFamily.InterNetwork)
            { method = "1/3 configured IPv4"; return address; }

            // Only hostnames use DNS. An IPv6 literal must never be truncated into
            // the legacy protocol's 16-byte IPv4 string field.
            if (!string.IsNullOrWhiteSpace(configured) && Uri.CheckHostName(configured) == UriHostNameType.Dns)
            {
                try
                {
                    address = lookup(configured).FirstOrDefault(x => x.AddressFamily == AddressFamily.InterNetwork);
                    if (address != null) { method = "2/3 DNS IPv4"; return address; }
                }
                catch (SocketException) { }
            }
            if (IPAddress.TryParse(bind, out address) && address.AddressFamily == AddressFamily.InterNetwork && IsPrivate(address))
            { method = "3/3 private server listening address"; return address; }
            throw new InvalidOperationException("No usable IPv4 NAT service address. Check the selected private connection before launching GT4.");
        }

        private static bool IsPrivate(IPAddress address)
        {
            byte[] b = address.GetAddressBytes();
            return b[0] == 10 || (b[0] == 172 && b[1] >= 16 && b[1] <= 31) || (b[0] == 192 && b[1] == 168);
        }
    }
}
