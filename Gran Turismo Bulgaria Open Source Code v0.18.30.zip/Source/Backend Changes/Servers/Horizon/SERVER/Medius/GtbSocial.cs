using CustomLogger;
using Horizon.MUM.Models;
using Horizon.LIBRARY.Database.Models;
using System.Threading;

namespace Horizon.SERVER.Medius
{
    public static class GtbSocial
    {
        private static readonly SemaphoreSlim Gate = new(1, 1);
        public static bool Enabled(ClientObject c) => c.ApplicationId == 10782 && Environment.GetEnvironmentVariable("GTB_SOCIAL_COMPAT") != "legacy";

        public static async Task<bool> Link(ClientObject source, int targetId)
        {
            if (!Enabled(source) || !source.IsLoggedIn || targetId <= 0 || targetId == source.AccountId) return false;
            await Gate.WaitAsync();
            try
            {
                var first = await HorizonServerConfiguration.Database.GetAccountById(source.AccountId);
                var second = await HorizonServerConfiguration.Database.GetAccountById(targetId);
                if (first?.AppId != 10782 || second?.AppId != 10782) return false;
                // Idempotent repair: never append an existing relation or overwrite a list.
                bool left = first.Friends?.Any(f => f.AccountId == targetId) == true ||
                    await HorizonServerConfiguration.Database.AddBuddy(new BuddyDTO { AccountId = source.AccountId, BuddyAccountId = targetId });
                bool right = second.Friends?.Any(f => f.AccountId == source.AccountId) == true ||
                    await HorizonServerConfiguration.Database.AddBuddy(new BuddyDTO { AccountId = targetId, BuddyAccountId = source.AccountId });
                await source.RefreshAccount();
                var peer = MediusClass.Manager.GetClientByAccountId(targetId, 10782);
                if (peer != null) await peer.RefreshAccount();
                if (!left || !right) LoggerAccessor.LogWarn($"[GTB Social] Mutual link incomplete source={source.AccountId} target={targetId}; retry on next friend-list refresh.");
                return left && right;
            }
            catch (Exception ex)
            {
                LoggerAccessor.LogWarn($"[GTB Social] Link failed safely: {ex.GetType().Name}; no logout requested.");
                return false;
            }
            finally { Gate.Release(); }
        }

        public static async Task Sync(ClientObject source)
        {
            if (!Enabled(source) || !source.IsLoggedIn || Environment.GetEnvironmentVariable("GTB_AUTO_FRIENDS") == "off") return;
            var peers = MediusClass.Manager.GetClients(10782).Where(p => p.ApplicationId == 10782 && p.AccountId > 0 && p.AccountId != source.AccountId && p.IsLoggedIn).Select(p => p.AccountId).Distinct().Take(64).ToArray();
            foreach (var peer in peers) await Link(source, peer);
            LoggerAccessor.LogInfo($"[GTB Social] Mutual friends synced account={source.AccountId} authenticatedPeers={peers.Length} friends={source.FriendsList?.Count ?? 0}");
        }
    }
}
