﻿/*
===========================================================================
Copyright (C) 2019-2026 Project Crystal Dev Team

This file is part of Project Crystal Server.

Project Crystal Server is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Project Crystal Server is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with Project Crystal Server. If not, see <https://www.gnu.org/licenses/>.
===========================================================================

Special thanks to Luke Usher (Insignia) for research help.
Special thanks to l_oliveira for PS2 technical advice.
Special thanks to Pancakes (Dricaster) for key/certificate.

===========================================================================
*/

namespace Crystal.DNAS1Server.DNAS1
{
    public class PacketHeader
    {
        public readonly ushort Flags;
        public readonly ushort Opcode;
        public readonly byte[] Security;
        public readonly uint DataSize;

        public const int SIZE = 0x28;
        public PacketHeader(ushort flags, ushort opcode, byte[] security, uint dataSize)
        {
            Flags = flags;
            Opcode = opcode;
            Security = security;
            DataSize = dataSize;
        }

        public byte[] GetBytes()
        {
            byte[] result = new byte[SIZE];

            using (MemoryStream mstream = new(result))
            using (BinaryWriter writer = new(mstream))
            {
                writer.Write(Flags);
                writer.Write(Utils.SwapEndian(Opcode));
                writer.Write(Security);
                writer.Write(Utils.SwapEndian(DataSize));
            }

            return result;
        }

        public static PacketHeader? Parse(byte[] pkt)
        {
            try
            {
                using (MemoryStream mstream = new(pkt))
                using (BinaryReader reader = new(mstream))
                {
                    ushort flags = reader.ReadUInt16();
                    ushort opcode = Utils.SwapEndian(reader.ReadUInt16());
                    byte[] security = reader.ReadBytes(0x20);
                    uint dataSize = Utils.SwapEndian(reader.ReadUInt32());

                    return new PacketHeader(flags, opcode, security, dataSize);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        public byte[] GetPacket(byte[] data)
        {
            byte[] pkt = new byte[0x28 + data.Length];
            GetBytes().AsSpan().CopyTo(pkt);
            data.AsSpan().CopyTo(pkt.AsSpan()[0x28..]);
            return pkt;
        }
    }
}
