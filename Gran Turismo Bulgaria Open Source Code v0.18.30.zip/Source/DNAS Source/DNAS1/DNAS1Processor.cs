/*
===========================================================================
Copyright (C) 2019-2026 Project Crystal Dev Team

This file is part of Project Crystal Server.

Project Crystal Server is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Project Crystal Server is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with Project Crystal Server. If not, see <https://www.gnu.org/licenses/>.
===========================================================================

Special thanks to Luke Usher (Insignia) for research help.
Special thanks to l_oliveira for PS2 technical advice.
Special thanks to Pancakes (Dricaster) for key/certificate.

===========================================================================
*/

using Crystal.DNAS1Server.DNAS1.Receive;
using Crystal.DNAS1Server.DNAS1.Send;

namespace Crystal.DNAS1Server.DNAS1
{
    public class DNAS1Processor()
    {
        public bool Process(byte[] requestPacket, out byte[]? responsePacket)
        {
            // Verify packet sizes and get the header
            responsePacket = null;
            string queryType = requestPacket.Length >= 4
                ? Convert.ToHexString(requestPacket.AsSpan(0, 4))
                : "unavailable";
            string packetGameId = requestPacket.Length >= 0x34
                ? Convert.ToHexString(requestPacket.AsSpan(0x2C, 8))
                : "unavailable";
            Console.WriteLine($"DNAS1 request fingerprint: bytes={requestPacket.Length}, query={queryType}, game-field={packetGameId}");
            if (requestPacket.Length < PacketHeader.SIZE)
            {
                Console.WriteLine("DNAS1 rejected: packet is shorter than its header.");
                return false;
            }

            PacketHeader? header = PacketHeader.Parse(requestPacket);
            if (header == null || PacketHeader.SIZE + header.DataSize != requestPacket.Length)
            {
                Console.WriteLine("DNAS1 rejected: declared packet size does not match received bytes.");
                return false;
            }

            Console.WriteLine($"DNAS1 header: flags=0x{header.Flags:X4}, opcode=0x{header.Opcode:X4}, data-bytes={header.DataSize}");

            // Process packet
            byte[] data = requestPacket[PacketHeader.SIZE..];
            switch (header.Opcode & 0xFF)
            {
                case 0:
                    {
                        InitializeRequest? request = InitializeRequest.Read(data);
                        if (request != null)
                        {
                            string safeGameId = new string(request.GameId.Where(c => c >= 0x20 && c <= 0x7E).ToArray());
                            Console.WriteLine($"DNAS1 initialize request: game={safeGameId}, activated={request.IsActivated}");
                            bool isHddActivated = (header.Flags & 0x8000) != 0;
                            byte[] responseData;
                            if (isHddActivated)
                                responseData = new InitializeResponse(new byte[25], 0).GetBytes();
                            else
                                responseData = new InitializeResponse(new byte[25]).GetBytes();
                            responsePacket = new PacketHeader(header.Flags, (ushort)((header.Opcode & 0xFF00) | InitializeResponse.OPCODE), header.Security, (uint)responseData.Length).GetPacket(responseData);
                            Console.WriteLine($"DNAS1 initialize response prepared: bytes={responsePacket.Length}");
                            return true;
                        }
                        break;
                    }
                case 1:
                    {
                        SetHddActivationSecretRequest? request = SetHddActivationSecretRequest.Read(data);
                        byte[] responseData = new SetHddActivationSecretResponse(new byte[6]).GetBytes();
                        responsePacket = new PacketHeader(header.Flags, (ushort)((header.Opcode & 0xFF00) | SetHddActivationSecretResponse.OPCODE), header.Security, (uint)responseData.Length).GetPacket(responseData);
                        Console.WriteLine($"DNAS1 HDD activate request");
                        break;
                    }
                case 2:
                    {
                        InstallRequest? request = InstallRequest.Read(data);
                        byte[] responseData = new InstallResponse(0).GetBytes();
                        responsePacket = new PacketHeader(header.Flags, (ushort)((header.Opcode & 0xFF00) | InstallResponse.OPCODE), header.Security, (uint)responseData.Length).GetPacket(responseData);
                        Console.WriteLine($"DNAS1 install request");
                        break;
                    }
                case 3:
                    // Haven't seen this in the wild
                    break;
                case 8:
                    // Haven't seen this in the wild
                    break;
                default:
                    return false;
            }

            return true;
        }
    }
}
