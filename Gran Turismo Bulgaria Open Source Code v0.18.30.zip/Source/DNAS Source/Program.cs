﻿/*
===========================================================================
Copyright (C) 2019-2026 Project Crystal Dev Team

This file is part of Project Crystal Server.

Project Crystal Server is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Project Crystal Server is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with Project Crystal Server. If not, see <https://www.gnu.org/licenses/>.
===========================================================================

Special thanks to Luke Usher (Insignia) for research help.
Special thanks to l_oliveira for PS2 technical advice.
Special thanks to Pancakes (Dricaster) for key/certificate.

===========================================================================
*/

namespace Crystal.DNAS1Server
{
    using System;
    using System.IO;
    using System.Net;
    using System.Net.Sockets;
    using System.Runtime.InteropServices;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using DNAS1Server.DNAS1;
    using DNAS1Server.Tls;
    using Org.BouncyCastle.Tls;

    class DnasTcpServer
    {
        private const string DefaultRegion = "us";
        private const int Timeout = 10000;
        private const int MaxHeaderBytes = 8 * 1024;
        private const int MaxBodyBytes = 64 * 1024;

        private static DNAS1Processor Dnas1 = new();
        private static readonly LegacyTlsCrypto Crypto = new();
        private static ServerCredentials? Credentials;
        private static string Region = DefaultRegion;

        public static async Task<int> Main()
        {
            // Get region we are serving
            Region = (Environment.GetEnvironmentVariable("DNAS_REGION") ?? DefaultRegion).ToLowerInvariant();
            if (!Region.Equals("us") && !Region.Equals("jp"))
            {
                Console.Error.WriteLine("Invalid region selected");
                return 1;
            }

            // Get the IP we listen on (all interfaces unless set)
            IPAddress bindIp = IPAddress.Any;
            string? bindIpSetting = Environment.GetEnvironmentVariable("DNAS_BIND_IP");
            if (!string.IsNullOrEmpty(bindIpSetting) && !IPAddress.TryParse(bindIpSetting, out bindIp!))
            {
                Console.Error.WriteLine("Invalid bind IP selected");
                return 1;
            }

            // The certificate chain and key live in keys/ next to the executable.
            string certFile = Path.Combine(AppContext.BaseDirectory, "keys", $"dnas1.{Region}.chain.crt");
            string keyFile = Path.Combine(AppContext.BaseDirectory, "keys", $"dnas1.{Region}.key");
            Credentials = ServerCredentials.Read(Crypto, certFile, keyFile);
            if (Credentials == null)
            {
                Console.Error.WriteLine("Could not load credentials:");
                Console.Error.WriteLine($"  certificate: {certFile}");
                Console.Error.WriteLine($"  private key: {keyFile}");
                return 1;
            }

            if (Environment.GetEnvironmentVariable("DNAS_SELF_TEST_SSLV2") == "1")
                return RunSsl2CompatibilitySelfTest();

            // Stop on SIGTERM (systemd) or Ctrl+C
            using CancellationTokenSource shutdown = new();
            using PosixSignalRegistration sigterm = PosixSignalRegistration.Create(PosixSignal.SIGTERM, ctx =>
            {
                ctx.Cancel = true;
                shutdown.Cancel();
            });
            Console.CancelKeyPress += (_, e) =>
            {
                e.Cancel = true;
                shutdown.Cancel();
            };

            int port = 443;
            string? portSetting = Environment.GetEnvironmentVariable("DNAS_PORT");
            if (!string.IsNullOrWhiteSpace(portSetting) && (!int.TryParse(portSetting, out port) || port < 1 || port > 65535))
            {
                Console.Error.WriteLine("Invalid DNAS port selected");
                return 1;
            }
            TcpListener server = new TcpListener(bindIp, port);
            server.Start();

            Console.WriteLine($"DNAS1 started (Region:{Region.ToUpper()}, IP:{bindIp}, Port:{port})...");

            try
            {
                while (true)
                {
                    TcpClient client = await server.AcceptTcpClientAsync(shutdown.Token);
                    // The TLS stack does blocking I/O, so each connection is handled on a pool thread.
                    _ = Task.Run(() => HandleClient(client));
                }
            }
            catch (OperationCanceledException)
            {
                Console.WriteLine("Shutting down.");
            }
            finally
            {
                server.Stop();
            }
            return 0;
        }

        private static void HandleClient(TcpClient client)
        {
            try
            {
                client.ReceiveTimeout = Timeout;
                client.SendTimeout = Timeout;
                client.NoDelay = true;   // send each record as soon as it is written, like the Apache servers of the era

                using (client)
                using (NetworkStream network = client.GetStream())
                {
                // The PS2 DNAS library sends an SSLv2-compatible ClientHello even though
                // the session it negotiates is SSL 3.0. Modern TLS libraries reject the
                // two-byte 0x80 record header before they can inspect the hello. Convert
                // only that initial compatibility hello to its equivalent SSL 3.0 record;
                // all subsequent encrypted records pass through unchanged.
                Stream tlsInput = PrepareTlsStream(network, out byte[]? legacyClientHello);
                var capture = new HandshakeCaptureStream(tlsInput);
                TlsServerProtocol tls = new LegacyTlsServerProtocol(capture, legacyClientHello);
                    try
                    {
                        // Handshake SSL
                        tls.Accept(new LegacyTlsServer(Crypto, Credentials!));
                        Stream stream = tls.Stream;

                        // Process HTTP
                        string? headers = ReadHeaders(stream);
                        if (headers == null)
                        {
                            SendBADResponse(stream);
                            return;
                        }

                        int contentLength = ParseContentLength(headers);
                        if (contentLength < 0 || contentLength > MaxBodyBytes)
                        {
                            SendBADResponse(stream);
                            return;
                        }

                        byte[] requestBody = new byte[contentLength];

                        if (contentLength > 0)
                        {
                            int bytesRead = 0;
                            while (bytesRead < contentLength)
                            {
                                int read = stream.Read(requestBody, bytesRead, contentLength - bytesRead);
                                if (read == 0) break;
                                bytesRead += read;
                            }
                        }

                        Console.WriteLine($"DNAS HTTP request received: body-bytes={requestBody.Length}");

                        // Process DNAS
                        if (Dnas1.Process(requestBody, out byte[]? response))
                        {
                            SendOKResponse(response!, stream);
                            Console.WriteLine($"DNAS HTTP response sent: status=200, body-bytes={response!.Length}");
                        }
                        else
                        {
                            SendBADResponse(stream);
                            Console.WriteLine("DNAS HTTP response sent: status=400");
                        }
                    }
                    finally
                    {
                        try { tls.Close(); } catch (Exception) { }
                    }
                }
            }
            catch (Exception e)
            {
                Console.Error.WriteLine($"Connection error: {e}");
            }
        }

        private static Stream PrepareTlsStream(Stream network, out byte[]? legacyClientHello)
        {
            legacyClientHello = null;
            int first = network.ReadByte();
            if (first < 0)
                throw new EndOfStreamException("Client closed before sending a TLS hello.");

            if ((first & 0x80) == 0)
                return new PrefixStream(new byte[] { (byte)first }, network);

            int second = network.ReadByte();
            if (second < 0)
                throw new EndOfStreamException("Truncated SSLv2-compatible ClientHello header.");

            int messageLength = ((first & 0x7F) << 8) | second;
            if (messageLength < 9 || messageLength > MaxHeaderBytes)
                throw new InvalidDataException("Invalid SSLv2-compatible ClientHello length.");

            byte[] message = new byte[messageLength];
            ReadExact(network, message, 0, message.Length);
            if (message[0] != 1)
                throw new InvalidDataException("Unsupported SSLv2 compatibility message.");

            int cipherLength = (message[3] << 8) | message[4];
            int sessionLength = (message[5] << 8) | message[6];
            int challengeLength = (message[7] << 8) | message[8];
            if (cipherLength < 3 || cipherLength % 3 != 0 || sessionLength > 32 || challengeLength < 16 || challengeLength > 32 ||
                9 + cipherLength + sessionLength + challengeLength != message.Length)
                throw new InvalidDataException("Malformed SSLv2-compatible ClientHello.");

            int cipherOffset = 9;
            int sessionOffset = cipherOffset + cipherLength;
            int challengeOffset = sessionOffset + sessionLength;
            using MemoryStream body = new();
            body.WriteByte(message[1]);
            body.WriteByte(message[2]);
            byte[] random = new byte[32];
            Buffer.BlockCopy(message, challengeOffset, random, random.Length - challengeLength, challengeLength);
            body.Write(random, 0, random.Length);
            body.WriteByte((byte)sessionLength);
            body.Write(message, sessionOffset, sessionLength);

            var suites = new MemoryStream();
            for (int at = cipherOffset; at < cipherOffset + cipherLength; at += 3)
            {
                // SSLv2 cipher specs are three bytes. A leading zero identifies a
                // cipher suite shared with SSL 3.0/TLS and can be represented directly.
                if (message[at] != 0) continue;
                suites.WriteByte(message[at + 1]);
                suites.WriteByte(message[at + 2]);
            }
            byte[] suiteBytes = suites.ToArray();
            if (suiteBytes.Length == 0)
                throw new InvalidDataException("ClientHello offered no SSL 3.0 cipher suites.");
            body.WriteByte((byte)(suiteBytes.Length >> 8));
            body.WriteByte((byte)suiteBytes.Length);
            body.Write(suiteBytes, 0, suiteBytes.Length);
            body.WriteByte(1);
            body.WriteByte(0);

            byte[] helloBody = body.ToArray();
            byte[] record = new byte[5 + 4 + helloBody.Length];
            record[0] = (byte)ContentType.handshake;
            record[1] = message[1];
            record[2] = message[2];
            int handshakeLength = 4 + helloBody.Length;
            record[3] = (byte)(handshakeLength >> 8);
            record[4] = (byte)handshakeLength;
            record[5] = (byte)HandshakeType.client_hello;
            record[6] = (byte)(helloBody.Length >> 16);
            record[7] = (byte)(helloBody.Length >> 8);
            record[8] = (byte)helloBody.Length;
            Buffer.BlockCopy(helloBody, 0, record, 9, helloBody.Length);
            // RFC 5246 E.2: Finished hashes the original SSLv2-format message from
            // msg_type onward; only its two-byte wire length is omitted. Retain it
            // so LegacyTlsServerProtocol can replace the parser's synthetic hello
            // with the exact transcript the PS2 calculated.
            legacyClientHello = message;
            Console.WriteLine($"Accepted PS2 SSLv2-compatible ClientHello (version {message[1]}.{message[2]}, {suiteBytes.Length / 2} SSL3 suites).");
            return new PrefixStream(record, network);
        }

        private static int RunSsl2CompatibilitySelfTest()
        {
            byte[] message = new byte[34];
            byte[] header = { 1, 3, 0, 0, 9, 0, 0, 0, 16, 0, 0, 4, 0, 0, 5, 0, 0, 10 };
            Buffer.BlockCopy(header, 0, message, 0, header.Length);
            for (int i = 0; i < 16; i++) message[18 + i] = (byte)i;
            byte[] packet = new byte[message.Length + 2];
            packet[0] = (byte)(0x80 | ((message.Length >> 8) & 0x7F));
            packet[1] = (byte)message.Length;
            Buffer.BlockCopy(message, 0, packet, 2, message.Length);

            using var transport = new TestDuplexStream(packet);
            Stream prepared = PrepareTlsStream(transport, out byte[]? legacyClientHello);
            var capture = new HandshakeCaptureStream(prepared);
            var tls = new LegacyTlsServerProtocol(capture, legacyClientHello);
            try { tls.Accept(new LegacyTlsServer(Crypto, Credentials!)); }
            catch (Exception) { }
            byte[] written = transport.Written;
            bool passed = tls.LegacyTranscriptApplied && written.Length >= 5 && written[0] == (byte)ContentType.handshake && written[1] == 3;
            Console.WriteLine(passed
                ? $"PASS SSLv2-compatible ClientHello produced an SSL3 server flight ({written.Length} bytes)."
                : "FAIL SSLv2-compatible ClientHello did not produce an SSL3 server flight.");
            return passed ? 0 : 1;
        }

        private static void ReadExact(Stream stream, byte[] buffer, int offset, int count)
        {
            int total = 0;
            while (total < count)
            {
                int read = stream.Read(buffer, offset + total, count - total);
                if (read <= 0) throw new EndOfStreamException("Truncated client handshake.");
                total += read;
            }
        }

        private sealed class PrefixStream : Stream
        {
            private readonly byte[] Prefix;
            private readonly Stream Inner;
            private int PrefixPosition;

            public PrefixStream(byte[] prefix, Stream inner) { Prefix = prefix; Inner = inner; }
            public override bool CanRead => true;
            public override bool CanSeek => false;
            public override bool CanWrite => true;
            public override long Length => throw new NotSupportedException();
            public override long Position { get => throw new NotSupportedException(); set => throw new NotSupportedException(); }
            public override void Flush() => Inner.Flush();
            public override int Read(byte[] buffer, int offset, int count)
            {
                int copied = 0;
                if (PrefixPosition < Prefix.Length)
                {
                    copied = Math.Min(count, Prefix.Length - PrefixPosition);
                    Buffer.BlockCopy(Prefix, PrefixPosition, buffer, offset, copied);
                    PrefixPosition += copied;
                    if (copied == count) return copied;
                }
                return copied + Inner.Read(buffer, offset + copied, count - copied);
            }
            public override int Read(Span<byte> buffer)
            {
                int copied = 0;
                if (PrefixPosition < Prefix.Length)
                {
                    copied = Math.Min(buffer.Length, Prefix.Length - PrefixPosition);
                    Prefix.AsSpan(PrefixPosition, copied).CopyTo(buffer);
                    PrefixPosition += copied;
                    if (copied == buffer.Length) return copied;
                }
                return copied + Inner.Read(buffer[copied..]);
            }
            public override void Write(byte[] buffer, int offset, int count) => Inner.Write(buffer, offset, count);
            public override void Write(ReadOnlySpan<byte> buffer) => Inner.Write(buffer);
            public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
            public override void SetLength(long value) => throw new NotSupportedException();
        }

        internal sealed class HandshakeCaptureStream : Stream
        {
            private readonly Stream Inner;
            private readonly MemoryStream Captured = new();
            public HandshakeCaptureStream(Stream inner) { Inner = inner; }
            public byte[] TakeCapturedWrites()
            {
                byte[] result = Captured.ToArray();
                Captured.SetLength(0);
                return result;
            }
            public override bool CanRead => Inner.CanRead;
            public override bool CanSeek => false;
            public override bool CanWrite => Inner.CanWrite;
            public override long Length => throw new NotSupportedException();
            public override long Position { get => throw new NotSupportedException(); set => throw new NotSupportedException(); }
            public override void Flush() => Inner.Flush();
            public override int Read(byte[] buffer, int offset, int count) => Inner.Read(buffer, offset, count);
            public override int Read(Span<byte> buffer) => Inner.Read(buffer);
            public override void Write(byte[] buffer, int offset, int count)
            {
                Captured.Write(buffer, offset, count);
                Inner.Write(buffer, offset, count);
            }
            public override void Write(ReadOnlySpan<byte> buffer)
            {
                Captured.Write(buffer);
                Inner.Write(buffer);
            }
            public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
            public override void SetLength(long value) => throw new NotSupportedException();
        }

        private sealed class TestDuplexStream : Stream
        {
            private readonly MemoryStream Input;
            private readonly MemoryStream Output = new();
            public TestDuplexStream(byte[] input) { Input = new MemoryStream(input, false); }
            public byte[] Written => Output.ToArray();
            public override bool CanRead => true;
            public override bool CanSeek => false;
            public override bool CanWrite => true;
            public override long Length => throw new NotSupportedException();
            public override long Position { get => throw new NotSupportedException(); set => throw new NotSupportedException(); }
            public override void Flush() { }
            public override int Read(byte[] buffer, int offset, int count) => Input.Read(buffer, offset, count);
            public override int Read(Span<byte> buffer) => Input.Read(buffer);
            public override void Write(byte[] buffer, int offset, int count) => Output.Write(buffer, offset, count);
            public override void Write(ReadOnlySpan<byte> buffer) => Output.Write(buffer);
            public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
            public override void SetLength(long value) => throw new NotSupportedException();
            protected override void Dispose(bool disposing)
            {
                if (disposing) { Input.Dispose(); Output.Dispose(); }
                base.Dispose(disposing);
            }
        }

        private static void SendOKResponse(byte[] data, Stream stream)
        {
            StringBuilder responseHeader = new StringBuilder();
            responseHeader.Append("HTTP/1.0 200 OK\r\n");
            responseHeader.Append("Content-Type: image/gif\r\n");
            responseHeader.Append($"Content-Length: {data.Length}\r\n");
            responseHeader.Append("Connection: close\r\n");
            responseHeader.Append("\r\n");

            // One write, so the response goes out in as few TLS records as possible.
            byte[] headerBytes = Encoding.ASCII.GetBytes(responseHeader.ToString());
            byte[] responseBytes = new byte[headerBytes.Length + data.Length];
            headerBytes.CopyTo(responseBytes, 0);
            data.CopyTo(responseBytes, headerBytes.Length);
            stream.Write(responseBytes, 0, responseBytes.Length);
            stream.Flush();
        }

        private static void SendBADResponse(Stream stream)
        {
            StringBuilder responseHeader = new StringBuilder();
            responseHeader.Append("HTTP/1.0 400 Bad Request\r\n");
            responseHeader.Append("Content-Type: image/gif\r\n");
            responseHeader.Append("Connection: close\r\n");
            responseHeader.Append("\r\n");

            byte[] headerBytes = Encoding.ASCII.GetBytes(responseHeader.ToString());
            stream.Write(headerBytes, 0, headerBytes.Length);
            stream.Flush();
        }

        // Returns null if the headers exceed MaxHeaderBytes.
        private static string? ReadHeaders(Stream stream)
        {
            StringBuilder headerCollector = new StringBuilder();
            byte[] buffer = new byte[1];
            while (stream.Read(buffer, 0, 1) > 0)
            {
                headerCollector.Append((char)buffer[0]);
                if (headerCollector.ToString().EndsWith("\r\n\r\n"))
                    break;
                if (headerCollector.Length >= MaxHeaderBytes)
                    return null;
            }
            return headerCollector.ToString();
        }

        private static int ParseContentLength(string headers)
        {
            foreach (var line in headers.Split("\r\n"))
            {
                if (line.StartsWith("Content-Length:", StringComparison.OrdinalIgnoreCase))
                {
                    int.TryParse(line.Split(":")[1].Trim(), out int length);
                    return length;
                }
            }
            return 0;
        }
    }
}
